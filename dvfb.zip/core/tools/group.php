<script>
    var _0xc1da=["\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x31\x32\x70\x78\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x61\x64\x64\x43\x6C\x61\x73\x73","\x23\x65\x78\x65\x63","\x76\x61\x6C","\x23\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E","\x23\x74\x69\x6D\x65","\x7C","\x73\x70\x6C\x69\x74","\x23\x6E\x6F\x69\x5F\x64\x75\x6E\x67","\x23\x69\x64\x74\x75\x73","\x23\x67\x72\x6F\x75\x70","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x46\x61\x69\x6C\x65\x64\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x64\x6F\x6E\x65","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x61\x63\x65\x62\x6F\x6F\x6B\x2E\x63\x6F\x6D\x2F","\x2F\x73\x68\x61\x72\x65\x64\x70\x6F\x73\x74\x73\x3F\x74\x6F\x3D","\x26\x6C\x6F\x63\x61\x6C\x65\x3D\x76\x69\x5F\x56\x4E\x26\x6D\x65\x74\x68\x6F\x64\x3D\x70\x6F\x73\x74\x26\x72\x65\x74\x75\x72\x6E\x5F\x73\x74\x72\x75\x63\x74\x75\x72\x65\x3D\x74\x72\x75\x65\x26\x6D\x65\x73\x73\x61\x67\x65\x3D","\x26\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68\x21","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x70\x72\x69\x6D\x61\x72\x79","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73"];function exec(){$(_0xc1da[6])[_0xc1da[5]](_0xc1da[4])[_0xc1da[3]](_0xc1da[2])[_0xc1da[1]](_0xc1da[0],_0xc1da[0]);var _0xfd2ax2=$(_0xc1da[8])[_0xc1da[7]]();var _0xfd2ax3=$(_0xc1da[9])[_0xc1da[7]]();var _0xfd2ax4=$(_0xc1da[12])[_0xc1da[7]]()[_0xc1da[11]](_0xc1da[10]);var _0xfd2ax5=$(_0xc1da[13])[_0xc1da[7]]();var _0xfd2ax6=$(_0xc1da[14])[_0xc1da[7]]();var _0xfd2ax7=0,_0xfd2ax8=0;$(_0xc1da[20])[_0xc1da[19]](_0xc1da[18])[_0xc1da[17]](_0xc1da[15]+ _0xfd2ax6[_0xc1da[16]]);for(var _0xfd2ax9=0;_0xfd2ax9< _0xfd2ax6[_0xc1da[16]];_0xfd2ax9++){!function(_0xfd2ax9){setTimeout(function(){var _0xfd2axa=_0xfd2ax4[Math[_0xc1da[22]](Math[_0xc1da[21]]()* _0xfd2ax4[_0xc1da[16]])];$[_0xc1da[33]](_0xc1da[29]+ _0xfd2ax5+ _0xc1da[30]+ _0xfd2ax6[_0xfd2ax9]+ _0xc1da[31]+ encodeURIComponent(_0xfd2axa)+ _0xc1da[32]+ _0xfd2ax2)[_0xc1da[28]](function(){_0xfd2ax7++;$(_0xc1da[27])[_0xc1da[19]](_0xc1da[18])[_0xc1da[17]](_0xc1da[26]+ _0xfd2ax7)})[_0xc1da[25]](function(){_0xfd2ax8++;$(_0xc1da[24])[_0xc1da[19]](_0xc1da[18])[_0xc1da[17]](_0xc1da[23]+ _0xfd2ax8)});if((_0xfd2ax9+ 1)== _0xfd2ax6[_0xc1da[16]]){$(_0xc1da[6])[_0xc1da[36]](_0xc1da[4])[_0xc1da[5]](_0xc1da[35])[_0xc1da[17]](_0xc1da[34])[_0xc1da[1]](_0xc1da[0],_0xc1da[0])}},_0xfd2ax9* 1000* _0xfd2ax3)}(_0xfd2ax9)}}
</script>
<div class="col-md-12" id="form">
            <div class="panel panel-primary">
            <div class="panel-heading">
        <h2 class="panel-title">Auto Chia Sẻ Post Group.</h3>
        </div>
        <div class="panel-body">
        <input type="hidden" value="<?php echo $utoken; ?>" id="access_token" name="access_token" />
        <div class="box-body">

            <div class="form-group">
                <label for="time"> Nhập ID Status/Ảnh/Video-Live Stream cần share:</label><br />
                <input type="text" name="idtus" id="idtus" class="form-control" placeholder="Nhập ID" />
            </div>
            <div class="form-group">
                <label for="sl">Chọn Group (Ấn giữ Ctrl và Click chọn hoặc Ấn giữ Shift và kéo chuột để chọn nhiều):</label>
                <select name="group[]" id="group" class="form-control" multiple="" style="height: 400px">
                    <?php
                    $get = json_decode(file_get_contents('https://graph.fb.me/me/groups?access_token=' . $utoken . '&fields=id,name&method=get&limit=5000'), true);
                    for ($i = 0; $i < count($get['data']); $i++) {
                        echo "<option value='" . $get['data'][$i]['id'] . "'>" . ($i + 1) . ". " . $get['data'][$i]['name'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="nd">Nội dung :</label>
                <textarea class="form-control" id="noi_dung" name="noi_dung" rows="7" placeholder="Nhập nội dung của bài chia sẻ, nội dung khác nhau bởi dấu |" required><?php echo isset($_POST['noi_dung']) ? $_POST['noi_dung'] : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label for="time"> Delay (tính bằng giây):</label><br />
                <input type="text" name="time" id="time" class="form-control" placeholder="Nhập Time Delay" />
            </div>

        </div>

        <div class="box-footer">
            <button type="button" id="exec" onclick="exec()" class="btn btn-primary">Auto Share To Group</button>
            <button id="total" class="btn btn-default" style="display:none"></button>
            <button id="success" class="btn btn-success" style="display:none"></button>
            <button id="fail" class="btn btn-danger"style="display:none"></button>
        </div>
        </form> 
    </div>
</div>
