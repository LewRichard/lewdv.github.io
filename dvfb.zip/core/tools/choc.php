<?php $titles='CHỌC BẠN BÈ LẤY TƯƠNG TÁC'; 
if ($uname != $accoutadmin) {
	echo "<script>alert('Ra ngoài chơi đi em???'); window.location='index.php';</script>";
        }else{
?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
<?php
error_reporting(0);
ini_set('max_execution_time', 0);
if (isset($_POST['submit'])) {
	$token = $_POST['access_token'];
	$limit = $_POST['limit'];
	$friend="https://graph.facebook.com/me/friends?limit=".$limit."&fields=id&access_token=".$token."";
	$json=json_decode(file_get_contents($friend));
	$data=$json->data;
	foreach($data as $data1)
	{
		$getid=$data1->id;
		$poke="https://graph.facebook.com/$getid/pokes?method=post&access_token=".$token."";
		$json=json_decode(file_get_contents($poke));
		sleep(rand(3,5));
	}
	if($json!=NULL)
	{
		echo '<font color=red>Đã chọc thành công!</font>';
	}
	else
	{
	echo 'Bạn đã chọc nhưng chưa được phản hồi!';die;
	}
}
	?>
			<div class="form-group">
                    <label for="access_token">Mã token:</label>
                    <input name="access_token" class="form-control" rows="10" value="<?php echo isset($_POST['access_token']) ? $_POST['access_token'] : ''; ?>" placeholder="Nhập mã token nick cần chọc...">
                </div>
				<div class="form-group">
                    <label for="limit">Nhập số người muốn chọc (max 5.000)</label>
                    <input type="number" name="limit" class="form-control" rows="10" value="<?php echo isset($_POST['limit']) ? $_POST['limit'] : ''; ?>" placeholder="">
                </div>
        </div>
        <div class="panel-footer">
            <button class="btn btn-success" type="submit" name="submit">Xác nhận</button>
        </div>
            </form>
    </div>
</div>
		<?php } ?>
