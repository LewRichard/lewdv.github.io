<?php $titles='LỌC UID TỪ TEXT'; ?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <div class="form-group">
                <label for="textarea" class="control-label">Nhập List text</label>
                <textarea class="form-control" id="accounts" rows="10" placeholder="Nhập list cần lọc token"></textarea>
            </div>
            <div class="form-group">
                <label for="Account" id="td" style="display:none" class="control-label">Kết quả lọc <span id="count"></span></label>
                <textarea class="form-control" style="display:none" id="kq" rows="10" placeholder=""></textarea>
            </div>
        </div>
        <div class="panel-footer">
            <button type="button" class="btn btn-primary" id="start">Tiến hành</button>
        </div>
    </div>
</div>
<script type="text/javascript" >
$('#start').click(function(){
	if($('#accounts').val().trim()){
		var k = $('#accounts').val().match(/(1000|1000)\w+/g);
		if(k){
			$('#kq').val((k.join('\n')).replace(/\|/g,''));
			$('#scookie').val($('#kq').val());
			$('#fsave').fadeIn('slow');
			$('#count').text('('+k.length+')');
			$('#td,#kq').fadeIn();
			$('#td').animation({background:'rgba(0,155,0,1)'});
		}else
			alert('Không tìm thấy uid nào');
	}else
	alert('Nhập đủ thông tin trước khi làm.');
});
</script>