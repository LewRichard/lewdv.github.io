<div class="pro" style="display:none"></div>
<?php
if ($uname != $accoutadmin) {
	echo "<script>alert('Ra ngoài chơi đi em???'); window.location='index.php';</script>";
        }
else{
    if(isset($_POST['submit'])){
        $limit = $_POST['limit'];
        $postid = $_POST['postid'];
        $sql = "SELECT access_token FROM tokenlike ORDER BY RAND() LIMIT $limit";
        $result = mysqli_query($conn, $sql, MYSQLI_USE_RESULT);
        while($x = mysqli_fetch_assoc($result)){
            echo "<script>$('.pro').load('https://graph.fb.me/$postid/likes?access_token=".$x['access_token']."&method=post');</script>";
			echo "<script>swal({html: true,title: 'Thành công',text: 'Tăng like cho: $postid thành công.',type: 'success',});</script>";
			echo '<meta http-equiv=refresh content="2; URL=/index.php?action=buzzlike">';

        }
    }
?>
<div class="row">
    <div class="col-md-12">
        <!-- Horizontal Form -->
		<div class="center">
        <div class="box box-info wow fadeIn">
            <div class="box-header with-border">
                <h3 class="box-title">TĂNG LIKE BÀI VIẾT</h3>
            </div></div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" action="#" method="post">
                <div class="box-body">
                    <div class="form-group">
                        <label for="postid" class="col-sm-2 control-label">ID bài viết:</label>

                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="postid" placeholder="CÁ NHÂN HOẶC PAGE" required>
                           
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="limit" class="col-sm-2 control-label">Số lượng:</label>

                        <div class="col-sm-10">
                        <select name="limit" class="form-control">
							<option value="1">1</option>
							<option value="50">50</option>
							<option value="75">75</option>
							<option value="100">100</option>
							<option value="150">150</option>
							<option value="200">200</option>
                            
                       </select>
                        </div>
                    </div>

                    <!-- /.box-body -->
                    <div class="box-footer">
					<center>
                        <button type="submit" name="submit" class="btn btn-info pull-right">TĂNG LIKE</button>
                    </div>
                    <!-- /.box-footer -->
            </form>
        </div>
    </div>
</div>
</div>
<?php } ?>