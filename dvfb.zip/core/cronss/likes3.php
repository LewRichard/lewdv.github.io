<?php
	include '../system/config.php';
	$layvip = "SELECT user_id, name, end, likes, max_like FROM vip WHERE server=3 ORDER BY RAND()";
	$result = mysqli_query($conn, $layvip);
	while($vip = mysqli_fetch_assoc($result)){
			$user_id = $vip['user_id'];
			$name = $vip['name'];
			$id_ctv = $vip['id_ctv'];
			$thoigian = time();
			$time = $vip['end'];
			$timed = $time - time();
			$conlai = round($timed/(24*3600));
			if ($conlai < 0){
				$sql = "DELETE FROM `vip` WHERE `user_id`= $user_id";
				if (mysqli_query($conn, $sql)) {
					$nd = "Vip Like";
					$lydo = "Hết Hạn";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$id_ctv', '$name', '$nd', '$thoigian', '$lydo')";
					if (mysqli_query($conn, $his)){
						echo 'Đã xoá và lưu lịch sử viplike';
					}
			}
			}
		$result1 = mysqli_query($conn, "SELECT access_token FROM tokenlike ORDER BY RAND() LIMIT ".$vip['likes']);
		while($token = mysqli_fetch_assoc($result1)){
			$feed = json_decode(load('https://graph.fb.me/'.$vip['user_id'].'/feed?limit=1&fields=id,likes&method=get&access_token='.$token['access_token']),true);
			if($feed['data'][0]['likes']['count'] < $vip['max_like']){
				load('https://graph.fb.me/'.$feed['data'][0]['id'].'/likes?access_token='.$token['access_token'].'&method=post');
			}
		}
	}
	function load($url){
		$ch =  curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$duy = curl_exec($ch);
		return $duy;
		curl_close($ch);
	}
?>