<title>Auto Rep Cmt</title>
<?php
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
$today = date('H:i d-m-Y');
$now = date('H');
include '../system/config.php';
$laytoken = mysqli_query($conn, "SELECT * FROM autorep WHERE status=0  ORDER BY RAND() LIMIT 1");
while($viprep = mysqli_fetch_assoc($laytoken)){
    $token= $viprep['access_token'];
    $id_user = $viprep['user_id'];
	$id_ctv = $viprep['id_ctv'];
	$name = $viprep['name'];
	$thoigian = time();
	//$limitpost = $viprep['limit_cmt'];
	$times = $viprep['end'];// xoá gói vip hết hạn.
	$timed = $times - time();
	$conlai = round($timed/(24*3600));
	if ($conlai < 0){
				$sql = "DELETE FROM `autorep` WHERE `user_id`= $id_user";
				if (mysqli_query($conn, $sql)) {
					$nd = "Vip Rep Cmt";
					$lydo = "Hết Hạn";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time) VALUES('$id_user', '$id_ctv', '$name', '$nd', '$thoigian', '$lydo')";
					if (mysqli_query($conn, $his)){
						echo 'Đã xoá và lưu lịch sử viprep';
					}
			}
			}
	// xoá vip hết hạn
	if (($now >= 9) && ($now <= 20)){
set_time_limit(0);
@ini_set('display_errors', 'on');
function post_data($site,$data,$cookie){
    $datapost = curl_init();
    $headers = array("Expect:");
    curl_setopt($datapost, CURLOPT_URL, $site);
    curl_setopt($datapost, CURLOPT_TIMEOUT, 40000);
    curl_setopt($datapost, CURLOPT_HEADER, TRUE);
    curl_setopt($datapost, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($datapost, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    curl_setopt($datapost, CURLOPT_POST, TRUE);
    curl_setopt($datapost, CURLOPT_POSTFIELDS, $data);
    curl_setopt($datapost, CURLOPT_COOKIE,$cookie);
    ob_start();
    return curl_exec ($datapost);
    ob_end_clean();
    curl_close ($datapost);
    unset($datapost);
}
function curl_f($url,$cookie)
{
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $page = curl_exec($ch);
    curl_close($ch);
    return $page;
}
function laynoidung($noidung, $start, $stop) {
    $bd = strpos($noidung, $start);
    $tru = strlen($start);
    $bd = $bd + $tru;
    $noidung2 = substr($noidung, $bd);
    $kt = strpos($noidung2, $stop);
    $content = substr($noidung2, 0, $kt);
    return $content;
    }
function cURL($a = NULL){
        if($a){
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_TIMEOUT => 120,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HEADER => false,
                CURLOPT_REFERER        =>'https://graph.facebook.com/',
                CURLOPT_USERAGENT      => 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_0_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13A452 Safari/601.1.46 Sleipnir/4.2.2m',
                CURLOPT_URL            => $a,
                )
            );
            $result = curl_exec($curl);
            curl_close($curl);
            return $result;
        }
        else return false;
    }
function saveFile($path,$y){
        $file = @fopen($path, 'w');
                @fwrite($file, $y);
                @fclose($file);
    }
function getData($id_user, $post, $type){
        if(!is_dir('data')) mkdir('data');
        if(file_exists('data/'.$type.'_'.$id_user)) $data = file_get_contents('data/'.$type.'_'.$id_user);
        else $data = ' ';
        if(preg_match('/'.$post['id'].'/', $data)) return false;
        else{
            if(strlen($data) > 5000) $text = strlen($data) - 5000;
            else $text = 0;
            saveFile('data/'.$type.'_'.$id_user, substr($data, $text).' '.$post['id']);
            return true;
        }
    }
function app($a = NULL){
        if($a){
            $result = cURL('https://graph.facebook.com/app?access_token='.$a);
            return json_decode($result, true);
        }
        else return false;
    }
function token_to_cookie($a){
        $cookie_nguon = cURL($a);
        $c_user = laynoidung($cookie_nguon, 'c_user","value":"', '"');
        $datr = laynoidung($cookie_nguon, 'datr","value":"', '"');
        $fr = laynoidung($cookie_nguon, '"fr","value":"', '"');
        $xs = laynoidung($cookie_nguon, '"xs","value":"', '"');
        $cookie = 'c_user='.$c_user.';xs='.$xs.';fr='.$fr.';datr='.$datr.'';
        return $cookie;
        }
function getHome_Like($token){
        if($token) $data = json_decode(cURL('https://graph.facebook.com/me/feed?fields=comments.from,comments.id,comments.order(reverse_chronological).limit(5)&order=reverse_chronological&limit=1&access_token='.$token.'&method=get'), true);
        if(isset($data['data'])) return $data['data'];
        else return $data;
    }
function _autoReplyComment($id_user, $token){
    $app = app($token);
    $appid = $app['id'];
    $cookie = token_to_cookie('https://api.facebook.com/method/auth.getSessionforApp?access_token='.$token.'&format=json&new_app_id='.$appid.'&generate_session_cookies=1');
    $url = curl_f("https://m.facebook.com/",$cookie);
    $fb_dtsg = laynoidung($url, 'fb_dtsg\" value=\"', '\"');
    if($fb_dtsg ==NULL){
    $fb_dtsg = laynoidung($url, 'name="fb_dtsg" value="', '"');
    }
    $datauser = getHome_Like($token);
foreach($datauser as $post){
	
    $number_comment = @count($post['comments']['data']);
    if($number_comment > 0){
    for($i=0;$i<$number_comment;$i++){
    $formname = $post['comments']['data'][$i]['from']['name'];
    $formid = $post['comments']['data'][$i]['from']['id'];
   // $list_cx = array('1', '2');
   // $type = $list_cx[array_rand($list_cx)];
    $idbai = $post['comments']['data'][$i]['id'];
    preg_match('/(.*)_(.*)/', $idbai, $id);
	// khai báo lại config để select comment.
	$today = date('H:i d-m-Y');
	$now = date('H');
	include '../system/config.php';
	$laytoken = mysqli_query($conn, "SELECT * FROM autorep WHERE status=0  ORDER BY RAND() LIMIT 1");
	while($viprep = mysqli_fetch_assoc($laytoken)){
    $cmtngay = $viprep['cmtngay'];
	//$type = $viprep['camxuc'];
	$tag = $viprep['tag'];
	$type = "";
	$uid = $viprep['user_id'];
    // lấy cmt mạc định
    $listcmt = explode("\n", $viprep['comment']);
    $comment = urlencode($listcmt[array_rand($listcmt)]);
	//$cmt = $comment;
	// lấy cmt sáng
    $cmts = explode("\n", $viprep['comments']);
    $cmtsang = urlencode($cmts[array_rand($cmts)]);
    // lấy cmt chiều
    $cmtc = explode("\n", $viprep['commentc']);
    $cmtchieu = urlencode($cmtc[array_rand($cmtc)]);
    // lấy cmt tối
    $cmtt = explode("\n", $viprep['commentt']);
    $cmttoi = urlencode($cmtt[array_rand($cmtt)]);
					if ($uid == $id_user){
                            if ($cmtngay == 1){
										if (($now > 8) && ($now < 11)){
												if ($tag == 1){
												$cmt = ''.$formname.' '.$cmtsang.'';
												}else{
												$cmt = $cmtsang;	
												}
											}
										else if (($now > 11) && ($now < 17)){
												if ($tag == 1){
												$cmt = ''.$formname.' '.$cmtchieu.'';
												}else{
												$cmt = $cmtchieu;
												}
											}
										else if (($now >= 18) && ($now <= 20)){
												if ($tag == 1){
												$cmt = ''.$formname.' '.$cmttoi.'';
												}else{
												$cmt = $cmttoi;	
												}
										}else{
												if ($tag == 1){
												$cmt = ''.$formname.' '.$comment.'';
												}else{
												$cmt = $comment;	
												}
											}
                            }else{
										if ($tag == 1){
												$cmt = ''.$formname.' '.$comment.'';
										}else{
												$cmt = $comment;	
												}
                            }
					}else if ($uid != $id_user){
						//echo '<meta http-equiv="refresh" content="30; URL=/">';
						exit();
					}
					
	
    if(getData($id_user, $post['comments']['data'][$i], 'vuicode') && $formid != $id_user){
    post_data("https://m.facebook.com/a/comment.php?parent_redirect_comment_token=".$idbai."&reaction_comment_id=".$id[2]."&viewer_reaction=".$type."&snowflake&ft_ent_identifier=".$id[1]."&gfid=AQC-aepxhZdf9lda&fs=8&refid=52&_ft_=&__tn__=R-R&client_id=1532281926543%3A4153625919&session_id=7bb19afc","m_sess=&fb_dtsg=".$fb_dtsg."&__dyn=1KQdAmmcwGxyufxe6oaE-F48xHXBgR3oy6F8mz8C2K2i5U9EoK363u4oSewYwGxWU5l0Yxm6Uhx6484Gi78y1qwDyoe8hxm3O3q6E42260AU8EmyUb852q3q5U2nwvE6W787um78pwAwWwnElz81m89XzU4G9w&__req=1o&__ajax__=AYm5se7ooUkmqWtuhnyyico2jHfCNtLxN7V2nLwZfTjxIjnU1te91w1wTB4vdRlsJDBCdUqvCqFSGYLIQJ0cKdkWlCFU1op0QBjeDc__JzTRuA&__user=".$id_user,$cookie);
    post_data("https://m.facebook.com/a/comment.php?parent_comment_id=".$id[2]."&parent_redirect_comment_token=".$idbai."&fs=0&comment_logging&inline_reply=1&ft_ent_identifier=".$id[1]."&eav=Afa2lDjEl_6Ifk-JMLPaRvtVxQGxx9031L9X-BELJ5xinhlL_Malhqy_aoDFNGzNQA4&av=".$id_user."&gfid=AQAQOXLpNf8IUhrv","comment_text=".$cmt."&privacy_value=0&waterfall_source=&client_id=1532281521777%3A3513778072&session_id=7bb19afc&submit=Tr%E1%BA%A3%20l%E1%BB%9Di&m_sess=&fb_dtsg=".$fb_dtsg."&__dyn=1KQdAmmcwGxyufxe6oaE-F48xHXBgR3oy6F8mz8C2K2i5U9EoK363u4oSewYwGxWU5l0Yxm6Uhx6484Gi78y1qwDyoe8hxm3O3q6E42260AU8EmyUb852q3q5U2nwvE6W787um78pwAwWwnElz81m89XzU4G9w&__req=n&__ajax__=AYm5se7ooUkmqWtuhnyyico2jHfCNtLxN7V2nLwZfTjxIjnU1te91w1wTB4vdRlsJDBCdUqvCqFSGYLIQJ0cKdkWlCFU1op0QBjeDc__JzTRuA&__user=".$id_user,$cookie);
    }
	//}
	}
    }
    }
    }
    }
    _autoReplyComment($id_user, $token);
	}//set time
}//while
// share by kimnamyou and admin Vuicode edit by Kim Quang
?>