<?php
    ob_start();
    session_start();
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $today = date('H:i d-m-Y');
    include '../system/config.php';
    $layvip = "SELECT * FROM vip WHERE server=3 ORDER BY RAND() LIMIT 25";
    $result = mysqli_query($conn, $layvip);
    while($vip = mysqli_fetch_assoc($result)){
			$user_id = $vip['user_id'];
			$name = $vip['name'];
			$id_ctv = $vip['id_ctv'];
			$thoigian = time();
			$time = $vip['end'];
			$timed = $time - time();
			$conlai = round($timed/(24*3600));
			if ($conlai < 0){
				$sql = "DELETE FROM `vip` WHERE `user_id`= $user_id";
				if (mysqli_query($conn, $sql)) {
					$nd = "Vip Like";
					$lydo = "Hết Hạn";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$id_ctv', '$name', '$nd', '$thoigian', '$lydo')";
					if (mysqli_query($conn, $his)){
						echo 'Đã xoá và lưu lịch sử viplike';
					}
			}
			}// xoá vip hết hạn
		$cx = $vip['type'];
        if(strripos($vip['type'], "\n")){
            $list_cx = explode("\n", $vip['type']);
            $cx = $list_cx[array_rand($list_cx)];
        }// lấy cảm xúc
		$result1 = mysqli_query($conn, 'SELECT * FROM tokenlike3 ORDER BY RAND() LIMIT '.$vip['likes']);
		while($token = mysqli_fetch_assoc($result1)){
			$feed = json_decode(load('https://graph.fb.me/'.$vip['user_id'].'/feed?limit=1&fields=id,likes,story&method=get&access_token='.$token['access_token']),true);
			if(stripos($feed['data'][0]['story'], 'profile picture.', 0) || stripos($feed['data'][0]['story'], 'cover photo.', 0)){
				$idpost = explode('_', $feed['data'][0]['id'])[1];
			}else{
				$idpost = $feed['data'][0]['id'];
			}
            $count_react = json_decode(load('https://graph.fb.me/'.$feed['data'][0]['id'].'/reactions?access_token='.$token['access_token'].'&fields=id&method=get&summary=total_count'),true);
			if($count_react['summary']['total_count'] < $vip['max_like']){
				load('https://graph.fb.me/'.$idpost.'/reactions?type='.$cx.'&access_token='.$token['access_token'].'&method=post');
                echo '<center>Done To : <a href="//fb.com/'.$idpost.'" target="_blank">'.$feed['data'][0]['id'].'</a> </hr></center>';
            }
        }
    }
    function load($url){
        $ch =  curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $duy = curl_exec($ch);
        return $duy;
        curl_close($ch);
    }
   
?>