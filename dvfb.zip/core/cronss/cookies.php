<?php

  $cookie = 'js_ver=3303; datr=bbPpWW4SuI1YAaH_6o2cdpPm; locale=vi_VN; dpr=1.25; sb=bbPpWSp--eWOQM-93YI89xCq; c_user=100022844836577; xs=33%3A7PjuAl1hqa5Pww%3A2%3A1547992241%3A13077%3A7497; fr=0Ak25Qbzx6Xr4iXrt.AWWlZtchYPt4S_8lV1hYEuyoJ_U.BZ6bNt.ZC.AAA.0.0.BcRHyx.AWWEnSVR; pl=n; spin=r.4699263_b.trunk_t.1547992242_s.1_v.2_; wd=1103x753; presence=EDvF3EtimeF1547992289EuserFA21B22844836577A2EstateFDutF1547992289850CEchFDp_5f1B22844836577F2CC';

  $content = auto('https://mbasic.facebook.com/home.php?sk=h_chr', $cookie);

  preg_match('#target" value="(.+?)"#is', $content, $id_user);

  $id_user = $id_user['1'];

  preg_match('#fb_dtsg" value="(.+?)"#is', $content, $fb_dtsg);

  $fb_dtsg = $fb_dtsg['1'];

  if (preg_match_all('#ft_ent_identifier=(.+?)&#is', $content, $story)) {

    $datapost = file_get_contents('idpost.log');

    for ($i=0; $i<count($story['1']); $i++) {
echo count($story['1']);
      $id_stt = $story['1'][$i];

      $comment = array('tym nek ?', 'tương tác nek ?', 'iu wa ?', 'yêu thích ?', 'haha haha ?');

      $cmt = $comment[rand(0, count($comment)-1)];

      if (strpos($datapost, $id_stt) == 0) {

        $reaction = auto('https://mbasic.facebook.com/reactions/picker/?ft_id=' . $id_stt . '&av=' . $id_user, $cookie);

        preg_match_all('#a href="(.+?)"#is', $reaction, $like);

        auto('https://mbasic.facebook.com' . $like['1'][rand(0, 5)], $cookie, 'fb_dtsg=' . $fb_dtsg . '&reaction_type=' . rand(0, 5));

        auto('https://mbasic.facebook.com/a/comment.php?ft_ent_identifier=' . $id_stt . '&av=' . $id_user, $cookie, 'fb_dtsg=' . $fb_dtsg . '&comment_text=' . urlencode($cmt));

        echo 'Done ' . $id_stt . ' comment ' . $cmt . ' <br>';

        $data = fopen('idpost.log', 'a');
        fwrite($data, $id_stt . "\n");
        fclose($data);

      }

    }

  }

  function auto($url, $cookie, $post = '') {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_USERAGENT, 'NokiaC3-00');
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_COOKIE, $cookie);
    if ($post) curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
  }

?>