<?php
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
$today = date('H:i d-m-Y');
$now = date('H');
include '../system/config.php';
$laytoken = mysqli_query($conn, "SELECT * FROM vipreaction WHERE server=1 AND status=0  ORDER BY RAND() LIMIT 0,20");
while($vipbot = mysqli_fetch_assoc($laytoken)){
    echo $vipbot['user_id'].'<hr>';
    $token= $vipbot['access_token'];
    $litmit = $vipbot['limit_react'];
    $time = substr(time(),0,6);
    $camxuc = $vipbot['type'];
	$user_id = $vipbot['user_id'];
	$name = $vipbot['name'];
	$$id_ctv = $vipbot['id_ctv'];
	$thoigian = time();
	$batcx = $vipbot['batcx'];
	$giochay = $vipbot['giochay'];
	$giodung = $vipbot['giodung'];
	$nhandan = $vipbot['nhandan'];
	$batcmt = $vipbot['cmt'];
	$stick = $vipbot['stick'];
	$cmtngay = $vipbot['cmtngay'];
	$chan = $vipbot['idchan'];//id muốn không tương tác
	$times = $vipbot['end'];// xoá gói vip hết hạn.
	$timed = $times - time();
	$conlai = round($timed/(24*3600));
	if ($conlai < 0){
				$sql = "DELETE FROM `vipreaction` WHERE `user_id`= $user_id";
				if (mysqli_query($conn, $sql)) {
					$nd = "Vip Bot";
					$lydo = "Hết Hạn";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$id_ctv', '$name', '$nd', '$thoigian', '$lydo')";
					if (mysqli_query($conn, $his)){
						echo 'Đã xoá và lưu lịch sử vipbot';
					}
			}
			}// xoá vip hết hạn
if (($now >= $giochay) && ($now <= $giodung)){
//if((($now >= 8) && ($now <= 10)) || (($now >= 12) && ($now <= 15)) || (($now >= 17) && ($now <= 20))){
    if(strripos($vipbot['type'], "\n")){
        $list_cx = explode("\n", $vipbot['type']);
        $camxuc = $list_cx[array_rand($list_cx)];
    }
	// lấy cmt mạc định
    $listcmt = explode("\n", $vipbot['comment']);
    $comment = urlencode($listcmt[array_rand($listcmt)]);
	// lấy cmt sáng
	$cmts = explode("\n", $vipbot['comments']);
    $cmtsang = urlencode($cmts[array_rand($cmts)]);
	// lấy cmt chiều
	$cmtc = explode("\n", $vipbot['commentc']);
    $cmtchieu = urlencode($cmtc[array_rand($cmtc)]);
	// lấy cmt tối
	$cmtt = explode("\n", $vipbot['commentt']);
    $cmttoi = urlencode($cmtt[array_rand($cmtt)]);
	$array = explode('|',$nhandan); // tách stick bằng dấu |
	$nhan = $array[rand(0,count($array) - 1)]; // lấy sticker ngẫu nhiên
	// xuất id không tương tác
	$idchan = explode('|',$chan);
	$id1 = $idchan[0];
	$id2 = $idchan[1];
	$id3 = $idchan[2];
    $fql = "select type,post_id,created_time from stream";
    $fql = $fql." where strpos(created_time,".$time.") >=0 AND source_id in ";
    $fql = $fql."(select uid2 from friend where uid1=me())";
    $fql = "https://api.facebook.com/method/fql.query?query=".urlencode($fql)."&limit=1&format=json&access_token=".$token;
    $json =  json_decode(curl($fql),true);
    if(empty($json[0]['post_id'])){
        $recheck = json_decode(file_get_contents("https://graph.facebook.com/me?fields=id&access_token=".$token),true);
        if(empty($recheck['id'])){
            $cookie= $vipbot['cookie'];
            $url = curl("https://www.facebook.com/".$vipbot['user_id'],$cookie);
            if(preg_match('#access_token:"(.+?)"#is',$url, $_trankynhanit)){
                $token = $_trankynhanit[1];
                mysqli_query($conn, "UPDATE vipreaction SET token='$token' WHERE id=".$vipbot['id']."");
                $fql = "select type,post_id,created_time from stream";
                $fql = $fql." where strpos(created_time,".$time.") >=0 AND source_id in ";
                $fql = $fql."(select uid2 from friend where uid1=me())";
                $fql = "https://api.facebook.com/method/fql.query?query=".urlencode($fql)."&limit='.$litmit.'&format=json&access_token=".$token;
                $json =  json_decode(curl($fql),true);
            }else{
                mysqli_query($conn, "UPDATE vipreaction SET status = 1 WHERE id=".$vipbot['id']."");
            }
        }else{
            $fql = "select type,post_id,created_time from stream";
            $fql = $fql." where strpos(created_time,".$time.") >=0 AND source_id in ";
            $fql = $fql."(select uid2 from friend where uid1=me())";
            $fql = "https://api.facebook.com/method/fql.query?query=".urlencode($fql)."&limit='.$litmit.'&format=json&access_token=".$token;
            $json =  json_decode(curl($fql),true);  
        }
    }
    for($i=0;$i<$litmit; $i++){
        $idstt = $json[$i]['post_id'];
        if($idstt){
            $idu = explode("_", $idstt);
			$chanid = $idu[0];// tìm uid muốn không tương tác.
            $log = file_get_contents('vipBot.txt');
            if (strpos($log, $post['id']) != false) {
                continue;
            } else {// thực thi bot
					if (($id1 && $id2 && $id3) != $chanid){ //nếu tìm không thấy id chặn thì chạy bot
							if ($batcx == 1){
								echo $idstt.'<br>';
								if($camxuc == "LIKE"){
									$kq = postCamXuc($vipbot['user_id'],$idu[0],$token,$idu[1],1);
								}
								if($camxuc == "LOVE"){
									$kq = postCamXuc($vipbot['user_id'],$idu[0],$token,$idu[1],2);    
								}
								if($camxuc == "HAHA"){ 
									$kq = postCamXuc($vipbot['user_id'],$idu[0],$token,$idu[1],4);    
								}
								if($camxuc == "WOW"){
									$kq = postCamXuc($vipbot['user_id'],$idu[0],$token,$idu[1],3);    
								}
								if($camxuc == "SAD"){
									$kq = postCamXuc($vipbot['user_id'],$idu[0],$token,$idu[1],7);    
								}
								if($camxuc == "ANGRY"){
									$kq = postCamXuc($vipbot['user_id'],$idu[0],$token,$idu[1],8);    
								}
								}
								saveFile($vipbot['id'].'||'.$vipbot['user_id'].'||'.$vipbot['name'].'||'.$idstt.'||'.$camxuc.'||'.$today."\n");
								sleep(10);
							
				 // chọn chạy comment theo buổi...
						 if ($batcmt == 1){
							 if ($cmtngay == 0){
								if ($stick == 0){
										 curl('https://graph.fb.me/'.$idstt.'/comments?message='.$comment.'&method=post&access_token='.$token,'null'); 
								}else{
										 curl('https://graph.facebook.com/'.$idstt.'/comments?method=post&message='.$comment.'&attachment_id='.$nhan.'&access_token='.$token.'');
										 
								 }
							 }else{					 
									if (($now > 8) && ($now < 10)){
										$cmt = $cmtsang;
									}
									else if (($now > 12) && ($now < 17)){
										$cmt = $cmtchieu;
									}
									else if (($now > 18) && ($now < 22)){
										$cmt = $cmttoi;
									}else{
										$cmt = $comment;
									}
									if($stick == 0){
										 curl("https://graph.fb.me/".$idstt."/comments?message=".$cmt."&method=post&access_token=".$token,"null"); 
									}else{
										 curl('https://graph.facebook.com/'.$idstt.'/comments?method=post&message='.$cmt.'&attachment_id='.$nhan.'&access_token='.$token.'');
										 
									 }
							 }
							
						}// hết bot comment
					}//chặn id		
			}// hết thả cảm xúc
        }
    }
}// giờ hoạt động
}
function saveFile($id){
	$file = @fopen('vipBot.txt', 'a+');
	@fwrite($file, $id);
	@fclose($file);
}
function curl($url,$cookie){
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $page = curl_exec($ch);
    curl_close($ch);
    return $page;
} 
function post_data($site,$data,$cookie){
    $datapost = curl_init();
    $headers = array("Expect:");
    curl_setopt($datapost, CURLOPT_URL, $site);
    curl_setopt($datapost, CURLOPT_TIMEOUT, 40000);
    curl_setopt($datapost, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    curl_setopt($datapost, CURLOPT_POST, TRUE);
    curl_setopt($datapost, CURLOPT_POSTFIELDS, $data);    
    curl_setopt($datapost, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($datapost, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($datapost, CURLOPT_SSL_VERIFYPEER, FALSE);    
    curl_setopt($datapost, CURLOPT_FOLLOWLOCATION, TRUE);
    ob_start();
    return curl_exec ($datapost);
    ob_end_clean();
    curl_close ($datapost);
    unset($datapost); 
}  
function postCamXuc($my_uid,$target_uid,$token,$post_id,$camxuc){
    $feedback_id = base64_encode("feedback:".$post_id);
    $headers2 = array();
    $headers2[] = 'X-FB-SIM-HNI: 45204';
    $headers2[] = 'X-FB-Net-HNI: 45204';
    $headers2[] = 'Authorization: OAuth '.$token;
    $headers2[] = 'Host: graph.facebook.com';
    $headers2[] = 'X-FB-Connection-Type: WIFI';
    $headers2[] = 'User-Agent: [FBAN/FB4A;FBAV/161.0.0.35.93;FBBV/94117327;FBDM/{density=1.5,width=1280,height=720};FBLC/vi_VN;FBRV/94628452;FBCR/Viettel Telecom;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.katana;FBDV/GT-I9506;FBSV/4.4.2;FBOP/1;FBCA/x86:armeabi-v7a;]';
    $headers2[] = 'Content-Type: application/x-www-form-urlencoded';
    $headers2[] = 'X-FB-Friendly-Name: ViewerReactionsMutation';
    //$headers2[] = 'Accept-Encoding: gzip, deflate';
    $headers2[] = 'X-FB-HTTP-Engine: Liger';
    $headers2[] = 'Connection: close';
    $data = 'doc_id=1664629946906286&method=post&locale=vi_VN&pretty=false&format=json&variables={"0":{"tracking":["{\"top_level_post_id\":\"'.$post_id.'\",\"tl_objid\":\"'.$post_id.'\",\"throwback_story_fbid\":\"'.$post_id.'\",\"profile_id\":\"'.$target_uid.'\",\"profile_relationship_type\":2,\"actrs\":\"'.$target_uid.'\"}","{\"image_loading_state\":3,\"time_since_fetched\":'.time().',\"radio_type\":\"wifi-none\",\"client_viewstate_position\":0}"],"feedback_source":"native_timeline","feedback_reaction":'.$camxuc.',"client_mutation_id":"ce52e651-5e23-4068-8367-696b8e3f045f","nectar_module":"timeline_ufi","actor_id":"'.$my_uid.'","feedback_id":"'.$feedback_id.'","action_timestamp":'.time().'}}&fb_api_req_friendly_name=ViewerReactionsMutation&fb_api_caller_class=graphservice';
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, "https://graph.facebook.com/graphql");
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($c, CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);  
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_HTTPHEADER, $headers2);
    curl_setopt($c,CURLOPT_POST, 1);
    curl_setopt($c,CURLOPT_POSTFIELDS,$data);
    $page = curl_exec($c);
    curl_close($c);
    return $page;
}
?>