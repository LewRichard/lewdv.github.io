<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
} else {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "UPDATE member SET password = 111111 WHERE id_ctv = $id";
        if (mysqli_query($conn, $sql)) {
            echo "<script>swal({html: true,title: 'Thành công',text: 'Mật khẩu mới là 6 số 1: 111111',type: 'success',});</script>";
            echo '<meta http-equiv=refresh content="1; URL=/index.php?action=user">';
        } else {
			echo "<script>alert('This click can not be performed'); window.location='/index.php';</script>";
        }
    }
}
?>