<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
} else {
    if (isset($_GET['id'], $_GET['type'])) {
        $id = $_GET['id'];
        if ($_GET['type'] == 'lock') {
            $sql = "UPDATE member SET status = -1 WHERE id_ctv = $id";
            if (mysqli_query($conn, $sql)) {
                echo "<script>window.location='/index.php?action=user';</script>";
            }
        } else if ($_GET['type'] == 'unlock') {
            $sql = "UPDATE member SET status = 1 WHERE id_ctv = $id";
            if (mysqli_query($conn, $sql)) {
                echo "<script>window.location='/index.php?action=user';</script>";
            }
        } else {
			echo "<script>alert('This click can not be performed'); window.location='/index.php';</script>";
        }
    }
}
?>