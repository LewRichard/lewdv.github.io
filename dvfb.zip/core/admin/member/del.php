<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
} else {
    if (isset($_GET['id']) && ($uname == $accoutadmin)) {
        $id = $_GET['id'];
        $get = "SELECT username FROM member WHERE id_ctv = $id";
        $result = mysqli_query($conn, $get);
        $x = mysqli_fetch_assoc($result);
       // $name = $x['name'];
        $u_name = $x['username'];
        $xoahis = "DELETE FROM history WHERE id_ctv = $id";
        mysqli_query($conn, $xoahis);
        mysqli_query($conn, "DELETE FROM shoutbox WHERE user_id = $id");
        $xoa = "DELETE FROM member WHERE id_ctv = $id";
        if (mysqli_query($conn, $xoa)) {
            header('Location: /index.php?action=user');
        }
    }
}
?>