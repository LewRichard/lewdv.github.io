<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php $titles="XÓA DIE TOKEN";?>
<!--<script>
    function del(token, table) {
        $(function () {
            $.getJSON('https://graph.fb.me/me?access_token=' + token + '&method=get&fields=id', function () {
                console.log('success');
            }).fail(function () {
                $('#del').load('<?=$domain;?>/core/admin/progresss.php?table=' + table + '&token=' + token);
            });
        });
    }
</script>-->
<script>
function del(token,table){
    $(function(){
    	$.getJSON('https://graph.fb.me/me?access_token='+token+'&method=get', function(){
    		console.log('success');
    	}).fail(function(){
    		$('#del').load('<?=$domain;?>/core/admin/progresss.php?table='+table+'&token='+token);
    	});
    });
}
</script>
<?php
if (isset($_POST['submit'])) {
    $table = $_POST['table'];
    $sql = "SELECT access_token FROM $table ORDER BY RAND()";
    $result = mysqli_query($conn, $sql);
    while ($r = mysqli_fetch_assoc($result)) {
        $token = trim($r['access_token']);
        echo "<script>del('$token','$table');</script>";
    }
}
?>
<?php
$getlike = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike");
$like = mysqli_fetch_assoc($getlike)['COUNT(*)'];

$getlike2 = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike2");
$like2 = mysqli_fetch_assoc($getlike2)['COUNT(*)'];

$getlike3 = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike3");
$like3 = mysqli_fetch_assoc($getlike3)['COUNT(*)'];

$getlike4 = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike4");
$like4 = mysqli_fetch_assoc($getlike4)['COUNT(*)'];

?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
                <div class="form-group">
                    <label for="token">Chọn Table Muốn Xóa:</label>
                    <select name="table" class="form-control" style="display: inline;width:200px">
                        <option value="tokenlike">SERVER 1 (<?=$like;?>)</option>
                        <option value="tokenlike2">SERVER 2 (<?=$like2;?>)</option>
                        <option value="tokenlike3">SERVER 3 (<?=$like3;?>)</option>
						<option value="tokenlike4">SERVER 4 (<?=$like4;?>)</option>
                    </select>
                </div>
            <div id="del" style="color:red"></div>
        </div>
        <div class="panel-footer">
            <button type="submit" name="submit" class="btn btn-success">Xác nhận</button>
        </div>
            </form>
    </div>
</div>