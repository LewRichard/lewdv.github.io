<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
if(isset($_GET['update'])) {
    $id = $_GET['update'];
    $get = "SELECT * FROM package WHERE id=$id";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: /index.php?action=trang-loi');
        }
    }
?>
<?php $titles='CẬP NHẬT';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3></div>
        <div class="panel-body">
            <form method="post">
    <?php
    if (isset($_POST['submit'])){
        $name_likes = $_POST['name_likes'];
        $max = $_POST['max'];
        $price = $_POST['price'];
        $sql = "UPDATE package SET price='$price', max='$max', name_likes='$name_likes' WHERE id=$id";
        if(mysqli_query($conn, $sql)){
            echo "<script>window.location='/index.php?action=list-like';</script>";
        }
    }
    ?>
                <div class="form-group">
                    <label>Giới hạn Like</label>
                    <input type="number" name="max" class="form-control" value="<?=$x['max'];?>" required>
                </div>
                <div class="form-group">
                    <label>Tên gói Like</label>
                    <input type="text" name="name_likes" class="form-control" value="<?=$x['name_likes'];?>" required>
                </div>
                <div class="form-group">
                    <label>Giá tiền</label>
                    <input type="number" name="price" class="form-control" value="<?=$x['price'];?>" required>
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success">Cập nhật</button>
            <a class="btn btn-primary waves-effect waves-light" href="/index.php?action=list-like">Quay lại</a>
        </div>
            </form>
    </div>
</div>
<?php }else{ ?>
<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php
if (isset($_POST['submit'])) {
    $loi = array();
    $get_max = "SELECT max FROM package WHERE type='LIKE'";
    $r_max = mysqli_query($conn, $get_max);
    while ($max = mysqli_fetch_assoc($r_max)) {
        foreach ($_POST['max_like'] as $max_like) {
            if ($max['max'] == $max_like) {
                $loi['exists'] = '<font color="red">Đã tồn tại package này</font>';
            }
        }
    }
    if (empty($loi)) {
        $name_likes = $_POST['name_likes'];
        $max_like = $_POST['max_like'];
        $gia_tien = $_POST['gia_tien'];
        $sql = "INSERT INTO package(price, max, name_likes, id_ctv, type) VALUES('$gia_tien', '$max_like', '$name_likes', '$idctv', 'LIKE')";
        if (mysqli_query($conn, $sql)) {
            echo "<script>window.location='';</script>";
        }
    }
}
?>
<?php $titles='QUẢN LÝ GÓI LIKE';?>
<script>
    function check(id) {
        if (confirm('Bạn có chắc chắn muốn xóa package này ?') == true) {
            window.location = '<?=$domain?>/index.php?action=list-like&xoa=' + id;
        } else {
            return false;
        }
    }
</script>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?> | <a href="#packagelike" data-toggle="modal" class="btn btn-danger">Thêm</a></h3></div>
        <div class="panel-body">
            <table class="table">
                <thead>
                    <tr style="color:#006699" role="row">
                        <th>#</th>
                        <th>Giới hạn Like</th>
                        <th>Giá tiền</th>
                        <th>Tên gói</th>
                        <th>Công cụ</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $a = 0;
                $get = "SELECT * FROM package WHERE type='LIKE'";
                $r_like = mysqli_query($conn, $get);
                while ($x = mysqli_fetch_assoc($r_like)) {
                    $member = $x['price'];
                    $id = $x['id'];
                    $agency = $x['price'] - $x['price'] * 20 / 100;
                    $ctv = $x['price'] - $x['price'] * 10 / 100;
                    $a = $a+1;
                ?>
                    <tr>
                        <td><? echo $a; ?></td>
                        <td><?php echo $x['max']; ?> Likes</td>
                        <td><?php echo number_format($x['price']); ?> VNĐ</td>
                        <td><?php echo "{$x['name_likes']}"; ?></td>
                        <td style="text-align:center">
                            <a href="<?=$domain;?>/index.php?action=list-like&update=<?=$id;?>" class="btn btn-info btn-xs">Chỉnh sửa</a> 
                            <a href="#" onclick="check(<?=$id;?>);" class="btn btn-danger btn-xs">Xóa</a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
        <div id="packagelike" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h3 class="modal-title">Thêm mới</h3>
                    </div>
                    <div class="modal-body">
            <form action="#" method="post">
                <div class="box-body" id="list">
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Max Like</label>
                                <input type="number" max="10000" name="max_like" class="form-control" placeholder="Nhập max like cho gói like này" required/>
                                <b><?php echo isset($loi['exists']) ? $loi['exists'] : ''; ?></b>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Giá tiền</label>
                                <input type="number" max="1000000" name="gia_tien" class="form-control" placeholder="Nhập giá tiền cho gói like này" required/>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Tên Gói</label>
                                <input type="text" name="name_likes" class="form-control" placeholder="Nhập tên cho gói like này" required/>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="submit" class="btn btn-primary">Xác nhận</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                </div>
            </form>
                    </div>
                </div>
            </div>
		</div>
<?php
if(isset($_GET['xoa'])){
    $id = $_GET['xoa'];
    $get = "SELECT id_ctv FROM package WHERE id = $id AND type='LIKE'";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    if($uname != $accoutadmin){
        echo "<script>window.location='/index.php?action=trang-loi';</script>";
    }else{
        $xoa = "DELETE FROM package WHERE id=$id";
        if(mysqli_query($conn, $xoa)){
            echo "<script>window.location='/index.php?action=list-like';</script>";
        }
    }
}
?>
<?php } ?>