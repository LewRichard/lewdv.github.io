<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php
   if(isset($_GET['update'])){
       $id = $_GET['update'];
       $get = "SELECT * FROM package WHERE id= $id AND type='REACTION'";
       $result = mysqli_query($conn, $get);
       $x = mysqli_fetch_assoc($result);
       if($uname != $accoutadmin){
        if($x['id_ctv'] != $idctv){
            echo "window.location='/index.php?action=trang-loi';</script>";
        }
       }
   if(isset($_POST['submit'])){
      $name_likes = $_POST['name_likes'];
      $max_reaction = $_POST['max_reaction'];
      $price = $_POST['price'];
      $sql = "UPDATE package SET price='$price', max='$max_reaction', name_likes='$name_likes' WHERE id=$id";
      if(mysqli_query($conn, $sql)){
        echo "<script>window.location='/index.php?action=list-reaction';</script>";
      }
   }
?>
<?php $titles='CẬP NHẬT';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3></div>
        <div class="panel-body">
            <form method="post">
                <div class="form-group">
                    <label for="user_id">Giới hạn:</label>
                    <input type="number" name="max_reaction" max="10000" class="form-control" value="<?php echo isset($x['max']) ? $x['max'] : ''; ?>" required="" />
                </div>
                <div class="form-group">
                    <label>Tên gói:</label>
                    <input type="text" name="name_likes" class="form-control" value="<?php echo isset($x['name_likes']) ? $x['name_likes'] : ''; ?>" placeholder="">
                </div>
                <div class="form-group">
                    <label for="profile">Giá:</label>
                    <input type="number" name="price" class="form-control" max="1000000" value="<?php echo isset($x['price']) ? $x['price'] : ''; ?>" required="" />
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success">Cập nhật</button>
            <a class="btn btn-primary waves-effect waves-light" href="/index.php?action=list-reaction">Quay lại</a>
        </div>
            </form>
    </div>
</div>
<?php }else if(isset($_GET['xoa'])){
    $id = $_GET['xoa'];
    $get = "SELECT id_ctv FROM package WHERE id = $id AND type='REACTION'";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    if($uname != $accoutadmin){
        echo "<script>window.location='/index.php?action=trang-loi';</script>";
    }else{
        $xoa = "DELETE FROM package WHERE id=$id";
        if(mysqli_query($conn, $xoa)){
            echo "<script>window.location='/index.php?action=list-reaction';</script>";
        }
    }
    }else{
?>
<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php $titles='QUẢN LÍ GÓI BOT';?>
<?php
if (isset($_POST['submit'])) {
    $loi = array();
    $get_max = "SELECT max FROM package WHERE type='REACTION'";
    $r_max = mysqli_query($conn, $get_max);
    while ($max = mysqli_fetch_assoc($r_max)) {
        foreach ($_POST['max_reaction'] as $max_react) {
            if ($max['max'] == $max_react) {
                $loi['exists'] = '<font color="red">Đã tồn tại package này</font>';
            }
        }
    }
    if (empty($loi)) {
        $name_likes = $_POST['name_likes'];
        $max_reaction = $_POST['max_reaction'];
        $gia_tien = $_POST['gia_tien'];
        $sql = "INSERT INTO package(price, max, name_likes, id_ctv, type) VALUES('$gia_tien', '$max_reaction', '$name_likes', '$idctv', 'REACTION')";
        if (mysqli_query($conn, $sql)) {
            echo "<script>window.location='/index.php?action=list-reaction';</script>";
        }
    }
}
?>
<script>
    function check(id) {
        if (confirm('Bạn có chắc chắn muốn xóa package này ?') == true) {
            window.location = '<?=$domain;?>/index.php?action=list-reaction&xoa='+id+'';
        } else {
            return false;
        }
    }
</script>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?> | <a href="#packagereaction" data-toggle="modal" class="btn btn-danger">Thêm</a></h3></div>
        <div class="panel-body">
            <table id="example1" class="table table-striped table-bordered">
                <thead>
                    <tr style="color:#006699" role="row">
                        <th>#</th>
                        <th>Giới hạn</th>
                        <th>Giá tiền</th>
                        <th>Tên gói</th>
                        <th>Công cụ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $a = 0;
                    $get = "SELECT * FROM package WHERE type='REACTION'";
                    $result = mysqli_query($conn, $get);
                    while ($x = mysqli_fetch_assoc($result)) {
                        $id = $x['id'];
                        if(isset($x['name'], $x['username'])){
                            $name = $x['name'];
                            $u_name = $x['username'];
                        }
                        $a = $a+1;
                    ?>
                    <tr>
                        <td><? echo $a; ?></td>
                        <td><?php echo $x['max']; ?> Reaction</td>
                        <td><?php echo number_format($x['price']); ?> VNĐ</td>
                        <td><?php echo $x['name_likes']; ?></td>
                        <td style="text-align:center">
                            <a href="<?=$domain;?>/index.php?action=list-reaction&update=<?php echo $id; ?>" class="btn btn-info btn-xs">Chỉnh sửa</a> 
                            <a href="#" onclick="check(<?=$id;?>);" class="btn btn-danger btn-xs">Xóa</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
        <div id="packagereaction" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h3 class="modal-title">Thêm mới</h3>
                    </div>
                    <div class="modal-body">
            <form action="#" method="post">
                <div class="box-body" id="list">
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Max Reaction</label>
                                <input type="number" max="10000" name="max_reaction" class="form-control" placeholder="eg. 1" required/>
                                <b><?php echo isset($loi['exists']) ? $loi['exists'] : ''; ?></b>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Giá tiền</label>
                                <input type="number" max="1000000" name="gia_tien" class="form-control" placeholder="eg. 50000" required/>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Tên Gói</label>
                                <input type="text" name="name_likes" class="form-control" placeholder="eg. Gói tương tác một tháng" required/>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="submit" class="btn btn-primary">Xác nhận</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                </div>
            </form>
                    </div>
                </div>
            </div>
		</div>
<?php } ?>