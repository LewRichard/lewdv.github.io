<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php $titles='CẤU HÌNH HỆ THỐNG';?>
<?php
$get = "SELECT * FROM setting";
$result = mysqli_query($conn, $get);
$x = mysqli_fetch_assoc($result);
?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
<?php
if (isset($_POST['submit'])) {
    $tile = addslashes($_POST['tile']);
    $logo = addslashes($_POST['logo']);
    $script = addslashes($_POST['script']);
    $keyword = addslashes($_POST['keyword']);
    $dangky = addslashes($_POST['dangky']);
    $ratelike = addslashes($_POST['ratelike']);
    $ratecmt = addslashes($_POST['ratecmt']);
    $rateshare = addslashes($_POST['rateshare']);
    $ratesub = addslashes($_POST['ratesub']);
    $check = mysqli_query($conn, "SELECT COUNT(*) FROM setting");
    $getcheck = mysqli_fetch_assoc($check);
    $res = $getcheck['COUNT(*)'];
    if($res == 0){
        mysqli_query($conn, "INSERT INTO setting SET tile='".$tile."', script='".$script."', keyword='".$keyword."', logo='".$logo."', dangky='".$dangky."', ratelike='".$ratelike."', ratesub='".$ratesub."', ratecmt='".$ratecmt."', rateshare='".$rateshare."'");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thành công',type: 'success',});</script>";
        echo '<meta http-equiv=refresh content="1; URL=/index.php?action=setting">';
    }else{
        mysqli_query($conn, "UPDATE setting SET tile='".$tile."', script='".$script."', keyword='".$keyword."', logo='".$logo."', dangky='".$dangky."', ratelike='".$ratelike."', ratesub='".$ratesub."', ratecmt='".$ratecmt."', rateshare='".$rateshare."'");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thành công',type: 'success',});</script>";
        echo '<meta http-equiv=refresh content="1; URL=/index.php?action=setting">';
    }
}
?>
                <p>Tiêu đề trang</p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="tile" class="form-control" type="text" value="<?=$x['tile'];?>">
                    </div>
                </div>
                <p>Đường dẫn logo</p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="logo" class="form-control" type="text" value="<?=$x['logo'];?>">
                    </div>
                </div>
                <p>Từ khóa Giúp Nỗi Bật </p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="keyword" class="form-control" type="text" value="<?=$x['keyword'];?>">
                    </div>
                </div>
                <p>Rate Like </p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="ratelike" class="form-control" type="text" value="<?=$x['ratelike'];?>">
                    </div>
                </div>
                <p>Rate Cmt </p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="ratecmt" class="form-control" type="text" value="<?=$x['ratecmt'];?>">
                    </div>
                </div>
                <p>Rate Share </p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="rateshare" class="form-control" type="text" value="<?=$x['rateshare'];?>">
                    </div>
                </div>
                <p>Rate Sub </p>
                <div class="form-group">
                    <div class="form-line">
                        <input name="ratesub" class="form-control" type="text" value="<?=$x['ratesub'];?>">
                    </div>
                </div>
                <p>Script chat hay gì gì đó</p>
                <div class="form-group">
                    <div class="form-line">
                        <textarea class="form-control" name="script" rows="10"><?=$x['script'];?></textarea>
                    </div>
                </div>
                <b>Cho phép người dùng đăng ký</b>
                <div class="form-group demo-radio-button">
                    <input name="dangky" id="0" class="radio-col-red" value="0" type="radio" <?php if($x['dangky']==0){ ?> checked="checked"  <?php } ?>>   
                    <label for="0">Không</label>
                    <input name="dangky" id="1" class="radio-col-red" value="1" type="radio" <?php if($x['dangky']==1){ ?> checked="checked" <?php } ?>>
                    <label for="1">Có</label>
                </div>
        </div>
        <div class="panel-footer">
            <button type="submit" name="submit" class="btn btn-success">XÁC NHẬN</button>
        </div>
            </form>
    </div>
</div>