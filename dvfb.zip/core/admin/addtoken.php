<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php $titles="THÊM TOKEN VÀO HỆ THỐNG";?>
<script>
    function add(){
        $('#submit').removeClass('btn btn-primary').addClass('btn btn-info').html('<i class="fa fa-spinner fa-spin"></i> Đang thêm token...').attr('disabled','disabled');
        var table = $('#table').val();
        var token = $('#token').val().split("\n");
        var success = 0; fail = 0;
        $('#total').fadeIn('slow').text('Tổng cộng: '+token.length);
        for(let i = 0; i < token.length; i++){
            if(table != 'share'){
                $.getJSON('https://graph.fb.me/me?access_token='+token[i]+'&fields=id,name,gender&method=get',function(ds){
                    $.post('<?=$domain;?>/core/admin/progress.php', {gender: ds.gender, tb: table, uid: ds.id, name: encodeURIComponent(ds.name), t: token[i]}, function(response){
                        if(response == 'success'){
                            success++;
                            $('#success').fadeIn('slow').text('Success: '+success);
                        }else{
                            fail++;
                            $('#fail').fadeIn('slow').text('Thành công: '+fail);
                        }
                    })
                }).fail(function(){
                    fail++;
                    $('#fail').fadeIn('slow').text('Thất bại: '+fail);
                });
                if((i+1) == token.length){
                    $('#token').val('');
                    $('#submit').removeClass('btn btn-info').addClass('btn btn-primary').text('Thêm tiếp').removeAttr('disabled');
                }
            }
        }
    }
</script>
<?php
$getlike = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike");
$like = mysqli_fetch_assoc($getlike)['COUNT(*)'];

$getlike2 = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike2");
$like2 = mysqli_fetch_assoc($getlike2)['COUNT(*)'];

$getlike3 = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike3");
$like3 = mysqli_fetch_assoc($getlike3)['COUNT(*)'];

$getlike4 = mysqli_query($conn,"SELECT COUNT(*) FROM tokenlike4");
$like4 = mysqli_fetch_assoc($getlike4)['COUNT(*)'];

?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3></div>
        <div class="panel-body">
            <div class="form-group">
                <label for="table">Chọn Table cần thêm token:</label>
                <select name="table" id="table" class="form-control">
                    <option value="tokenlike" <?php echo (isset($_POST['table']) && $_POST['table'] == 'tokenlike') ? 'selected' : ''; ?>>SERVER 1 (<?=$like;?>)</option>
                    <option value="tokenlike2" <?php echo (isset($_POST['table']) && $_POST['table'] == 'tokenlike2') ? 'selected' : ''; ?>>SERVER 2 (<?=$like2;?>)</option>
                    <option value="tokenlike3" <?php echo (isset($_POST['table']) && $_POST['table'] == 'tokenlike3') ? 'selected' : ''; ?>>SERVER 3 (<?=$like3;?>)</option>
					<option value="tokenlike4" <?php echo (isset($_POST['table']) && $_POST['table'] == 'tokenlike4') ? 'selected' : ''; ?>>SERVER 4 (<?=$like4;?>)</option>
                    
				</select>
            </div>
            <div class="form-group">
                <label for="token">List token:</label>
                <textarea name="token" id="token" class="form-control" rows="15" placeholder="Mỗi token 1 dòng"><?=$_POST['token'];?></textarea>
            </div>
        </div>
        <div class="panel-footer">
            <button type="submit" onclick="add()" id="submit" class="btn btn-success">Xác nhận</button>
            <button type="button" id="total" class="btn btn-default" style="display:none"></button>
            <button type="button" id="success" class="btn btn-success" style="display:none"></button>
            <button type="button" id="fail" class="btn btn-danger" style="display:none"></button>
        </div>
    </div>
</div>