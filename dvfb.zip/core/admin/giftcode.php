<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php $titles='QUẢN LÝ GIFT CODE';?>
<?php
$get = "SELECT * FROM setting";
$result = mysqli_query($conn, $get);
$x = mysqli_fetch_assoc($result);
?>
<div class="col-md-6">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
<?php
if (isset($_POST['submit'])){
    $soluong = $_POST['soluong'];
    $monney = $_POST['monney'];
    if($soluong < 0){
        echo "<script>swal({html: true,title: 'Lỗi',text: 'Số lượng không hợp lệ.',type: 'error',});</script>";
    }else if(!$soluong){
        echo "<script>swal({html: true,title: 'Lỗi',text: 'Vui lòng điền số lượng.',type: 'error',});</script>";
    }else if(!$monney){
        echo "<script>swal({html: true,title: 'Lỗi',text: 'Vui lòng điền giá tiền.',type: 'error',});</script>";
    }else if($monney < 0){
        echo "<script>swal({html: true,title: 'Lỗi',text: 'Giá tiền không hợp lệ.',type: 'error',});</script>";
    }else{
        for($i=0;$i<$soluong;$i++){
            $code = randma(20);
            mysqli_query($conn, "INSERT INTO giftcode(code, monney, type) VALUES ('$code', '$monney', '0')");
        }
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thêm thành công $soluong mã nhận thưởng vào hệ thống.',type: 'success',});</script>";
    }
}
function randma($length) {
    $characters = '0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>
            <div class="form-group">
                <label for="soluong">Số lượng</label>
                <input class="form-control" type="number" name="soluong" value="<?=$_POST['soluong'];?>" placeholder="Nhập số lượng..." required>
            </div>
            <div class="form-group">
                <label for="monney">Giá tiền</label>
                <input class="form-control" type="number" name="monney" value="<?=$_POST['monney'];?>" placeholder="Nhập số tiền..." required>
            </div>
        </div>
        <div class="panel-footer">
            <button type="submit" name="submit" class="btn btn-success">Xác nhận</button>
        </div>
            </form>
    </div>
</div>
<div class="col-md-6">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">DANH SÁCH MÃ CODE</h3>
        </div>
            <div class="panel-body">
                <div class="slimscrollleft">
                    <div class="table-responsive">
                        <table class="table table-responsive">
                            <thead>
                                <tr style="color:#006699" role="row">
                                    <th>#</th>
                                    <th>Code</th>
                                    <th>Số tiền</th>
                                    <th>Trạng thái</th>
                                    <th>Công cụ</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $a = 0;
                            $get = "SELECT * FROM giftcode";
                            $result = mysqli_query($conn, $get);
                            while ($x = mysqli_fetch_assoc($result)) {
                                if($x['type'] == 0){
                                    $type = '<a class="btn btn-success">Chưa sử dụng</a>';
                                }else if($x['type'] == 1){
                                    $type = '<a class="btn btn-danger">Đã sử dụng</a>';
                                }
                                $a = $a + 1;
                            ?>
                                <tr>
                                    <td><?=$a;?></td>
                                    <td><?=$x['code'];?></td>
                                    <td><?=number_format($x['monney']);?></td>
                                    <td><?=$type;?></td>
                                    <td style="text-align:center"><a onclick="xoa(<?= $x['id'];?>)" class="btn btn-danger" href="javascript:void(0)">Xóa</a></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
<script>
    function xoa(id) {
        if (confirm('Bạn có chắc xóa id này?') == true) {
            window.location = '<?=$domain;?>/index.php?action=gift-code-admin&id=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    if ($uname != $accoutadmin) {
        echo "<script>window.location='/index.php?action=trang-loi';</script>";
    }else{
        mysqli_query($conn, "DELETE FROM giftcode WHERE id = $id");
        echo "<script>window.location='/index.php?action=gift-code-admin';</script>";
    }
}
?>