<?php $titles='THÔNG TIN';?>
<?php
if ($n['status'] < 1) {
    echo "<script>alert('Tài khoản chưa kích hoạt.!');window.location='/index.php';</script>";
}
?>
<?php
    $get = "SELECT * FROM member WHERE id_ctv=$idctv";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    $username=$x['username'];
    $pass=$x['password'];
	$level=$x['level'];
?>
<div class="row">
    <div class="col-sm-12">
        <div class="bg-picture text-center" style="background-image:url('https://brandthunder.com/wp/wp-content/uploads/2015/02/shooting-star-fb-cover-photo.jpg')">
            <div class="bg-picture-overlay"></div>
            <div class="profile-info-name">
                <img src="https://graph.facebook.com/<?=$idfb;?>/picture?width=90&height=90" class="thumb-lg img-circle img-thumbnail" alt="profile-image">
                <h3 class="text-success"><b><?=$uname;?> <i class="fa fa-check-circle" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Tài khoản này đã được xác minh"></i></b></h3>
				<?php
	if($level == 2){
		echo '<font color=white>(Cộng Tác Viên)</font>';
	}elseif($level == 3){
		echo '<font color=white>(Đại Lý)</font>';
	}elseif($level == 4){
		echo '<font color=white>(Tổng Đại Lý)</font>';
	}
	else{
		echo '<font color=white>(Thành Viên)</font>';
	}
				?>
            </div>
        </div>
        <!--/ meta -->
    </div>
    <div class="row user-tabs">
        <div class="col-sm-9 col-lg-6">
            <ul class="nav nav-tabs tabs" style="width: 100%;">
                <li class="tab active" style="width: 25%;">
                    <a href="#home-2" data-toggle="tab" aria-expanded="true" class="active">
                        <span class="visible-xs"><i class="fa fa-home"></i></span>
                        <span class="hidden-xs">Thông tin cá nhân</span>
                    </a>
                </li>
                <li class="tab" style="width: 25%;">
                    <a href="#messages-2" data-toggle="tab" aria-expanded="true">
                        <span class="visible-xs"><i class="fa fa-envelope-o"></i></span>
                        <span class="hidden-xs">Chỉnh sửa thông tin</span>
                    </a>
                </li>
                <li class="tab" style="width: 25%;">
                    <a href="#settings-2" data-toggle="tab" aria-expanded="false">
                        <span class="visible-xs"><i class="fa fa-cog"></i></span>
                        <span class="hidden-xs">Đổi mật khẩu</span>
                    </a>
                </li>
                <div class="indicator" style="right: 381px; left: 0px;"></div>
                <div class="indicator" style="right: 381px; left: 0px;"></div>
            </ul>
        </div>
    </div>
</div>
<?php
if(isset($_POST['submit'])){
	if($idctv == 12){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Chức năng không khả dụng cho tài khoản này!.</font</h4></div>';
	}else{
	$checkid = "SELECT id_ctv FROM member WHERE id_ctv = $idctv";
    $resultid = mysqli_query($conn, $checkid);
    $x = mysqli_fetch_assoc($resultid);
	$idboss = $x['id_ctv'];
	$boss = $_POST['boss'];
    $email = $_POST['email'];
    $sdt = $_POST['sdt'];
    $idfb = $_POST['idfb'];
    if(!$email){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng nhập Email.</font</h4></div>';
    }else if($boss == $idboss){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Không thể chọn bạn làm Đại Lý.</font</h4></div>';
    }else if(!$sdt){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng nhập số điện thoại.</font</h4></div>';
    }else if(!$idfb){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng nhập UID facebook.</font</h4></div>';
    }else if(mysqli_query($conn, "UPDATE member SET email='$email', sdt='$sdt', idfb='$idfb', boss='$boss' WHERE id_ctv=$idctv")){
		echo '<div class="panel-footer"><h4><font color="green">* Thông báo:<br>- Cập nhật thông tin thành công.</font</h4></div>';
    }
}
}
?>
<?php
if(isset($_POST['change'])){
	if($idctv == 12){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Chức năng không khả dụng cho tài khoản này!.</font</h4></div>';
	}else{
    $old_pass = $_POST['old_pass'];
    $new_pass1 = $_POST['new_pass1'];
    $new_pass2 = $_POST['new_pass2'];
    $get = "SELECT password FROM member WHERE id_ctv = $idctv";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    if(!$old_pass || !$new_pass1 || !$new_pass2){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng điền đầy đủ thông tin.</font</h4></div>';
    }else if($x['password'] != $old_pass){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Mật khẩu cũ không đúng.</font</h4></div>';
    }else if(($old_pass == $new_pass1) && ($old_pass == $new_pass2)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Mật khẩu mới không được trùng với mật khẩu cũ.</font</h4></div>';
    }else if(strcmp($new_pass1, $new_pass2) != 0){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Nhập lại mật khẩu mới không trùng nhau.<br></font</h4></div>';
    }else if(mysqli_query($conn, "UPDATE member SET password='$new_pass1' WHERE id_ctv=$idctv")){
		echo '<div class="panel-footer"><h4><font color="green">* Thông báo:<br>- Đổi mật khẩu thành công.</font</h4></div>';
    }
}
}
?>
    <div class="row">
        <div class="col-lg-12">
            <div class="tab-content profile-tab-content">
                <div class="tab-pane active" id="home-2" style="display: block;">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="panel panel-default panel-fill">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Thông tin cá nhân</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="about-info-p">
                                        <strong>Tên đăng nhập</strong>
                                        <br>
                                        <p class="text-muted">
                                            <?=$uname;?>
                                        </p>
                                    </div>
                                    <div class="about-info-p">
                                        <strong>Số điện thoại</strong>
                                        <br>
                                        <p class="text-muted">
                                            <?=$sdt;?>
                                        </p>
                                    </div>
                                    <div class="about-info-p">
                                        <strong>Email</strong>
                                        <br>
                                        <p class="text-muted">
                                            <?=$email;?>
                                        </p>
                                    </div>
                                    <div class="about-info-p m-b-0">
                                        <strong>Địa điểm</strong>
                                        <br>
                                        <p class="text-muted"><?=$diachi;?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="panel panel-default panel-fill">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Trạng thái hệ thống</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="m-b-15">
                                        <h5>VIP LIKE<span class="pull-right">90%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-primary wow animated progress-animated" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%; visibility: hidden; animation-name: none;">
                                                <span class="sr-only">90% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m-b-15">
                                        <h5>VIP BOT <span class="pull-right">100%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-pink wow animated progress-animated" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%; visibility: hidden; animation-name: none;">
                                                <span class="sr-only">100% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                <!--    <div class="m-b-15">
                                        <h5>VIP REP CMT <span class="pull-right">80%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-purple wow animated progress-animated" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%; visibility: hidden; animation-name: none;">
                                                <span class="sr-only">80% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m-b-0">
                                        <h5>Hệ thống Vip Rep<span class="pull-right">95%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-info wow animated progress-animated" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 95%; visibility: hidden; animation-name: none;">
                                                <span class="sr-only">95% Complete</span>
                                            </div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="messages-2" style="display: none;">
                    <div class="panel panel-default panel-fill">
                        <div class="panel-heading">
                            <h3 class="panel-title">Chỉnh sửa thông tin</h3>
                        </div>
                        <div class="panel-body">
                            <form method="post">
					<?php
							$checkdl = "SELECT boss FROM member WHERE id_ctv = $idctv";
							$resultdl = mysqli_query($conn, $checkdl);
							$x = mysqli_fetch_assoc($resultdl);
							$chekboss = $x['boss'];
							$checkdl2 = "SELECT username,sdt FROM member WHERE id_ctv = $chekboss";
							$resultdl2 = mysqli_query($conn, $checkdl2);
							$x = mysqli_fetch_assoc($resultdl2);
							$nameboss = $x['username'];
							$sdtboss = $x['sdt'];
							if($chekboss <= 0){
								?>	<div class="form-group">
                                    <label for="boss">* Nhập ID của Đại Lý (nếu không thì để trống)* Chỉ được chọn 1 lần duy nhất</label>
                                    <input type="number" class="form-control" id="boss" placeholder="Nhập ID của Đại Lý hoặc Tổng Đại Lý..." name="boss" value="<?=$boss;?>">
                                </div>
                                <div class="form-group">
                                    <label for="sdt">* Email</label>
                                    <input type="email" class="form-control" id="sdt" placeholder="Nhập Email..." name="email" value="<?=$email;?>">
                                </div>
                                <div class="form-group">
                                    <label for="sdt">* Số điện thoại</label>
                                    <input type="number" class="form-control" id="sdt" placeholder="Số điện thoại..." name="sdt" value="<?=$sdt;?>">
                                </div>
                                <div class="form-group">
                                    <label for="idfb">* ID Facebook</label>
                                    <input type="number" class="form-control" id="idfb" placeholder="ID Facebook..." name="idfb" value="<?=$idfb;?>">
                                </div>
							<?php }else{ ?>
							<div class="form-group">
                                    <label>* Đại Lý hiện tại của bạn là: <?php echo "<font color='green'>$nameboss - Số điện thoại: $sdtboss</font>"; ?></label>
                                </div>
							<div class="form-group">
                                    <label for="sdt">* Email</label>
                                    <input type="email" class="form-control" id="sdt" placeholder="Nhập Email..." name="email" value="<?=$email;?>">
                                </div>
                                <div class="form-group">
                                    <label for="sdt">* Số điện thoại</label>
                                    <input type="number" class="form-control" id="sdt" placeholder="Số điện thoại..." name="sdt" value="<?=$sdt;?>">
                                </div>
                                <div class="form-group">
                                    <label for="idfb">* ID Facebook</label>
                                    <input type="number" class="form-control" id="idfb" placeholder="ID Facebook..." name="idfb" value="<?=$idfb;?>">
                                </div>
							<?php } ?>
							
                                <button name="submit" class="btn btn-purple waves-effect waves-light btn-block">Cập nhật thông tin</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="settings-2" style="display: none;">
                    <div class="panel panel-default panel-fill">
                        <div class="panel-heading">
                            <h3 class="panel-title">Đổi mật khẩu</h3>
                        </div>
                        <div class="panel-body">
                            <form method="post">
                                <div class="form-group">
                                    <label for="oldpass">* Mật khẩu cũ</label>
                                    <input type="text" class="form-control" id="old_pass" name="old_pass" value="<?=$_POST['old_pass'];?>" placeholder="Nhập mật khẩu cũ">
                                </div>
                                <div class="form-group">
                                    <label for="newpasword">* Mật khẩu mới</label>
                                    <input type="text" class="form-control" id="new_pass1" placeholder="Nhập mật khẩu mới" name="new_pass1" value="<?=$_POST['new_pass1'];?>">
                                </div>
                                <div class="form-group">
                                    <label for="renewpass">* Nhập lại mật khẩu mới</label>
                                    <input type="text" class="form-control" id="new_pass2" placeholder="Nhập lại mật khẩu mới" name="new_pass2">
                                </div>
                                <button name="change" class="btn btn-purple waves-effect waves-light btn-block">Đổi mật khẩu</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
