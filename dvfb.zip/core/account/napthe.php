<?php $titles='NẠP THẺ';?>
<?php
if ($n['status'] < 1) {
    echo "<script>alert('Tài khoản chưa kích hoạt.!');window.location='/index.php';</script>";
}
?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">THÔNG BÁO NẠP TIỀN</h3>
        </div>
        <div class="panel-body">
            <h4>
				+ QUYỀN LỢI tại hệ thống: được pas bill khi có Cộng tác viên hoặc Đại lý.<br>
                - Nạp tiền qua ngân hàng nhập nội dung theo cú pháp: <font color="red">trieulikes tendangnhap</font><br>
				- Ví dụ bạn nạp 500k cho tài khoản: admin thì nhập nội dung:<font color="red"> trieulikes admin</font><br>
				- Vậy là tiền tự động cộng vào tài khoản của bạn sau đó. </h4>
				<h3><font color="green">* THÔNG TIN NGÂN HÀNG CỦA CHÚNG TÔI( 0858 743 369)</font></h3>
				<ul><code>
				<li>
				Vietcombank: LUONG THI KIEU | 0421 0004 97541  | Chi nhánh Tân Bình
				</li>
				<li>
				Agribank: LUONG THI KIEU | 6460 2056 34780 | Chi nhánh Tân Phú
				</li>
				<li>
				BIDVbank: LUONG THI KIEU | 3681 0000 1819 50 | Chi nhánh Tân Bình
				</li>
				<li>
				ACBbank: LUONG THI KIEU | 2464 094 39 | Chi nhánh Tân Phú
				</li></code>
				</ul>
            <br>
			<div class="col-md-6">
                    <ul class="list-group">
						<li class="list-group-item">CỘNG TÁC VIÊN: MIN 500.000Đ + 8%</li>
						<li class="list-group-item">ĐẠI LÝ: MIN 1.000.000Đ + 10%</li>
						<li class="list-group-item">TỔNG ĐẠI LÝ: MIN 2.000.000 và chiết khấu cấp tổng đại lý.</li>
                    </ul>
            </div>
        </div>
    </div>
</div>
<div class="col-md-9">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">NẠP TIỀN VÀO TÀI KHOẢN BẰNG THẺ CÀO ĐIỆN THOẠI</h3>
        </div>
        <div class="panel-body">
            <form method="post">
                <hr><font color="red"><b>*LƯU Ý: NẠP THẺ SAI QUÁ 2 LẦN SẼ BỊ KHOÁ TÀI KHOẢN</b></font><hr>
                <div class="form-group">
                    <label>Mã thẻ:</label>
                    <input type="number" class="form-control" name="mathe" value="<?php echo isset($_POST['mathe']) ? $_POST['mathe'] : ''; ?>" id="mathe" placeholder="Nhập dãy số gồm 15 chữ số." required>
                </div>
                <div class="form-group">
                    <label>Số seri:</label>
                    <input type="number" class="form-control" name="seri" value="<?php echo isset($_POST['seri']) ? $_POST['seri'] : ''; ?>" id="seri" placeholder="Nhập dãy số gồm 14 chữ số." required>
                </div>
                <div class="form-group">
                    <label for="type">Nhà mạng:</label>
                    <select id="type" name="type" class="form-control">
                        <option value="Viettel">Viettel</option>
                        <option value="Mobiphone">Mobiphone</option>
                        <option value="Vinaphone">Vinaphone</option>
                    </select>
                </div>
				<div class="form-group">
                    <label for="gia">Mệnh giá:</label>
                    <select id="gia" name="gia" class="form-control">
                        <option value="20000">20K</option>
                        <option value="50000">50K</option>
                        <option value="100000">100K</option>
						<option value="200000">200K</option>
						<option value="500000">500K</option>
                    </select>
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success waves-effect waves-light">XÁC NHẬN</button>
        </div>
            </form>
    </div>
</div>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">LỊCH SỬ NẠP THẺ CÀO</h3>
        </div>
        <div class="panel-body">
            <table class="table table-responsive">
                <thead>
                    <tr style="color:#006699" role="row">
                        <th>#</th>
						<th>Tên</th>
                        <th>Mạng</th>
                        <th>Mã thẻ</th>
                        <th>Số seri</th>
						<th>Mệnh giá</th>
						<th>Vào lúc</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $a = 0;
                        if ($uname == $accoutadmin) {
                            $get = "SELECT * FROM card LIMIT 9";
                        }else{
                            $get = "SELECT * FROM card WHERE user_id=$idctv LIMIT 9";
                        }
                        $result = mysqli_query($conn, $get);
                        while ($card = mysqli_fetch_assoc($result)) {
                            $id = $card['id'];
                            $loaithe = $card['loaithe'];
                            $mathe = $card['mathe'];
                            $maseri = $card['maseri'];
                            $type = $card['type'];
							$gia = $card['gia'];
							$name = $card['name'];
							$t = $card['time'];
							$time = date("d-m H:i", $t);
                            if($type == 0){
								if($uname == $accoutadmin){
                                $trangthai = 
								'<a onClick="thanhcong('.$id.');" class="btn btn-warning">Thành công</a>
								<a onClick="thatbai('.$id.');" class="btn btn-danger">Thất bại</a>
								';
								}else{
									$trangthai = 
								'<a class="btn btn-info"><img src="images/load.gif"/>Đang xử lý</a>';
								}
							}else if($type == 1){
									if($uname == $accoutadmin){
									$trangthai = 
									'<a class="btn btn-success">Đã duyệt</a>
									<a onClick="xoathe('.$id.');" class="btn btn-danger">Xoá</a>
									';
									}else{
										$trangthai = 
									$trangthai = '<a class="btn btn-success">Thành công</a>';
									}
                            }else{
									if($uname == $accoutadmin){
									$trangthai = 
									'<a class="btn btn-danger">Đã duyệt</a>
									<a onClick="xoathe('.$id.');" class="btn btn-danger">Xoá</a>
									';
									}else{
										$trangthai = 
									$trangthai = '<a class="btn btn-block">Thất bại</a>';
									}
                            }
                            $a++;
                        ?>
                    <tr>
                        <td><?=$a;?></td>
						<td><?=$name;?></td>
                        <td><?=$loaithe;?></td>
                        <td><?=$mathe;?></td>
                        <td><?=$maseri;?></td>
						<td><?=number_format($gia);?> đồng</td>
						<td><?=$time;?></td>
                        <td><?=$trangthai;?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">
function thanhcong(id) {
        if (confirm('Bạn có chắc chắn thẻ nạp này thành công không?') == true) {
            window.location = '<?=$domain;?>/index.php?action=nap-the&thanhcong=' + id;
        } else {
            return false;
        }
    }
	function thatbai(id) {
        if (confirm('Bạn có chắc chắn thẻ nạp này thất bại không?') == true) {
            window.location = '<?=$domain;?>/index.php?action=nap-the&thatbai=' + id;
        } else {
            return false;
        }
    }
	function xoathe(id) {
        if (confirm('Bạn có chắc chắn xoá thẻ nạp này không?') == true) {
            window.location = '<?=$domain;?>/index.php?action=nap-the&xoathe=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
// xử lý thẻ nạp thành công
if (isset($_GET['thanhcong'])) {
    $id_thanhcong = $_GET['thanhcong'];
    $get = "SELECT id, gia, type, user_id, name FROM card WHERE id = $id_thanhcong";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $id = $check['id'];
	$userid = $check['user_id'];
	$name = $check['name'];
	$gia = $check['gia'];
	$getbill = "SELECT bill FROM member WHERE username='$name'";
    $result = mysqli_query($conn, $getbill);
    $x = mysqli_fetch_assoc($result);
	$bill = $x['bill'];
	if($uname != $accoutadmin){
	            echo "<script>swal({html: true,title: 'Thất bại',text: 'Đã xảy ra lỗi.',type: 'success',});</script>";
	}
    else{
		mysqli_query($conn, "UPDATE card SET type = 1 WHERE id = $id_thanhcong");
        mysqli_query($conn, "UPDATE member SET bill = bill + $gia WHERE id_ctv = $userid");
		$content = "Nạp Tiền Card";
        $tien_sau = $bill + $gia;
        $time = time();
        $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$userid', '$name', '$gia', '$bill', '$tien_sau', 4)";
		if (mysqli_query($conn, $his)) {
			echo "<script>swal({html: true,title: 'Thành công',text: 'Đã duyệt thẻ xong.',type: 'success',});</script>";
			echo '<meta http-equiv=refresh content="1; URL=/index.php?action=nap-the">';
 			}
	}
}
// xử lý thẻ nạp thất bại
if (isset($_GET['thatbai'])) {
    $id_thatbai = $_GET['thatbai'];
    $get = "SELECT id, type, user_id FROM card WHERE id = $id_thatbai";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $user_id = $check['user_id'];
	$id = $check['id'];
	$sql = "UPDATE card SET type = -1 WHERE id = $id_thatbai";
	if (mysqli_query($conn, $sql)) {
            echo "<script>swal({html: true,title: 'Thành công',text: 'Đã duyệt thẻ xong.',type: 'success',});</script>";
			echo '<meta http-equiv=refresh content="1; URL=/index.php?action=nap-the">';
                        
			}
}
// xử lý xoá thẻ nạp
if (isset($_GET['xoathe'])) {
    $id_xoathe = $_GET['xoathe'];
    $get = "SELECT * FROM card WHERE id = $id_xoathe";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
	if($uname != $accoutadmin){
	            echo "<script>swal({html: true,title: 'Thất bại',text: 'Đã xảy ra lỗi.',type: 'success',});</script>";
	}
    else{
		mysqli_query($conn, "DELETE FROM card WHERE id = $id_xoathe");
			echo "<script>swal({html: true,title: 'Thành công',text: 'Đã xoá thẻ xong.',type: 'success',});</script>";
			echo '<meta http-equiv=refresh content="1; URL=/index.php?action=nap-the">';
 			}
}
?>
<?php
if (isset($_POST['submit'])) {
    $mathe = trim($_POST['mathe']);
    $seri = trim($_POST['seri']);
    $type = trim($_POST['type']);
	$gia = trim($_POST['gia']);
	$time = time();
    $checkma = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) FROM card WHERE mathe = '$mathe'"));
    $checkseri = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) FROM card WHERE maseri = '$seri'"));
    if ($n['status'] < 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Tài khoản của bạn chưa kích hoạt.',type: 'error',});</script>";
    }else if (!$mathe) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng nhập mã thẻ.',type: 'error',});</script>";
    }else if (strlen($mathe) < 15) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã thẻ không được bé hơn 15 kí tự.',type: 'error',});</script>";
    }else if (strlen($mathe) > 15) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã thẻ không được lớn hơn 15 kí tự.',type: 'error',});</script>";
    }else if (!$seri) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng nhập seri.',type: 'error',});</script>";
    }else if (strlen($seri) < 14) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã seri không được bé hơn 14 kí tự.',type: 'error',});</script>";
    }else if (strlen($seri) > 14) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã seri không được lớn hơn 14 kí tự.',type: 'error',});</script>";
    }else if (!$type) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng chọn loại thẻ.',type: 'error',});</script>";
    }else if($checkma['COUNT(*)'] > 0){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã thẻ đã tồn tại trên hệ thống.',type: 'error',});</script>";
    }else if($checkseri['COUNT(*)'] > 0){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã seri đã tồn tại trên hệ thống.',type: 'error',});</script>";
    }else{
        mysqli_query($conn, "INSERT INTO card(loaithe, mathe, maseri, gia, type, user_id, name, time) VALUES('$type', '$mathe', '$seri', '$gia', '0', '$idctv', '$uname', '$time')");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Bạn vừa nạp thẻ thành công!. Hệ thống đang xử lý...',type: 'success',});</script>";
		echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
    }
}
?>