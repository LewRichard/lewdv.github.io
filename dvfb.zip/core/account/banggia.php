<?php $titles='BẢNG GIÁ';?>
<div class="col-md-12">
    <div class="panel panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'info'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title" style="color: white;">Bảng Giá VIP BOT (chiết khấu > 70% cho đại lý & 60% cho cộng tác viên)</h3>
        </div>
        <div class="panel-body">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Gói</th>
                <th>Thời gian</th>
                <th>Mô tả</th>
                <th>Giá tiền</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $a = 0;
            $react = "SELECT * FROM package WHERE type='REACTION' ORDER BY price ASC";
            $r_react = mysqli_query($conn, $react);
            while ($x = mysqli_fetch_assoc($r_react)) {
                $giatien = $x['price'];
                $a = $a+1;
                ?>
                <tr>
                    <td><? echo $a; ?></td>
                    <td><?php echo "{$x['name_likes']}"; ?></td>
                    <td style="color: red"><?php echo "30 ngày"; ?></td>
                    <td><?php echo "Tương tác tùy chỉnh."; ?></td>
                    <td><span style="color: red"><?php echo number_format($giatien);?></span> đồng</td>
                </tr>
                <?php } ?>
            </tbody>
          </table>
        </div>
    </div>   
</div>
<div class="col-md-6">
    <div class="panel panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'info'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title" style="color:white;">Bảng Giá VIP LIKE (tự động chiết khấu cho đại lý và cộng tác viên)</h3>
        </div>
        <div class="panel-body">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Gói</th>
                <th>Giới hạn like</th>
                <th>Thời hạn</th>
                <th>Giá</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $a = 0;
            $like = "SELECT * FROM package WHERE type='LIKE' ORDER BY price ASC";
            $r_like = mysqli_query($conn, $like);
            while ($x = mysqli_fetch_assoc($r_like)) {
                $giatien = $x['price'];
                $a = $a+1;
                ?>
                <tr>
                    <td><? echo $a; ?></td>
                    <td><?php echo "{$x['name_likes']}"; ?></td>
                    <td style="color: red"><?php echo $x['max'] . ''; ?></td>
                    <td>30 ngày</td>
                    <td><span style="color: red"><?php echo number_format($giatien);?></span> đồng</td>
                </tr>
                <?php } ?>
            </tbody>
          </table>
        </div>
    </div>
</div>
<div class="col-md-6">
    <div class="panel panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'info'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title" style="color: white;">BẢNG GIÁ VIP REP COMMENT (chiết khấu > 50% cho đại lý & 50% cho CTV)</h3>
        </div>
        <div class="panel-body">
          <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Gói</th>
                    <th>Giới hạn bài</th>
                    <th>Thời gian</th>
                    <th>Giá</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $a = 0;
            $like = "SELECT * FROM package WHERE type='CMT' ORDER BY price ASC";
            $r_like = mysqli_query($conn, $like);
            while ($x = mysqli_fetch_assoc($r_like)) {
                $giatien = $x['price'];
                $a = $a+1;
                ?>
                <tr>
                    <td><? echo $a; ?></td>
                    <td><?php echo "{$x['name_likes']}"; ?></td>
                    <td style="color: red"><?php echo $x['max'] . ''; ?></td>
                    <td>30 ngày</td>
                    <td><span style="color: red"><?php echo number_format($giatien);?></span> đồng</td>
                </tr>
                <?php } ?>
            </tbody>
          </table>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="panel panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'info'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title" style="color: white;">THÔNG TIN CHO ĐẠI LÝ, CỘNG TÁC VIÊN</h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <h4 class="text-center text-success">THÔNG TIN CHI TIẾT CHIẾT KHẤU</h4>
                <div class="col-md-6">
                    <div class="mini-stat clearfix bx-shadow bg-white">
                        <span class="mini-stat-icon"><img src="https://graph.facebook.com/4/picture?width=70&height=70" alt="" class="img-circle img-responsive"></span>
                        <div class="mini-stat-info text-right text-dark">
                            <h4 class="name text-dark">Edit by KQ</h4>
                               Hotline: 0858 743 369
                        </div>
                        <br>
                        <hr class="m-t-10">
                        <ul class="text-center social-links list-inline m-0">
                            <li>
                                <a href=""><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href=""><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href=""><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <ul class="list-group">
						<li class="list-group-item">CỘNG TÁC VIÊN: MIN 500.000Đ + 8%</li>
						<li class="list-group-item">ĐẠI LÝ: MIN 1.000.000Đ + 10%</li>
						<li class="list-group-item">TỔNG ĐẠI LÝ: MIN 2.000.000 và chiết khấu cấp tổng đại lý.</li>
                    </ul>
                </div>          
            </div>
        </div>
    </div>
</div>