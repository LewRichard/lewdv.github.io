<?php $titles='GIFT CODE';?>
<?php
if ($n['status'] < 1) {
    echo "<script>alert('Tài khoản chưa kích hoạt.!');window.location='/index.php';</script>";
}
?>
<div class="col-md-6">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
            <div class="panel-body">
                <form method="post">
<?php

if (isset($_POST['submit'])) {
	$get = "SELECT * FROM member WHERE id_ctv=$idctv";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
	$bill = $x['bill'];
	$level = $x['level'];
	$num_id = $x['num_id'];
    $code = $_POST['code'];
	$name = $x['name'];
    $getcheck = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) FROM giftcode WHERE code = '$code'"));
    $res = $getcheck['COUNT(*)'];
    $check = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM giftcode WHERE code = '$code'"));
    $monney = $check['monney'];
    $type = $check['type'];
    if($res == 0){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã nhận thưởng không tồn tại.',type: 'error',});</script>";
    }else if($type == 1){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mã nhận thưởng đã được sử dụng.',type: 'error',});</script>";
    }else if($bill >= $monney){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn không được nhận thưởng.',type: 'error',});</script>";
    }else if($level == 2 || $level == 3){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Đại lý và cộng tác viên không được nhận thưởng.',type: 'error',});</script>";
    }else if($num_id > 0){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn không được nhận thưởng..',type: 'error',});</script>";
    }
	else{
        mysqli_query($conn, "UPDATE member SET bill = bill + '$monney' WHERE id_ctv='$idctv'");
        mysqli_query($conn, "UPDATE giftcode SET type = 1 WHERE code='$code'");
		$tien = number_format($monney);
		$content = "Nhận Thưởng";
        $tien_sau = $bill + $monney;
        $time = time();
        $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$idctv', '$uname', '$monney', '$bill', '$tien_sau', 2)";
		if (mysqli_query($conn, $his)) {
        echo "<script>swal({html: true,title: 'Thành công',text: 'Chúc mừng! Tài khoản của bạn đã được cộng $tien đồng.',type: 'success',});</script>";
		}
    }
}
?>
                    <div class="form-group">
                        <label for="code">Mã nhận thưởng</label>
                        <input class="form-control" type="text" name="code" value="<?=$_POST['code'];?>" placeholder="Nhập mã nhận thưởng" required>
                    </div>
            </div>
            <div class="panel-footer">
                <button type="submit" name="submit" class="btn btn-success">XÁC NHẬN</button>
            </div>
                </form>
    </div>
</div>
<div class="col-md-6">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">TOP 10 MÃ NHẬN THƯỞNG CHỈ DÀNH CHO THÀNH VIÊN MỚI</h3>
        </div>
            <div class="panel-body">
                <div class="slimscrollleft">
                    <div class="table-responsive">
                        <table class="table table-responsive">
                            <thead>
                                <tr style="color:#006699" role="row">
                                    <th>#</th>
                                    <th>Mã nhận thưởng</th>
                                    <th>Số tiền</th>
                                    <th>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $a = 0;
                            $get = "SELECT * FROM giftcode ORDER BY id DESC LIMIT 10";
                            $result = mysqli_query($conn, $get);
                            while ($x = mysqli_fetch_assoc($result)) {
                                $id = $x['id'];
                                if($x['type'] == 0){
                                    //$code = '********************';
									$code = $x['code'];
                                    $type = '<a class="btn btn-success">Chưa sử dụng</a>';
                                }else if($x['type'] == 1){
                                    $code = $x['code'];
                                    $type = '<a class="btn btn-danger">Đã sử dụng</a>';
                                }
                                $a = $a + 1;
                            ?>
                                <tr>
                                    <td><?=$a;?></td>
                                    <td><?=$code;?></td>
                                    <td><?=number_format($x['monney']);?></td>
                                    <td><?=$type;?></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</div>
