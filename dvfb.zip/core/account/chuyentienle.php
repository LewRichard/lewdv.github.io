<?php $titles='CHUYỂN TIỀN';?>
<?php
if ($n['status'] < 1) {
    echo "<script>alert('Tài khoản chưa kích hoạt.!');window.location='/index.php';</script>";
}
?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">CHUYỂN TIỀN CHO KHÁCH</h3>
        </div>
            <div class="panel-body">
                <form method="post">
<?php
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $get = "SELECT id_ctv, level FROM member WHERE username='$username'";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    $id = $x['id_ctv'];
	$lvel = $x['level'];
    $money = $_POST['money'];
    $time = time();
    $check = "SELECT bill FROM member WHERE id_ctv=$idctv";
    $rs = mysqli_query($conn, $check);
    $bl = mysqli_fetch_assoc($rs)['bill'];
	$level = $bl['level'];
    $acc = "SELECT * FROM member WHERE username='$username'";
    $check = mysqli_query($conn, $acc);
    $checkacc = mysqli_fetch_assoc($check);
    if(!$money || !$username){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng điền đầy đủ thông tin.',type: 'error',});</script>";
    }else if ($checkacc['username'] != $_POST['username']) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Tài khoản <strong>$username</strong> không có trên hệ thống..',type: 'error',});</script>";
    }else if ($level <= $lvel){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chỉ có thể chuyển tiền cho cấp nhỏ hơn.',type: 'error',});</script>";
    }else if($money < 0){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số tiền không hợp lệ.',type: 'error',});</script>";
    }else if($money < 100000){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số tiền chuyển ít nhất là 100,000 VNĐ.',type: 'error',});</script>";
    }else if($money > $bl){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư của bạn không đủ để thực hiện phiên giao dịch này.',type: 'error',});</script>";
    }else if($bl >= $money){
        $minus = "UPDATE member SET bill = bill - $money WHERE id_ctv=$idctv";
        if(mysqli_query($conn, $minus)){
            $sql = "UPDATE member SET bill = bill + $money WHERE username = '$username'";
            if (mysqli_query($conn, $sql)) {
                $content = "Chuyển Tiền";
                $tien_sau = $bill - $money;
                $time = time();
                $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$idctv', '$uname', '$money', '$bill', '$tien_sau', 5)";
                if (mysqli_query($conn, $his)) {
                    $check = "SELECT bill, id_ctv FROM member WHERE username='$username'";
                    $rs = mysqli_query($conn, $check);
                    $biill = mysqli_fetch_assoc($rs)['bill'];
                    $result = mysqli_query($conn, $check);
                    $x = mysqli_fetch_assoc($result);
                    $id = $x['id_ctv'];
                    $content1 = "Nhận Tiền";
                    $tien_sau = $biill + $money;
                    $time = time();
                    $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content1', '$time', '$id', '$username', '$money', '$biill', '$tien_sau', 6)";
                    if (mysqli_query($conn, $his)) {
                        echo "<script>swal({html: true,title: 'Thành công',text: 'Bạn vừa chuyển " . number_format($money) . " đồng vào tài khoản <strong>$username</strong>.',type: 'success',});</script>";
                    }
                }
            }
        }
    }
}
?>
                    <div class="form-group">
                        <label for="user_id">Người nhận( Đúng tên đăng nhập - min 100.000Đ)</label>
                        <input class="form-control" type="text" name="username" value="<?=$_POST['username'];?>" placeholder="Ví dụ: admin" required>
                    </div>
                    <div class="form-group">
                        <label for="profile">Số tiền (VNĐ):</label>
                        <input class="form-control" type="number" name="money" value="<?=$_POST['money'];?>" placeholder="Ví dụ: 100000" required>
                    </div>
            </div>
            <div class="panel-footer">
                <button type="submit" name="submit" class="btn btn-success">Xác nhận</button>
            </div>
                </form>
    </div>
</div>