<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">LỊCH SỬ GIAO DỊCH</h3>
        </div>
        <div class="panel-body">
            <div class="slimscrollleft">
                <div class="table-responsive">
                    <table class="table table-responsive">
                        <thead>
                            <tr style="color:#006699" role="row">
                                <th>#</th>
                                <th>Thời gian</th>
                                <th>Người tạo</th>
                                <th>Loại giao dịch</th>
                                <th>Số tiền</th>
                                <th>Tiền trước</th>
                                <th>Tiền sau</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $a = 0;
                        if ($uname == $accoutadmin) {
                            $get = "SELECT * FROM history ORDER BY id DESC";
                        } else {
                            $get = "SELECT * FROM history WHERE id_ctv = $idctv ORDER BY id DESC";
                        }
                        $result = mysqli_query($conn, $get);
                        while ($x = mysqli_fetch_assoc($result)) {
                            $id = $x['id'];
                            $t = $x['time'];
                            $time = date("d-m-Y H:i", $t);
                            $a = $a + 1;
							$us = $x['user'];
							$use = "admin";
							$nd = $x['vip'];
							if($nd == 1){
								$ndung ="<a class='btn btn-info'>Mua Vip Bot</a>";
							}
							if($nd == 2){
								$ndung ="<a class='btn btn-success'>Mua Vip Like</a>";
							}
							if($nd == 3){
								$ndung ="<a class='btn btn-warning'>Mua Vip Rep</a>";
							}
							if($nd == 4){
								$ndung ="<a class='btn btn-danger'>Nạp Tiền Card</a>";
							}
							if($nd == 5){
								$ndung ="<a class='btn btn-info'>Chuyển Tiền</a>";
							}
							if($nd == 6){
								$ndung ="<a class='btn btn-success'>Nhận Tiền</a>";
							}
							if($nd == 7){
								$ndung ="<a class='btn btn-warning'>Nhận Thưởng</a>";
							}
							if($nd == 8){
								$ndung ="<a class='btn btn-warning'>Gia Hạn VipBot</a>";
							}
							if($nd == 8){
								$ndung ="<a class='btn btn-success'>Gia Hạn VipLike</a>";
							}
							if($us == $use){
								$u = "<a class='btn btn-danger'>administrator</a>";
							}else{
								$u = "<a class='btn btn-success'>$us</a>";
							}
                        ?>
                            <tr>
                                <td><?php echo $a; ?></td>
                                <td><?php echo $time; ?></td>
                                <td><?php echo $u; ?></td>
                                <td><?php echo $ndung; ?></td>
                                <td><?php echo number_format($x['sodu']); ?></td>
                                <td><?php echo number_format($x['tien_truoc']); ?></td>
                                <td><?php echo number_format($x['tien_sau']); ?></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>