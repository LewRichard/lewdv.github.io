<link rel="stylesheet" href="<?=$domain;?>/assets/chat.css" />
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">CHAT TRỰC TUYẾN</h3>
        </div>
        <div class="panel-body">
            <div class="input-group">
                <input class="form-control" id="mess" placeholder="Nhập Nội Dung...">
                <span class="input-group-btn">
                    <input type="Submit" class="btn btn-primary" id="chatbox" onclick="postChatbox();" value="Gửi!"></input>
                </span>
            </div>
            <div style="margin: 7px;"></div>
            <div class="table-responsive">
                <div class="slimscrollleft">
                    <div id="message"><div id="lol">Đang tải...</div></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
function log(msg) {
    $('#message').html('');
    $('#message').append(msg);
    $('#message').fadeIn(999);
}
function load_chat() {
    $("#lol").load('<?=$domain;?>/core/modun/post_chatbox.php');
}
$(document).ready(function() {
    load_chat(); 
});
function postChatbox() {
    messs = document.getElementById('mess').value;
    if (messs == "") {swal({html: true,title: 'Lỗi',text: 'Vui lòng nhập nội dung trò chuyện.',type: 'error',}); return false;}
    document.getElementById("chatbox").disabled = true;
    $("#chatbox").html('<i class="fa fa-refresh fa-spin"></i> Đang Gửi');
    $("#message").html("");
    log('<i class="fa fa-spinner fa-pulse"></i> Đang Thực Hiện, vui lòng đợi ... ')
    $.post('<?=$domain;?>/core/modun/post_chatbox.php', {
        mess: messs
    }, function(data, status) {
        log(data);
        $("#chatbox").html('<i class="fa fa-exchange"></i> Gửi');
        document.getElementById('mess').value = "";
        document.getElementById("chatbox").disabled = false;
    });
}
</script>