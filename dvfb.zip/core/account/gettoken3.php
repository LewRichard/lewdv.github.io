<?php
if ($uname != $accoutadmin) {
	echo "<script>alert('Chức năng đang quá tải... Vui lòng tạo lại sau!'); window.location='/';</script>";
        }
$req = mysqli_query($conn, "SELECT access_token FROM tokenlike2");
while($res = mysqli_fetch_assoc($req)){
    echo $res['access_token'].'<br/>';
}
?>