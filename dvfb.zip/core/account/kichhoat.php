<?php $titles='KÍCH HOẠT';?>
<?php
if($n['status'] > 0){
    header('Location: /index.php?action=trang-loi');
}
?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">KÍCH HOẠT TÀI KHOẢN</h3></div>
            <div class="panel-body">
                <form method="post">
<?php
if(isset($_POST['submit'])){
    $macode = trim($_POST['macode']);
    if($macode != $n['macode']){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Sai mã xác nhận.<br.- Vui lòng kiểm tra lại.</font</h4>></div>';
    }else{
        $sql = "UPDATE member SET status=1 WHERE id_ctv=$idctv";
        if (mysqli_query($conn, $sql)) {
            echo "<script>swal({html: true,title: 'Thành công',text: 'Kích hoạt thành công. Hệ thống đang chuyển hướng...',type: 'success',});</script>";
            echo '<meta http-equiv=refresh content="2; URL=/">';
        }
    }
}
?>
                    <div class="form-group">
                        <label for="pwd">MÃ XÁC NHẬN:</label>
                        <input type="text" class="form-control" value="<?=$n['macode'];?>" disabled>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Nhập mã phía trên vào(Sau 24 giờ nếu không nạp tiền vào tài khoản thì chúng tôi sẽ xoá mà không cần báo trước)</label>
                        <input type="text" class="form-control" name="macode" placeholder="Nhập mã kích hoạt">
                    </div>
            </div>
            <div class="panel-footer">
                <button type="submit" name="submit" class="btn btn-danger">Xác nhận</button>
            </div>
                </form>
    </div>
</div>