<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">LỊCH SỬ ĐÃ XOÁ</h3>
        </div>
        <div class="panel-body">
            <div class="slimscrollleft">
                <div class="table-responsive">
                    <table class="table table-responsive">
                        <thead>
                            <tr style="color:#006699" role="row">
                                <th>#</th>
                                <th>Khách hàng</th>
                                <th>Gói vip</th>
								<th>Lý do xoá</th>
                                <th>Vào lúc</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $a = 0;
                        if ($uname == $accoutadmin) {
                            $get = "SELECT * FROM lichsuxoavip ORDER BY id DESC";
                        } else {
                            $get = "SELECT * FROM lichsuxoavip WHERE id_ctv = $idctv ORDER BY id DESC";
                        }
                        $result = mysqli_query($conn, $get);
                        while ($x = mysqli_fetch_assoc($result)) {
                            $id = $x['id'];
                            $t = $x['time'];
                            $time = date("d-m-Y H:i", $t);
                            $a = $a + 1;
                        ?>
                            <tr>
                                <td><?php echo $a; ?></td>
                                <td><b><font color="green"><?php echo '<img src="https://graph.facebook.com/'.$x['user_id'].'/picture?width=30&amp;height=30" class="img img-circle img-thumbnail"><br><a href="//fb.com/'.$x['user_id'].'" target="_blank"><b>'.$x['name'].'</b></a><br>ID: '.$x['user_id'].''; ?></font></b></td>
                                <td><b><font color="blue"><?php echo $x['vip']; ?></font></b></td>
								<td><b><font color="red"><?php echo $x['lydo']; ?></font></b></td>
                                <td><b><font color="red"><?php echo $time; ?></font></b></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>