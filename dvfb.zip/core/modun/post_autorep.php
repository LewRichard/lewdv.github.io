<?php
include "../system/config.php";
include "../system/functions.php";
if (isset($_GET['id'])){
    $id = $_GET['id'];
    $a = 0;
    $json = array();
    if($id == $idadmin){
        $get = "SELECT * FROM autorep ORDER BY end ASC";
    }else{
        $get = "SELECT * FROM autorep WHERE id_ctv=$id ORDER BY end ASC";
    }
    $result = mysqli_query($conn, $get);
     while ($data = mysqli_fetch_assoc($result)) {
			$stt = $data['status'];
			$ghichu = $data['ghi_chu'];
			$cmtngay = $data['cmtngay'];
			if ($cmtngay == 1) {
				$cmts ='<b><font color=blue>Nâng cao</font></b>';
			}
			else{
				$cmts ='<b><font color=green>Mặc định</font></b>';
			}
            $me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$data['access_token'].'&fields=id&method=get'),true);
		if ($stt == 0){	
            $tokenstt = '';
            if((isset($me['id']) && $me['id'] == $data['user_id'])){
                $tokenstt = '<font color="green">Hoạt động</font>';
            }
			else if(!isset($me['id'])){
				mysqli_query($conn, "UPDATE autorep SET status='1' WHERE user_id=".$data['user_id']."");
                $tokenstt = '<b><font color="red">NGỪNG</font></b>';
            }else if(isset($me['id']) && $me['id'] != $data['user_id']){
                $tokenstt = '<font color="blue">LỖI</font>';
            }
			$han = $data['han'];
			$time = $data['end'];
			$timed = $time - time();
			$conlai = round($timed/(24*3600));
			if ($stt == 1){
				$tt = '<b><font color="red">Tạm dừng</font></b>';
			}else{
					if ($conlai > 3){
						$tt = '<b><font color=green>Chạy <sup>'.$han.' tháng</sup></font></b>';
					}
					else if(($conlai == 3) || ($conlai == 2) || ($conlai ==1) || ($conlai == 0)){
						$tt = '<b><font color=blue>Còn '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
					}
					else if ($conlai < 0){
						$tt = '<b><font color=red>Hết '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
			
					}	
				}
            $userid = $data['user_id'];
			$name = $data['name'];
            $het_han = date('d/m/Y', $data['end']);
            $a = $a+1;
        $json[] = array(
            $a,
            '<img src="https://graph.facebook.com/'.$userid.'/picture?width=30&amp;height=30" class="img img-circle img-thumbnail"><br><a href="//fb.com/'.$userid.'" target="_blank"><b>'.$name.'</b></a><br>'.$userid.'',
            $cmts,
            $tokenstt,
			$tt,
			$ghichu,
            $het_han,
            '<ul class="nav navbar-nav navbar-right pull-left">
            <li class="dropdown">
            <a class="btn btn-info" data-toggle="dropdown">CÀI ĐẶT</a>
            <ul class="dropdown-menu">
			<a class="btn btn-info" href="'.$domain.'/index.php?action=auto-rep&update='.$userid.'" title="Chỉnh sửa chương trình">Sửa</a> 
			<a class="btn btn-success" href="'.$domain.'/index.php?action=auto-rep&giahan='.$userid.'" title="Chỉnh sửa chương trình">Gia hạn</a> 
			<a onClick="dungrep('.$userid.');" class="btn btn-warning">Dừng lại</a>
            <a onClick="xoarep('.$userid.');" class="btn btn-danger">Xóa</a>
			</ul>
            </li>
            </ul>',
        );
    }else{
		$tokenstt = '';
            if((isset($me['id']) && $me['id'] == $data['user_id'])){
                $tokenstt = '<font color="green">Hoạt động</font>';
            }
			else if(!isset($me['id'])){
                $tokenstt = '<b><font color="red">NGỪNGg</font></b>';
            }else if(isset($me['id']) && $me['id'] != $data['user_id']){
                $tokenstt = '<b><font color="blue">LỖI</font></b>';
            }
			$han = $data['han'];
			$time = $data['end'];
			$timed = $time - time();
			$conlai = round($timed/(24*3600));
			if ($stt == 1){
				$tt = '<b><font color="red">Tạm dừng</font></b>';
			}else{
					if ($conlai > 3){
						$tt = '<b><font color=green>Chạy <sup>'.$han.' tháng</sup></font></b>';
					}
					else if(($conlai == 3) || ($conlai == 2) || ($conlai ==1) || ($conlai == 0)){
						$tt = '<b><font color=blue>Còn '.$conlai.' ngày <sup>của'.$han.' tháng</sup></font></b>';
					}
					else if ($conlai < 0){
						$tt = '<b><font color=red>Hết '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
					}
				}	
			
			if ($cmtngay == 1) {
				$cmts ='<b><font color=blue>Nâng cao</font></b>';
			}
			else{
				$cmts ='<b><font color=green>Mặc định</font></b>';
			}
            $userid = $data['user_id'];
			$name = $data['name'];
            $het_han = date('d/m/Y', $data['end']);
            $a = $a+1;//số tt
        $json[] = array(
            $a,
            '<img src="https://graph.facebook.com/'.$userid.'/picture?width=30&amp;height=30" class="img img-circle img-thumbnail"><br><a href="//fb.com/'.$userid.'" target="_blank"><b>'.$name.'</b></a><br>'.$userid.'',
            $cmts,
            $tokenstt,
			$tt,
			$ghichu,
            $het_han,
            '<ul class="nav navbar-nav navbar-right pull-left">
            <li class="dropdown">
            <a class="btn btn-info" data-toggle="dropdown">CÀI ĐẶT</a>
            <ul class="dropdown-menu">
			<a class="btn btn-info" href="'.$domain.'/index.php?action=auto-rep&update='.$userid.'" title="Chỉnh sửa chương trình">Sửa</a> 
			<a class="btn btn-success" href="'.$domain.'/index.php?action=auto-rep&giahan='.$userid.'" title="Chỉnh sửa chương trình">Gia hạn</a> 
			<a onClick="startrep('.$userid.');" class="btn btn-warning">Chạy lại</a>
            <a onClick="xoarep('.$userid.');" class="btn btn-danger">Xóa</a>
			</ul>
            </li>
            </ul>',
			);
	}
	 }
	$response = array();
	$response['data'] = $json;
	echo json_encode($response);
}else{
    echo '<meta charset="utf-8" />Bạn không có quyền truy cập vào bản quyền';
}
?>