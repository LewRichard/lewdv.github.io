<?php
include "../system/config.php";
include "../system/functions.php";
if (isset($_GET['id'])){
    $id = $_GET['id'];
    $a = 0;
    $json = array();
	$getmem = "SELECT id_ctv FROM member WHERE id_ctv = $idctv";
	$res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$id_ctv = $x['id_ctv'];
	$idvip = 25;
    if($id == $idadmin){
        $get = "SELECT * FROM vipreaction";
    }else if($id_ctv == $idvip){
        $get = "SELECT * FROM vipreaction WHERE boss = $idvip";
    }else{
		$get = "SELECT * FROM vipreaction WHERE id_ctv = $id";
	}
    $result = mysqli_query($conn, $get);
     while ($data = mysqli_fetch_assoc($result)) {
            $type = $data['type'];
			$stt = $data['status'];
			$useradd = $data['useradd'];
			$cmt = $data['cmt'];
			$ghichu = $data['ghi_chu'];
			$cmtngay = $data['cmtngay'];
			$stick = $data['stick'];
			$batcx = $data['batcx'];
			if (($cmt == 1) && ($cmtngay == 0)) {
				$cmts ='<b><font color=green>Mặc định</font></b>';
			}
			if (($cmt == 1) && ($cmtngay == 1)) {
				$cmts ='<b><font color=blue>Nâng cao</font></b>';
			}
			if ($cmt == 0){
				$cmts ='<b><font color=red>TẮT</font></b>';
			}
			if ($stick == 1){
				$sti ='<b><font color=green>BẬT</font></b>';
			}else{
				$sti ='<b><font color=red>TẮT</font></b>';
			}
            if(strripos($data['type'], "\n")){
                $type = str_replace("\n", ",", $data['type']);
            }
            $me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$data['access_token'].'&fields=id&method=get'),true);
		if ($stt == 0){	
            $tokenstt = '';
            if((isset($me['id']) && $me['id'] == $data['user_id'])){
                $tokenstt = '<font color="green">Hoạt động</font>';
            }
			else if(!isset($me['id'])){
                $tokenstt = '<b><font color="red">NGỪNG</font></b>';
            }else if(isset($me['id']) && $me['id'] != $data['user_id']){
                $tokenstt = '<font color="blue">LỖI</font>';
            }
			$han = $data['han'];
			$limit = $data['limit_react'];
			$limits = "$limit Bài";
			$time = $data['end'];
			$timed = $time - time();
			$conlai = round($timed/(24*3600));
			if ($stt == 1){
				$tt = '<b><font color="red">Tạm dừng</font></b>';
			}else{
					if ($conlai > 3){
						$tt = '<b><font color=green>'.$han.' tháng</font></b>';
					}
					else if(($conlai == 3) || ($conlai == 2) || ($conlai ==1) || ($conlai == 0)){
						$tt = '<b><font color=blue>Còn '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
					}
					else if ($conlai < 0){
						$tt = '<b><font color=red>Hết '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
			
					}	
				}
			$type = $data['type'];
			if ($batcx == 0){
				$type = '<b><font color="red">TẮT</font></b>';
			}else{
				if(strpos($type, "\n", 0)){
					$type = str_replace("\n", " ", $data['type']);
					$type = str_replace(array(
						'LIKE',
						'HAHA',
						'LOVE',
						'WOW',
						'SAD',
						'ANGRY'
                ), array(
                    '<img src="/core/menu/icon/like.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Thích">', 
                    '<img src="/core/menu/icon/haha.svg" style="width:24px" data-toggle="tooltip" title="" data-original-title="Cười lớn">', 
                    '<img src="/core/menu/icon/love.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Yêu thích">', 
                    '<img src="/core/menu/icon/wow.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Ngạc nhiên">', 
                    '<img src="/core/menu/icon/sad.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Buồn">', 
                    '<img src="/core/menu/icon/angry.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Phẩn nộ">'), $type);
            }
		}
            $userid = $data['user_id'];
			$name = $data['name'];
            $het_han = date('d/m/Y', $data['end']);
            $a = $a+1;
        $json[] = array(
            $a,
            '<img src="https://graph.facebook.com/'.$userid.'/picture?width=30&amp;height=30" class="img img-circle img-thumbnail"><br><a href="//fb.com/'.$userid.'" target="_blank"><b>'.$name.'</b></a><br>'.$userid.'',
            $cmts,
			$sti,
            $type,
            $tokenstt,
			$tt,
			$limits,
			$useradd,
			$ghichu,
            $het_han,
            '<ul class="nav navbar-nav navbar-right pull-left">
            <li class="dropdown">
            <a class="btn btn-info" data-toggle="dropdown">CÀI ĐẶT</a>
            <ul class="dropdown-menu">
			<a class="btn btn-info" href="'.$domain.'/index.php?action=vip-bot&update='.$userid.'" title="Chỉnh sửa chương trình">Sửa</a> 
			<a class="btn btn-success" href="'.$domain.'/index.php?action=vip-bot&giahan='.$userid.'" title="Chỉnh sửa chương trình">Gia hạn</a> 
			<a onClick="dungbot('.$userid.');" class="btn btn-warning">Tạm dừng</a>
            <a onClick="xoabot('.$userid.');" class="btn btn-danger">Xoá</a>
			</ul>
            </li>
            </ul>',
        );
    }else{
		$tokenstt = '';
            if((isset($me['id']) && $me['id'] == $data['user_id'])){
                $tokenstt = '<font color="green">Hoạt động</font>';
            }
			else if(!isset($me['id'])){
                $tokenstt = '<b><font color="red">NGỪNG</font></b>';
            }else if(isset($me['id']) && $me['id'] != $data['user_id']){
                $tokenstt = '<b><font color="blue">LỖI</font></b>';
            }
			$han = $data['han'];
			$limit = $data['limit_react'];
			$limits = "$limit Bài";
			$time = $data['end'];
			$timed = $time - time();
			$conlai = round($timed/(24*3600));
			if ($stt == 1){
				$tt = '<b><font color="red">Tạm dừng</font></b>';
			}else{
					if ($conlai > 3){
						$tt = '<b><font color=green>'.$han.' tháng</font></b>';
					}
					else if(($conlai == 3) || ($conlai == 2) || ($conlai ==1) || ($conlai == 0)){
						$tt = '<b><font color=blue>Còn '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
					}
					else if ($conlai < 0){
						$tt = '<b><font color=red>Hết '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
					}
				}	
			if (($cmt == 1) && ($cmtngay == 0)) {
				$cmts ='<b><font color=green>Mặc định</font></b>';
			}
			if (($cmt == 1) && ($cmtngay == 1)) {
				$cmts ='<b><font color=blue>Nâng cao</font></b>';
			}
			if ($cmt == 0){
				$cmts ='<b><font color=red>TẮT</font></b>';
			}
			if ($stick == 1){
				$sti ='<b><font color=green>BẬT</font></b>';
			}else{
				$sti ='<b><font color=red>TẮT</font></b>';
			}
            $type = $data['type'];
		   if ($batcx == 0){
				$type = '<b><font color="red">TẮT</font></b>';
			}else{
            if(strpos($type, "\n", 0)){
                $type = str_replace("\n", " ", $data['type']);
                $type = str_replace(array(
                    'LIKE',
                    'HAHA',
                    'LOVE',
                    'WOW',
                    'SAD',
                    'ANGRY'
                ), array(
                    '<img src="/core/menu/icon/like.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Thích">', 
                    '<img src="/core/menu/icon/haha.svg" style="width:24px" data-toggle="tooltip" title="" data-original-title="Cười lớn">', 
                    '<img src="/core/menu/icon/love.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Yêu thích">', 
                    '<img src="/core/menu/icon/wow.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Ngạc nhiên">', 
                    '<img src="/core/menu/icon/sad.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Buồn">', 
                    '<img src="/core/menu/icon/angry.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Phẩn nộ">'), $type);
            }
		}
            $userid = $data['user_id'];
			$name = $data['name'];
            $het_han = date('d/m/Y', $data['end']);
            $a = $a+1;//số tt
        $json[] = array(
            $a,
            '<img src="https://graph.facebook.com/'.$userid.'/picture?width=30&amp;height=30" class="img img-circle img-thumbnail"><br><a href="//fb.com/'.$userid.'" target="_blank"><b>'.$name.'</b></a><br>'.$userid.'',
            $cmts,
			$sti,
            $type,
            $tokenstt,
			$tt,
			$limits,
			$useradd,
			$ghichu,
            $het_han,
            '<ul class="nav navbar-nav navbar-right pull-left">
            <li class="dropdown">
            <a class="btn btn-info" data-toggle="dropdown">CÀI ĐẶT</a>
            <ul class="dropdown-menu">
			<a class="btn btn-info" href="'.$domain.'/index.php?action=vip-bot&update='.$userid.'" title="Chỉnh sửa chương trình">Sửa</a> 
			<a class="btn btn-success" href="'.$domain.'/index.php?action=vip-bot&giahan='.$userid.'" title="Chỉnh sửa chương trình">Gia hạn</a> 
			<a onClick="startbot('.$userid.');" class="btn btn-warning">Chạy lại</a>
            <a onClick="xoabot('.$userid.');" class="btn btn-danger">Xoá</a>
			</ul>
            </li>
            </ul>',
			);
	}
	 }
	$response = array();
	$response['data'] = $json;
	echo json_encode($response);
}else{
    echo '<meta charset="utf-8" />Bạn không có quyền truy cập vào bản quyền';
}
?>