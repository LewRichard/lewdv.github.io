<?php
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
require("../system/config.php");
include "../system/functions.php";
$file = 'log.log';
$fileblock = 'block.log';
if(isset($_POST['mess'])){
	$post = $_POST['mess'];
	$message = addslashes($_POST['mess']);
	$message = htmlentities($message);
	$user_ip = $_SERVER['REMOTE_ADDR'];
	$time = date('H:i:s d-m-Y');
	$keynoibay = array(
	'dm','đm','đéo','Dm','Đm','dcm','đcm','vl','fuck',
	'djt','địt','lồn','loz','clm','cac','vc','cc','cặc',
	'djt','dit','đụ','cai lon','con cu','lol'
	);
	if($uname == $accoutadmin){
        $bikhoanb = false;
	}else{
        foreach($keynoibay as $keynb => $noibay){
            if(ereg($noibay,strtolower($post))){
                $bikhoanb = true;
            }
        }
	}
	$keyquangcao = array(
	'https','http','//','goo.gl','.asia','.com','.tk',
	'.net','.xyz','www.','.info','.org','.ga',
	'.top','.vn','.pro','.online','.club'
	);
	if($uname == $accoutadmin){
        $bikhoaqc = false;
	}else{
        foreach($keyquangcao as $keyqc => $quangcao){
            if(ereg($quangcao,strtolower($post))){
                $bikhoaqc = true;
            }
        }
	}
	$keyhack = array(
	'/>','</','script','hack'
	);
	if($uname == $accoutadmin){
        $bikhoahack = false;
	}else{
        foreach($keyhack as $keyh => $hack){
            if(ereg($hack,strtolower($post))){
			    $bikhoahack = true;
		    }
	    }
	}
	if($bikhoanb){
		$noidungblock = 'Tài Khoản: '.$uname.' || Id: '.$idctv.' || Nói Bậy Với Nội Dung: '.$_POST['mess'].' || Vào Lúc: '.$time;
		$opfile = @fopen($file,"a");
		@fwrite($opfile,$noidungblock);
		@fwrite($opfile,"\n");
		@fclose($opfile);
		echo'<script language="javascript">setTimeout(function(){toastr.error("Đừng nói bậy bạn ơi.", "Lời Nhắn");});</script>';
	}else if($bikhoaqc){
		$noidungblock = 'Tài Khoản: '.$uname.' || Id: '.$idctv.' || Quảng Cáo Với Nội Dung: '.$_POST['mess'].' || Vào Lúc: '.$time;
		$opfile = @fopen($file,"a");
		@fwrite($opfile,$noidungblock);
		@fwrite($opfile,"\n");
		@fclose($opfile);
		echo'<script language="javascript">setTimeout(function(){toastr.error("Đừng quảng cáo bạn ơi.", "Lời Nhắn");});</script>';
	}else if($bikhoahack){
		$opfile = @fopen($fileblock,"a");
		@fwrite($opfile,$idctv);
		@fwrite($opfile,"\n");
		@fclose($opfile);
		mysqli_query($conn, "INSERT INTO shoutbox(user, user_id, message, ip_address, date_time) VALUES('$uname', '$idctv', Thành Viên '$uname' Vừa Định Tấn Công Hệ Thống Và Đã Bị Khoá. Vui Lòng Không Thực Hiện Theo Thành Viên Này!, '$user_ip', '$time')");
		echo'<script language="javascript">setTimeout(function(){toastr.success("Gửi thành công.", "Lời Nhắn");});</script>';
	}else if(($uname == $accoutadmin)&&(ereg('/xoa',strtolower($post)))){
		$xoa = mysqli_query($conn, "DELETE FROM shoutbox");
		if($xoa){
		    $messenger = '<font color="red">'.$accoutadmin.' <i class="fa fa-check-square" aria-hidden="true" tille="Đã Xác Minh"></i></font> vừa xoá lịch sử trò chuyện';
		    mysqli_query($conn, "INSERT INTO shoutbox(user, user_id, message, ip_address, date_time) VALUES('$uname', '$idctv', '#xoa', '$user_ip', '$time')");
		    mysqli_query($conn, "INSERT INTO shoutbox(user, user_id, message, ip_address, date_time) VALUES('BOT', '$idctv', '$messenger', '$user_ip', '$time')");
		    echo'<script language="javascript">setTimeout(function(){toastr.success("Xoá ChatBox thành công.", "Lời Nhắn");});</script>';
		}
	}else{
		mysqli_query($conn, "INSERT INTO shoutbox(user, user_id, message, ip_address, date_time) VALUES('$uname', '$idctv', '$message', '$user_ip', '$time')");
		echo'<script language="javascript">setTimeout(function(){toastr.success("Gửi thành công.", "Lời Nhắn");});</script>';
	}
}
$req = mysqli_query($conn, "SELECT * FROM `shoutbox` ORDER BY `id` DESC LIMIT 5");
while($res = mysqli_fetch_assoc($req)) {
	$data = @file('camxuc.log');
	$i=0;
	foreach($data as $value){
		$i++;
		$ex = explode(' => ',$value);
		$kytu = str_replace('"','\\"',$ex[0]);
		$urlbt = trim($ex[1]);
		$res['message'] = str_replace($kytu,'<img src="'.$urlbt.'" alt="Biểu Tượng Cảm Xúc" height="20" width="20">', $res['message']); 
	}
?>
    <div class="list-group-item">
        <i class="fa fa-user"></i> <b><font color="<?php if($res['user'] == $accoutadmin){  echo'red';  }else{ echo'green'; } ;?>"><?=$res['user'];?> <?php if($res['user'] == $accoutadmin){  echo'<i class="fa fa-check-square" aria-hidden="true" tille="Đã Xác Minh"></i>';}?></font></b>:</a>
        <b> <?=$res['message'];?></b>
        <time><?=$res['date_time'];?></time>
    </div>
<?php } ?>