<?php
include "../system/config.php";
include "../system/functions.php";
if (isset($_GET['id'])){
    $id = $_GET['id'];
    $a = 0;
    $json = array();
    if($id == $idadmin){
        $get = "SELECT * FROM vip";
    }else{
        $get = "SELECT * FROM vip WHERE id_ctv=$id";
    }
    $result = mysqli_query($conn, $get);
    while ($data = mysqli_fetch_assoc($result)) {
        $userid = $data['user_id'];
		$han = $data['han'];
		$ghichu = $data['ghi_chu'];
		$time = $data['end'];
		$ser = $data['server'];
		$timed = $time - time();
		$conlai = round($timed/(24*3600));
		if ($conlai > 3){
			$tt = '<b><font color=green>Chạy <sup>'.$han.' tháng</sup></font></b>';
		}
		else if(($conlai == 3) || ($conlai == 2) || ($conlai ==1) || ($conlai == 0)){
			$tt = '<b><font color=blue>Còn '.$conlai.' ngày <sup>của '.$han.' tháng</sup></font></b>';
		}
		else if ($conlai < 0){
			$tt = '<b><font color=red>Hết '.$conlai.' ngày <sup>của'.$han.' tháng</sup></font></b>';
		}
		if($ser == 1){
			$sv = "<a class='btn btn-info'>1</a>";
		}else if($ser == 2){
			$sv = "<a class='btn btn-warning'>2</a>";
		}else if($ser == 3){
			$sv = "<a class='btn btn-success'>3</a>";
		}else if($ser == 4){
			$sv = "<a class='btn btn-danger'>4</a>";
		}else if($ser == 5){
			$sv = "<a class='btn btn-warning'>5</a>";
		}else if($ser == 6){
			$sv = "<a class='btn btn-success'>6</a>";
		}else{
			$sv = "<a class='btn btn-info'>7</a>";
		}
        $laydl = "SELECT * FROM package WHERE max = ".$data['max_like']." AND type='LIKE'";
        $resultt = mysqli_query($conn, $laydl);
        $datax = mysqli_fetch_assoc($resultt);
        $id = $data['id'];
        $userid = $data['user_id'];
        $het_han = date('d/m/Y', $data['end']);
        $a = $a+1;
        $json[] = array(
            $a,
            '<img src="https://graph.facebook.com/'.$data['user_id'].'/picture?width=30&amp;height=30" class="img img-circle img-thumbnail"><br><a href="//fb.com/'.$data['user_id'].'" target="_blank"><b>'.$data['name'].'</b></a><br>ID: '.$data['user_id'].'',
            $datax['name_likes'],
            ''.$data['likes'].' likes/lần',
            $tt,
			$sv,
			$ghichu,
            $het_han,
            '<ul class="nav navbar-nav navbar-right pull-left">
            <li class="dropdown">
            <a class="btn btn-info" data-toggle="dropdown">CÀI ĐẶT</a>
            <ul class="dropdown-menu">
			<a class="btn btn-info" href="'.$domain.'/index.php?action=vip-like&update='.$userid.'" title="Chỉnh sửa chương trình">Chỉnh sửa thông tin</a>
			<a class="btn btn-success" href="'.$domain.'/index.php?action=vip-like&giahan='.$userid.'" title="Chỉnh sửa chương trình">Gia hạn</a> 
            <a onClick="xoavip('.$userid.');" class="btn btn-danger">Xoá bỏ</a>
			</ul>
            </li>
            </ul>',
        );
    }
	$response = array();
	$response['data'] = $json;
	echo json_encode($response);
}else{
    echo '<meta charset="utf-8" />Bạn không có quyền truy cập vào bản quyền';
}
?>