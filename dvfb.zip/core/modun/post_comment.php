<?php
include "../system/config.php";
include "../system/functions.php";
if (isset($_GET['id'])){
    $id = $_GET['id'];
    $a = 0;
    $json = array();
    if($id == $idadmin){
        $get = "SELECT * FROM vipcmt";
    }else{
        $get = "SELECT * FROM vipcmt WHERE id_ctv=$id";
    }
        $result = mysqli_query($conn, $get);
        while ($data = mysqli_fetch_assoc($result)) {
            $userid = $data['user_id'];
            $z = $data['end'] - time();
            $id = $data['id'];
            $het_han = date('d/m/Y', $data['end']);
            if($data['status'] == '0'){
                $tt = '<font color="green">Đang chạy</font>';
            }else if($data['status'] == '1'){
                $tt = '<font color="red">Tạm dừng</font>';
            }else if($z <= 0){
                $tt = '<font color=red>Kết thúc</font>';
            }else if($ngay <= 5){
                $tt = '<font color=red>Sắp kết thúc</font>';
            }
            $type = $data['noi_dung'];
            if(strripos($data['noi_dung'], "\n")){
                $type = str_replace("\n", ",", $data['noi_dung']);
            }
            $laydl = "SELECT * FROM package WHERE max = ".$data['max_cmt']." AND type='CMT'";
            $resultt = mysqli_query($conn, $laydl);
            $datax = mysqli_fetch_assoc($resultt);
            $a = $a + 1;
        $json[] = array(
            $a,
            '<a href="//fb.com/'.$userid.'" target="_blank">'.$data['name'].'</a>',
            $datax['name_likes'],
            ''.$data['cmts'].' comments/5 phút',
            $tt,
            $het_han,
            '<a class="btn btn-success" href="'.$domain.'/index.php?action=vip-cmt&chitiet='.$userid.'" title="Xem chi tiết chương trình">Chi tiết</a> 
            <a class="btn btn-info" href="'.$domain.'/index.php?action=vip-cmt&update='.$userid.'" title="Chỉnh sửa chương trình">Chỉnh sửa</a> 
            <a onClick="xoa('.$userid.');" class="btn btn-danger">Xóa</a>',
        );
    }
	$response = array();
	$response['data'] = $json;
	echo json_encode($response);
}else{
    echo '<meta charset="utf-8" />Bạn không có quyền truy cập vào bản quyền';
}
?>