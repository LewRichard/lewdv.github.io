<div class="col-md-12">
        <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
            <div class="panel-heading">
                <button class="btn btn-info"><b>QUẢN LÝ VIPBOT</button> <a href="/index.php?action=vip-bot">+ Thêm gói mới</a></b>
            </div>
            <div class="panel-body">
            <div class="table-responsive">
                    <table id="vipbot" class="table" style="width:100%;"></table>
                </div>
            </div>
        </div>
</div>
<script type="text/javascript">
    function vipbot() {
        $("#vipbot").load('<?=$domain?>/core/modun/post_bot.php?id=<?=$idctv;?>');
    }
    $(document).ready(function(){
        vipbot();
    });
    function vipbot(){
        $('#vipbot').DataTable({
            destroy: true,
            "ordering": false,
            "order": [[ 0, "desc" ]],
            "pageLength": 5,
            "lengthMenu": [[5, 10, 25, 50, 100, -1], [5, 10, 25, 50, 100, "Tất cả"]],
            "ajax": "<?=$domain?>/core/modun/post_bot.php?id=<?=$idctv;?>",
            "columns": [
                {
                    title: "#"
                },
                {
                    title: "NAME"
                },
                {
                    title: "COMMENT"
                },
				{
                    title: "STICK"
                },
                {
                    title: "ICON"
                },
                {
                    title: "Token"
                },
				{
                    title: "STATUS"
                },
				{
                    title: "POST"
                },
				{
                    title: "USER-ADD"
                },
				{
                    title: "NOTE"
                },
                {
                    title: "HSD"
                },
                {
                    title: "SETTING"
                },
            ],
            "language": {
            	"sProcessing":   "Đang xử lý...",
            	"sLengthMenu":   "Xem _MENU_ mục",
            	"sZeroRecords":  "Không tìm thấy dòng nào phù hợp",
            	"sInfo":         "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
            	"sInfoEmpty":    "Đang xem 0 đến 0 trong tổng số 0 mục",
            	"sInfoFiltered": "(được lọc từ _MAX_ mục)",
            	"loadingRecords": "Đang tải lên...",
            	"sInfoPostFix":  "",
            	"sSearch":       "Tìm kiếm :",
            	"sUrl":          "",
            	"oPaginate": {
            		"sFirst":    "Đầu",
            		"sPrevious": "Trước",
            		"sNext":     "Tiếp",
            		"sLast":     "Cuối"
            	}
            }
        });
    }
    function xoabot(id) {
        if (confirm('Bạn có chắc chắn xóa UID BOT này? Dữ liệu không thể khôi phục.') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-bot&xoabot=' + id;
        } else {
            return false;
        }
    }
    function dungbot(id) {
        if (confirm('Bạn có chắc chắn tạm dừng BOT?') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-bot&dungbot=' + id;
        } else {
            return false;
        }
    }
    function startbot(id) {
        if (confirm('Bạn có chắc chắn tiếp tục chạy lại BOT?') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-bot&startbot=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
// xử lý dừng bot
if (isset($_GET['dungbot'])) {
    $id_dung = $_GET['dungbot'];
    $get = "SELECT * FROM vipreaction WHERE user_id = $id_dung";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
	if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>alert('Khách hàng này không phải bạn quản lý, nếu bạn cho rằng hệ thống nhầm lẫn vui lòng liên hệ admin!'); window.location='index.php';</script>";
        } else {
				$sql = "UPDATE vipreaction SET status = 1 WHERE user_id = $id_dung";
				if (mysqli_query($conn, $sql)) {
				header('Location: /index.php');
				}
			}
	}else {
		$sql = "UPDATE vipreaction SET status = 1 WHERE user_id = $id_dung";
        if (mysqli_query($conn, $sql)) {
            header('Location: /index.php');
			}
		}
}
// xử lý chạy lại bot
if (isset($_GET['startbot'])) {
    $id_start = $_GET['startbot'];
    $get = "SELECT * FROM vipreaction WHERE user_id = $id_start";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
	if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>alert('Khách hàng này không phải bạn quản lý, nếu bạn cho rằng hệ thống nhầm lẫn vui lòng liên hệ admin!'); window.location='index.php';</script>";
        }
        else {
				$sql = "UPDATE vipreaction SET status = 0 WHERE user_id = $id_start";
				if (mysqli_query($conn, $sql)) {
				header('Location: /index.php?action=admin-bot');
				}
			}
	}else{
		$sql = "UPDATE vipreaction SET status = 0 WHERE user_id = $id_start";
        if (mysqli_query($conn, $sql)) {
            header('Location: /index.php?action=admin-bot');
			}
		}
}
// xử lý xoá bot
if (isset($_GET['xoabot'])) {
	$getmem = "SELECT level FROM member WHERE id_ctv = $idctv";
    $res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
    $idbot = $_GET['xoabot'];
    $get = "SELECT * FROM vipreaction WHERE user_id = $idbot";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $user_id = $check['user_id'];
    $name = $check['name'];
	$time = time();
	$ti = $check['end'];
	$timed = $ti - $time;
	$conlai = round($timed/(24*3600));
	$ngaydu = $conlai - 3; // trừ 3 ngày
	$goi = $check['limit_react'];
	if(($goi == '1') || ($goi == '2') || ($goi == '3') || ($goi == '4') || ($goi == '5') || ($goi == '6')){
		$g = '100000';
	}
	if($level == 2){
			$hoantien = $ngaydu * $g/30 * 0.4;// giảm 60% cho cộng tác viên
		}else if($level == 3){
			$hoantien = $ngaydu * $g/30 * 0.3;// giảm 70% cho đại lý cấp 1
		}else if($level == 4){
			$hoantien = $ngaydu * $g/30 * 0.2;// giảm 80% cho tổng đại lý
		}else{
			$hoantien = $ngaydu * $g/30;
		}
if($ngaydu <= 3){
		echo "<script>swal({html: true,title: 'Thất bại',text: 'Gói Vip Bot này sắp hết hạn, không thể xoá!',type: 'success',});</script>";
}else{
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
					echo "<script>swal({html: true,title: 'Thất bại',text: 'Đã xảy ra lỗi, vui lòng liên hệ Admin.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="2; URL=/">';    
        }
		else {
            $sql = "DELETE FROM vipreaction WHERE user_id = $idbot";
            if (mysqli_query($conn, $sql)) {
				mysqli_query($conn, "UPDATE member SET bill = bill + $hoantien WHERE id_ctv = $ctv");
                $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";      
                if(mysqli_query($conn, $up)){
					$nd = "Vip Bot";
					$lydo = "Chưa Rõ";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$ctv', '$name', '$nd', '$time', '$lydo')";
                    if(mysqli_query($conn, $his)){
						echo "<script>swal({html: true,title: 'Thành công',text: 'Xoá Vip Bot thành công, bạn được hoàn ".number_format($hoantien)." đồng.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="2; URL=/index.php?action=admin-bot">';
                        }
                    }
                }
            }
        }
    else{
         $sql = "DELETE FROM vipreaction WHERE user_id = $idbot";
            if (mysqli_query($conn, $sql)) {
					mysqli_query($conn, "UPDATE member SET bill = bill + $hoantien WHERE id_ctv = $ctv");
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
                if(mysqli_query($conn, $up)){
					$nd = "Vip Bot";
					$lydo = "Chưa Rõ";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$ctv', '$name', '$nd', '$time', '$lydo')";
                    if(mysqli_query($conn, $his)){
						echo "<script>swal({html: true,title: 'Thành công',text: 'Xoá Vip Bot thành công, bạn được hoàn ".number_format($hoantien)." đồng.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="2; URL=/index.php?action=admin-bot">';
                        }
                    }
                }
            }
	}
}
 // hết vip bot
 ?>