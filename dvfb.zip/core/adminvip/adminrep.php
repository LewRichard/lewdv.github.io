<div class="col-md-12">
        <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
            <div class="panel-heading">
                <button class="btn btn-warning"><b>QUẢN LÝ VIPREP</button> <a href="/index.php?action=auto-rep">+ Thêm gói mới</a></b>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="viprep" class="table" style="width:100%;"></table>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
    function viprep() {
        $("#viprep").load('<?=$domain?>/core/modun/post_autorep.php?id=<?=$idctv;?>');
    }
    $(document).ready(function(){
        viprep();
    });
    function viprep(){
        $('#viprep').DataTable({
            destroy: true,
            "ordering": false,
            "order": [[ 0, "desc" ]],
            "pageLength": 5,
            "lengthMenu": [[5, 10, 25, 50, 100, -1], [5, 10, 25, 50, 100, "Tất cả"]],
            "ajax": "<?=$domain?>/core/modun/post_autorep.php?id=<?=$idctv;?>",
            "columns": [
                {
                    title: "#"
                },
                {
                    title: "Tên"
                },
                {
                    title: "Bình luận"
                },
                {
                    title: "Token"
                },
				{
                    title: "Trạng thái"
                },
				{
                    title: "Ghi chú"
                },
                {
                    title: "Ngày hết hạn"
                },
                {
                    title: "Công cụ"
                },
            ],
            "language": {
            	"sProcessing":   "Đang xử lý...",
            	"sLengthMenu":   "Xem _MENU_ mục",
            	"sZeroRecords":  "Không tìm thấy dòng nào phù hợp",
            	"sInfo":         "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
            	"sInfoEmpty":    "Đang xem 0 đến 0 trong tổng số 0 mục",
            	"sInfoFiltered": "(được lọc từ _MAX_ mục)",
            	"loadingRecords": "Đang tải lên...",
            	"sInfoPostFix":  "",
            	"sSearch":       "Tìm kiếm :",
            	"sUrl":          "",
            	"oPaginate": {
            		"sFirst":    "Đầu",
            		"sPrevious": "Trước",
            		"sNext":     "Tiếp",
            		"sLast":     "Cuối"
            	}
            }
        });
    }
    function xoarep(id) {
        if (confirm('Bạn có chắc chắn xóa UID viprep này?') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-rep&xoarep=' + id;
        } else {
            return false;
        }
    }
    function dungrep(id) {
        if (confirm('Bạn có chắc chắn tạm dừng viprep?') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-rep&dungrep=' + id;
        } else {
            return false;
        }
    }
    function startrep(id) {
        if (confirm('Bạn có chắc chắn tiếp tục chạy lại viprep?') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-rep&startrep=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
// xử lý dừng bot
if (isset($_GET['dungrep'])) {
    $id_dung = $_GET['dungrep'];
    $get = "SELECT id_ctv,user_id, end FROM autorep WHERE user_id = $id_dung";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $user_id = $check['user_id'];
    $end = $check['end'];
	if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>alert('Khách hàng này không phải bạn quản lý, nếu bạn cho rằng hệ thống nhầm lẫn vui lòng liên hệ admin!'); window.location='index.php';</script>";
        } else {
				$sql = "UPDATE autorep SET status = 1 WHERE user_id = $id_dung";
				if (mysqli_query($conn, $sql)) {
				header('Location: /index.php?action=admin-rep');
				}
			}
	}else {
		$sql = "UPDATE autorep SET status = 1 WHERE user_id = $id_dung";
        if (mysqli_query($conn, $sql)) {
            header('Location: /index.php?action=admin-rep');
			}
		}
}
// xử lý chạy lại bot
if (isset($_GET['startrep'])) {
    $id_start = $_GET['startrep'];
    $get = "SELECT id_ctv,user_id, end FROM autorep WHERE user_id = $id_start";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $user_id = $check['user_id'];
    $end = $check['end'];
	if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>alert('Khách hàng này không phải bạn quản lý, nếu bạn cho rằng hệ thống nhầm lẫn vui lòng liên hệ admin!'); window.location='index.php';</script>";
        }
        else {
				$sql = "UPDATE autorep SET status = 0 WHERE user_id = $id_start";
				if (mysqli_query($conn, $sql)) {
				header('Location: /index.php?action=admin-rep');
				}
			}
	}else{
		$sql = "UPDATE autorep SET status = 0 WHERE user_id = $id_start";
        if (mysqli_query($conn, $sql)) {
            header('Location: /index.php?action=admin-rep');
			}
		}
}
// xử lý xoá bot
if (isset($_GET['xoarep'])) {
    $idrep = $_GET['xoarep'];
    $get = "SELECT * FROM autorep WHERE user_id = $idrep";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $user_id = $check['user_id'];
    $name = $check['name'];
	$time = time();
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
					echo "<script>swal({html: true,title: 'Thất bại',text: 'Đã xảy ra lỗi, vui lòng liên hệ Admin.',type: 'success',});</script>";
					echo '<meta http-equiv=refresh content="2; URL=/">';    
        }
		else {
            $sql = "DELETE FROM autorep WHERE user_id = $idrep";
            if (mysqli_query($conn, $sql)) {
                $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";      
                if(mysqli_query($conn, $up)){
					$nd ="Vip Rep Cmt";
					$lydo = "Chưa Rõ";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$ctv', '$name', '$nd', '$time', '$lydo')";
                    if(mysqli_query($conn, $his)){
						echo "<script>swal({html: true,title: 'Thành công',text: 'Đã xoá khỏi hệ thống.',type: 'success',});</script>";
                        }
                    }
                }
            }
        }
    else{
         $sql = "DELETE FROM autorep WHERE user_id = $idrep";
            if (mysqli_query($conn, $sql)) {
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
                if(mysqli_query($conn, $up)){
					$nd = "Vip Rep Cmt";
					$lydo = "Chưa Rõ";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$ctv', '$name', '$nd', '$time', '$lydo')";
                    if(mysqli_query($conn, $his)){
						echo "<script>swal({html: true,title: 'Thành công',text: 'Đã xoá khỏi hệ thống.',type: 'success',});</script>";
                        }
                    }
                }
            }
	}
 // hết vip rep
 ?>