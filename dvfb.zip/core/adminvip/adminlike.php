<div class="col-md-12">
        <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
            <div class="panel-heading">
                <button class="btn btn-success"><b>QUẢN LÝ VIPLIKE</button> <a href="/index.php?action=vip-like">+ Thêm gói mới</a></b>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="vip" class="table" style="width:100%;"></table>
                </div>
            </div>
        </div>
</div>
<script type="text/javascript">
    function load_vip() {
        $("#vip").load('<?=$domain?>/core/modun/post_like.php?id=<?=$idctv;?>');
    }
    $(document).ready(function(){
        load_vip();
    });
    function load_vip(){
        $('#vip').DataTable({
            destroy: true,
            "ordering": false,
            "order": [[ 0, "desc" ]],
            "pageLength": 5,
            "lengthMenu": [[5, 10, 25, 50, 100, -1], [5, 10, 25, 50, 100, "Tất cả"]],
            "ajax": "<?=$domain?>/core/modun/post_like.php?id=<?=$idctv;?>",
            "columns": [
                {
                    title: "#"
                },
                {
                    title: "Tên"
                },
                {
                    title: "Gói"
                },
                {
                    title: "Tốc độ"
                },
                {
                    title: "Trạng thái"
                },
				{
                    title: "Server"
                },
				{
                    title: "Ghi chú"
                },
                {
                    title: "Ngày hết hạn"
                },
                {
                    title: "Công cụ"
                },
            ],
            "language": {
            	"sProcessing":   "Đang xử lý...",
            	"sLengthMenu":   "Xem _MENU_ mục",
            	"sZeroRecords":  "Không tìm thấy dòng nào phù hợp",
            	"sInfo":         "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
            	"sInfoEmpty":    "Đang xem 0 đến 0 trong tổng số 0 mục",
            	"sInfoFiltered": "(được lọc từ _MAX_ mục)",
            	"loadingRecords": "Đang tải lên...",
            	"sInfoPostFix":  "",
            	"sSearch":       "Tìm kiếm :",
            	"sUrl":          "",
            	"oPaginate": {
            		"sFirst":    "Đầu",
            		"sPrevious": "Trước",
            		"sNext":     "Tiếp",
            		"sLast":     "Cuối"
            	}
            }
        });
    }
    function xoavip(id) {
        if (confirm('Bạn có chắc chắn muốn xóa UID LIKE này? Dữ liệu không thể khôi phục.') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-like&xoavip=' + id;
        } else {
            return false;
        }
    }
	function huyvip(id) {
        if (confirm('Bạn có chắc chắn muốn huỷ UID LIKE này? Dữ liệu không thể khôi phục.') == true) {
            window.location = '<?=$domain;?>/index.php?action=admin-like&huyvip=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
if (isset($_GET['xoavip'])) {
	$getmem = "SELECT level FROM member WHERE id_ctv = $idctv";
    $res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
    $id = $_GET['xoavip'];
    $get = "SELECT * FROM vip WHERE user_id = $id";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
	$name = $check['name'];
    $ctv = $check['id_ctv'];
    $user_id = $check['user_id'];
	$time = time();
	$ti = $check['end'];
	$timed = $ti - $time;
	$conlai = round($timed/(24*3600));
	$ngaydu = $conlai - 3; // trừ 3 ngày
	$goi = $check['max_like'];
	if ($goi == '50'){
		$g = '50000';
	}else if($goi == '70'){
		$g = '70000';
	}else if($goi == '100'){
		$g = '100000';
	}
	else if($goi == '150'){
		$g = '150000';
	}
	else if($goi == '200'){
		$g = '200000';
	}
	else if($goi == '250'){
		$g = '250000';
	}
	else if($goi == '300'){
		$g = '300000';
	}else{
		$g = '500000';
	}
	if($level == 2){
			$hoantien = $ngaydu * $g/30 * 0.5; // trừ 50% cho cộng tác viên
	}else if($level == 3){
			$hoantien = $ngaydu  * $g/30 * 0.4; // trừ 60% cho đại lý
	}else{
			$hoantien = $ngaydu * $g/30; // không trừ cho thành viên
		}
		// xét hạn còn lại có được phép xoá hay không
	if($ngaydu <= 3){
		echo "<script>swal({html: true,title: 'Thất bại',text: 'Gói Vip Like này sắp hết hạn, không thể xoá!',type: 'success',});</script>";
	}else{
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
					echo "<script>swal({html: true,title: 'Thất bại',text: 'Đã xảy ra lỗi, vui lòng liên hệ Admin.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="2; URL=/">';    
        }
		else {
            $sql = "DELETE FROM vip WHERE user_id = $id";
            if (mysqli_query($conn, $sql)) {
				
                $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";    
                if(mysqli_query($conn, $up)){
					$nd = "Vip Like";
					$lydo = "Chưa Rõ";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$ctv', '$name', '$nd', '$time', '$lydo')";
                    if(mysqli_query($conn, $his)){
						echo "<script>swal({html: true,title: 'Thành công',text: 'Đã xoá khỏi hệ thống.',type: 'success',});</script>";
                        }
                    }
                }
            }
        }
    else{
         $sql = "DELETE FROM vip WHERE user_id = $id";
            if (mysqli_query($conn, $sql)) {
					mysqli_query($conn, "UPDATE member SET bill = bill + $hoantien WHERE id_ctv = $ctv");
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
                if(mysqli_query($conn, $up)){
					$nd = "Vip Like";
					$lydo = "Chưa Rõ";
					$his = "INSERT INTO lichsuxoavip(user_id, id_ctv, name, vip, time, lydo) VALUES('$user_id', '$ctv', '$name', '$nd', '$time', '$lydo')";
                    if(mysqli_query($conn, $his)){
						echo "<script>swal({html: true,title: 'Thành công',text: 'Huỷ Vip Like thành công, bạn được hoàn ".number_format($hoantien)." đồng.',type: 'success',});</script>";
                        }
                    }
                }
            }
	}
}
?>

