<?php
if($uname != $accoutadmin){
	if ($idctv != $idvip) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
	}
}
?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">DANH SÁCH ĐẠI LÝ - CỘNG TÁC VIÊN</h3>
        </div>
        <div class="panel-body">
            <div class="slimscrollleft">
                <div class="table-responsive">
                    <table class="table table-responsive">
                        <thead>
                            <tr style="color:#006699" role="row">
                                <th>#</th>
                                <th>TÊN</th>
                                <th>CHỨC VỤ</th>
								<th>FACEBOOK</th>
								<th>SỐ DƯ</th>
								<th>SỐ GÓI ĐÃ CÀI</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $a = 0;
                        $get = "SELECT * FROM member WHERE boss=25";
                        $result = mysqli_query($conn, $get);
                        while ($x = mysqli_fetch_assoc($result)) {
                            $id = $x['id'];
							$username = $x['username'];
							$level = $x['level'];
							$idfb = $x['idfb'];
							$num_id = $x['num_id'];
                            $a = $a + 1;
							if($level == 1){
								$lv = "<a class='btn btn-danger'>Thành Viên</a>";
							}elseif($level == 2){
								$lv = "<a class='btn btn-warning'>Cộng Tác Viên</a>";
							}elseif($level == 3){
								$lv = "<a class='btn btn-info'>Đại Lý</a>";
							}else{
							$lv = "<a class='btn btn-success'>Tổng Đại Lý</a>";	
							}
                        ?>
                            <tr>
                                <td><?php echo $a; ?></td>
                                <td><?php echo $username; ?></td>
								<td><?php echo $lv; ?></td>
								<td><?php echo "<a href='https://fb.com/$idfb' target='_blank'>$idfb</a>"; ?></td>
                                <td><?=number_format($x['bill']);?> đồng</td>
								<td><?php echo $num_id; ?></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>