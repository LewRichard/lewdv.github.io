<div class="col-md-4">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">TOP 10 GIAO DỊCH | ĐANG ONLINE: <?php echo number_format(mt_rand(4,8)); ?></h3>
        </div>
        <div class="panel-body">
            <div class="slimscrollleft">
                <div class="table-responsive">
                    <table class="table table-responsive">
                        <thead>
                            <tr style="color:#006699" role="row">
                                <th>#</th>
                                <th>USER</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $a = 0;
                        $get = "SELECT * FROM history ORDER BY id DESC LIMIT 10";
                        $result = mysqli_query($conn, $get);
                        while ($x = mysqli_fetch_assoc($result)) {
                            $id = $x['id'];
							$us = $x['user'];
							$level = $x['level'];
							//$use = "admin";
							$nd = $x['vip'];
							if($nd == 1){
								$ndung ="<a class='btn btn-success'>Mua Vip Bot</a>";
							}
							if($nd == 2){
								$ndung ="<a class='btn btn-success'>Mua Vip Like</a>";
							}
							if($nd == 3){
								$ndung ="<a class='btn btn-success'>Mua Vip Rep</a>";
							}
							if($nd == 4){
								$ndung ="<a class='btn btn-success'>Nạp Tiền Card</a>";
							}
							if($nd == 5){
								$ndung ="<a class='btn btn-success'>Chuyển Tiền</a>";
							}
							if($nd == 6){
								$ndung ="<a class='btn btn-success'>Nhận Tiền</a>";
							}
							if($nd == 7){
								$ndung ="<a class='btn btn-success'>Nhận Thưởng</a>";
							}
							if($nd == 8){
								$ndung ="<a class='btn btn-success'>Gia Hạn VipBot</a>";
							}
							if($nd == 9){
								$ndung ="<a class='btn btn-success'>Gia Hạn VipLike</a>";
							}
								if($level == 1){
								$u = "<a class='btn btn-danger'>$us</a>";
								}elseif($level == 2){
								$u = "<a class='btn btn-warning'>$us</a>";
								}elseif($level == 3){
								$u = "<a class='btn btn-info'>$us</a>";
								}else{
								$u = "<a class='btn btn-success'>$us</a>";	
								}
                          //  $time = date("d-m H:i", $t);
                            $a = $a + 1;
                        ?>
                            <tr>
                                <td><?php echo $a; ?></td>
                                <td><?php echo $u; ?></td>
                                <td><?php echo $ndung; ?></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>