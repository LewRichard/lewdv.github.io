<?php
include "config.php";
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
$today = date('d-m-Y');
define('COPYRIGHT', '0858 743 369');
$getsetting = "SELECT * FROM setting";
$resultsetting = mysqli_query($conn, $getsetting);
$setting = mysqli_fetch_assoc($resultsetting);
if (isset($_SERVER['HTTP_CLIENT_IP']))
$remoteip = $_SERVER['HTTP_CLIENT_IP'];
else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
$remoteip = $_SERVER['HTTP_X_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_X_FORWARDED']))
$remoteip = $_SERVER['HTTP_X_FORWARDED'];
else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
$remoteip = $_SERVER['HTTP_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_FORWARDED']))
$remoteip = $_SERVER['HTTP_FORWARDED'];
else if(isset($_SERVER['REMOTE_ADDR']))
$remoteip = $_SERVER['REMOTE_ADDR'];
else
$remoteip = 'UNKNOWN';
$sqll = "SELECT id_ctv FROM member WHERE username='$accoutadmin'";
$resultt = mysqli_query($conn, $sqll);
$user = mysqli_fetch_assoc($resultt);
$idadmin = $user['id_ctv'];
//mysqli_query($conn, "UPDATE member SET bill=100000000 WHERE username='$accoutadmin'");
$hour = date("G");
if ((isset($_SESSION['login']) && $_SESSION['login'] == 'ok')){
	
    $action = true;
    $idctv = $_SESSION['id_ctv'];
	$idvip = 25;
    $sql = "SELECT * FROM member WHERE id_ctv = $idctv";
    $result = mysqli_query($conn, $sql);
    $n = mysqli_fetch_assoc($result);
    $sdt = $n['sdt'];
    $ip = $n['ip'];
    $diachi = $n['diachi'];
    $email = $n['email'];
    $idfb = $n['idfb'];
    $uname = $n['username'];
    $bill = $n['bill'];

    $getmember ="SELECT COUNT(*) FROM member";
    $resultmember = mysqli_query($conn, $getmember);
    $member = mysqli_fetch_assoc($resultmember)['COUNT(*)'];
    
    $getlike ="SELECT COUNT(*) FROM vip WHERE id_ctv = $idctv";
    $resultlike = mysqli_query($conn, $getlike);
    $like = mysqli_fetch_assoc($resultlike)['COUNT(*)'];
    
    $getcmt ="SELECT COUNT(*) FROM vipcmt WHERE id_ctv = $idctv";
    $resultcmt = mysqli_query($conn, $getcmt);
    $cmt = mysqli_fetch_assoc($resultcmt)['COUNT(*)'];
    
    $getbot ="SELECT COUNT(*) FROM vipreaction WHERE id_ctv = $idctv";
    $resultbot = mysqli_query($conn, $getbot);
    $bot = mysqli_fetch_assoc($resultbot)['COUNT(*)'];
    
    $getrep ="SELECT autorep FROM member WHERE id_ctv = $idctv";
    $resultrep = mysqli_query($conn, $getrep);
    $rep = mysqli_fetch_assoc($resultrep);
}
?>