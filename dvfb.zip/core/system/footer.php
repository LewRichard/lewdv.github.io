                    </div>
                </div>
                <footer class="footer text-right">
<div id="fb-root"></div>
<!--<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js#xfbml=1&version=v2.12&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="138840996847100"> 
</div>-->
                    2017 © <?=$_SERVER['HTTP_HOST']?>
					
                </footer>
            </div>
        </div>
<title><?=$titles;?> - <?=$setting['tile'];?></title>
<?=$setting['script'];?>
        <script>
            var resizefunc = [];
        </script>
        <script src="<?=$domain;?>/assets/datatables/jquery.dataTables.min.js"></script>
        <script src="<?=$domain;?>/assets/datatables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function() {
                $('.data_table').dataTable();
            });
        </script>
        <script src="<?=$domain;?>/js/bootstrap.min.js"></script>
        <script src="<?=$domain;?>/js/waves.js"></script>
        <script src="<?=$domain;?>/js/wow.min.js"></script>
        <script src="<?=$domain;?>/<?=$domain;?>/js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="<?=$domain;?>/js/jquery.scrollTo.min.js"></script>
        <script src="<?=$domain;?>/assets/jquery-detectmobile/detect.js"></script>
        <script src="<?=$domain;?>/assets/fastclick/fastclick.js"></script>
        <script src="<?=$domain;?>/assets/jquery-slimscroll/jquery.slimscroll.js"></script>
        <script src="<?=$domain;?>/assets/jquery-blockui/jquery.blockUI.js"></script>
        <script src="<?=$domain;?>/assets/sweet-alert/sweet-alert.min.js"></script>
        <script src="<?=$domain;?>/assets/sweet-alert/sweet-alert.init.js"></script>
        <!-- CUSTOM JS -->
        <script src="<?=$domain;?>/js/jquery.app.js"></script>
    
    </body>
</html>