<?php
if ($uname != $accoutadmin) {
    echo "<script>window.location='/index.php?action=trang-loi';</script>";
}
?>
<?php $titles='CPANEL ADMIN';?>
<script>
    function check(id, me, num, username) {
        if (id == me) {
            alert('Không thể xóa ID này.');
            return false;
        } else if(id == 1){
            alert('Không thể xóa ID này.');
            return false;
        } else if(me != 1){
            alert('Không thể xóa ID này.');
            return false;
        } else if (num > 0) {
            alert('Thành viên này đang cài ' + num + ' id trên hệ thống.');
            return false;
        } else {
            if (confirm('Bạn chắc chắn xóa member này') == true) {
                window.location = '<?=$domain;?>/index.php?action=xoa-member&id='+id+'';
            } else {
                return false;
            }
        }
    }
    function check1(me,id, type, username) {
        if(type == 'lock'){
            if (id == me) {
            alert('Không thể khóa ID này.');
            return false;
        } else if(id == 1){
            alert('Không thể khóa ID này.');
            return false;
        } else if(me != 1){
            alert('Không thể khóa ID này.');
            return false;
        }else{
            window.location = '<?=$domain;?>/index.php?action=chinh-sua-member&id='+id+'&type=lock';
        }
    }
}
</script>
<?php
if(isset($_GET['edit_user'])){
    $id = $_GET['edit_user'];
    if(isset($_POST['submit'])){
        $password = $_POST['password'];
        $email = $_POST['email'];
        $sdt = $_POST['sdt'];
        $idfb = $_POST['idfb'];
        $bill = $_POST['bill'];
		$level = $_POST['level'];
        mysqli_query($conn, "UPDATE member SET password='$password', level='$level', email='$email', sdt='$sdt', idfb='$idfb',bill='$bill' WHERE id_ctv = '$id'");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Cập nhập thành công.',type: 'success',});</script>";
		echo '<meta http-equiv=refresh content="1; URL=/index.php?action=user">';
    }
    $user_info = mysqli_query($conn, "SELECT * FROM member WHERE id_ctv = '{$_GET['edit_user']}'");
    $info_fetch = mysqli_fetch_assoc($user_info);
	$level = $info_fetch['level'];
if($level == 2){
	$tt = '<font color=green>Cộng Tác Viên</font>';
}elseif($level == 3){
	$tt = '<font color=blue>Đại Lý</font>';
}elseif($level == 4){
	$tt = '<font color=red>Tổng Đại Lý</font>';
}
else{
	$tt = '<font color=black>Thành Viên</font>';
}
?>
<?php $titles='CHỈNH SỬA USER';?>
<div class="panel panel-default">
  <div class="panel-heading">Chỉnh sửa thành viên</div>
<div class="panel-body form-horizontal payment-form">
<form action="" method="POST">
                    <div class="form-group">
                        <label for="username" class="col-sm-3 control-label">Tên đăng nhập</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="username" name="username" value="<?=$info_fetch['username']?>" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label">Mật khẩu</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="password" name="password" value="<?=$info_fetch['password']?>">
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="email" class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" id="email" name="email" value="<?=$info_fetch['email']?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="sdt" class="col-sm-3 control-label">Số điện thoại</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" id="sdt" name="sdt" value="<?=$info_fetch['sdt']?>">
                        </div>
                    </div>   

                    <div class="form-group">
                        <label for="idfb" class="col-sm-3 control-label">ID Facebook</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" id="idfb" name="idfb" value="<?=$info_fetch['idfb']?>">
                        </div>
                    </div>   
                    <div class="form-group">
                        <label for="bill" class="col-sm-3 control-label">Tiền</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" id="bill" name="bill" value="<?=$info_fetch['bill']?>">
                        </div>
                    </div>   
					<div class="form-group">
                        <label>Chức vụ (<?php echo $tt; ?>)</label>
                        <select name="level" class="form-control">
							<option value="1">Thành viên</option>
							<option value="2">Cộng tác viên</option>
							<option value="3">Đại lý</option>
							<option value="4">Tổng Đại Lý</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12 text-right">
                            <button type="submit" name="submit" class="btn btn-success preview-add-button">
                                <span class="glyphicon glyphicon-plus"></span> Cập nhật thông tin
                            </button>
                        </div>
                    </div>
                </div> 
</div>
</form>
</div>
</div>
<?php exit(); } ?>
<div class="container">
    <div class="col-md-12 col-lg-12">
        <div class="panel panel-info">
            <div class="panel-heading"><h3 class="panel-title">Quản lý thành viên</h3></div>
            <div class="pane-body">
                <div class="slimscrollleft">
                <div class="table-responsive">
                    <table class="table table-responsive" style="width: : 100px !important; overflow: scroll;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Sđt</th>
                                <th>Chức vụ</th>
                                <th>Số dư</th>
                                <th>Id đã cài</th>
                                <th>Công cụ</th>
                            </tr>
                        </thead>
                        <tbody>
<?php
$a = 0;
$get = "SELECT * FROM member";
$result = mysqli_query($conn, $get);
while ($x = mysqli_fetch_assoc($result)) {
    $id = $x['id_ctv'];
    $num = $x['num_id'];
    $username = $x['username'];
	$level = $x['level'];
	if($level == 2){
	$tt = '<a class="btn btn-warning">CỘNG TÁC VIÊN</a>';
	}elseif($level == 3){
		$tt = '<a class="btn btn-info">ĐẠI LÝ</a>';
	}elseif($level == 4){
		$tt = '<a class="btn btn-success">TỔNG ĐẠI LÝ</a>';
	}
	else{
		$tt = '<a class="btn btn-danger">Thành Viên</a>';
	}
    $z = '<a onClick="check1('.$idctv.','.$id.','."'lock'".','. "'$username'".')" class="btn btn-danger btn-xs" data-toggle="tooltip" data-placement="top" title="" data-original-title="Khóa"><i class="fa fa-lock"></i></a>';
    if ($x['status'] == -1) {
        $z = "<a href='/index.php?action=chinh-sua-member&id=$id&type=unlock' class='btn btn-success btn-xs' data-toggle='tooltip' data-placement='top' title='' data-original-title='Mở khóa'><i class='fa fa-unlock-alt'></i></a>";
    }
    $a = $a+1;
?>
                            <tr>
                                <td><?=$a;?></td>
                                <td><?=$x['username'];?></td>
                                <td><?=$x['password'];?></td>
                                <td><?=$x['sdt'];?></td>
								<td><?=$tt; ?></td>
                                <td><?=number_format($x['bill']);?> đồng</td>
                                <td><?=number_format($x['num_id']);?> id</td>
                                <td style="text-align:center">
                                    <a href="<?=$domain;?>/index.php?action=user&edit_user=<?=$id?>" class="btn-success btn btn-xs" data-toggle="tooltip" data-placement="top" title="" data-original-title="Sửa"><i class="fa fa-pencil"></i></a>
                                    <?=$z ?>
                                    <a type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#monney<?=$x['id_ctv'];?>"><i class="fa fa-plus"></i></a>
                                    <a href="<?=$domain;?>/index.php?action=reset-pass&id=<?=$id;?>" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="top" title="" data-original-title="ResetPass"><i class="fa fa-refresh"></i></a>
                                    <a href="#" onclick="check(<?=$id.','.$idctv.','.$num.','."'$username'" ?>);" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="top" title="" data-original-title="Xóa"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
<?php
    if (isset($_POST['monney'])) {
        $username = $_POST['username'];
        $get = "SELECT id_ctv FROM member WHERE username='$username'";
        $result = mysqli_query($conn, $get);
        $x = mysqli_fetch_assoc($result);
        $idcttv = $x['id_ctv'];
        $money = $_POST['money'];
        $time = time();
        if($_POST['money'] == 0){
            echo "<script>swal({html: true,title: 'Thất bại',text: 'Số tiền không hợp lệ.',type: 'error',});</script>";
        }else{
            mysqli_query($conn, "UPDATE member SET bill = bill + $money WHERE id_ctv='$idcttv'");
            echo "<script>swal({html: true,title: 'Thành công',text: 'Cộng tiền thành công.',type: 'success',});</script>";
            echo '<meta http-equiv=refresh content="1; URL=">';
        }
    }
?>
        <div class="modal fade" id="monney<?=$x['id_ctv'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h3 class="modal-title">CỘNG TIỀN</h3>
                    </div>
                    <div class="modal-body">
                        <form action="#" method="post">
                            <div class="box-body">
                                <div class="form-group">
                                    <label>Tên tài khoản:</label>
                                        <input type="text" class="form-control" name="username" placeholder="eg. <?=$accoutadmin;?>" value="<?=$username;?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Số tiền (VNĐ):</label>
                                        <input type="number" class="form-control" name="money" placeholder="eg. 1000000" required=""/>
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="monney" class="btn btn-primary">Xác nhận</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                    </div>
                        </form>
                    </div>
                </div>
            </div>
		</div>
<?php } ?>
                        </tbody>
                    </table>
            </div>
            </div>
        </div>
    </div>
    </div>
    <div class="col-md-12">
        <div class="panel panel-warning">
            <div class="panel-heading"><h3 class="panel-title" style="color: white;">Thêm thành viên</h3></div>
            <div class="panel-body">
                <form method="post">
                    <div class="form-group">
                        <label for="username">Tên đăng nhập:</label>
                            <input type="text" class="form-control" name="username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>" placeholder="Ví dụ: admin">
                    </div>
                    <div class="form-group">
                        <label for="sdt">Email</label>
                        <input type="email" class="form-control" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" placeholder="Ví dụ: admin@gmail.com" name="email" required="">
                    </div>
                    <div class="form-group">
                        <label for="sdt">Số điện thoại</label>
                        <input type="number" class="form-control" value="<?php echo isset($_POST['sdt']) ? $_POST['sdt'] : ''; ?>" placeholder="Ví dụ: 0982 890 996" name="sdt" required="">
                    </div>
                    <div class="form-group">
                        <label for="idfb">UID Facebook</label>
                        <input type="number" class="form-control" value="<?php echo isset($_POST['idfb']) ? $_POST['idfb'] : ''; ?>" placeholder="Ví dụ: 100004165955485" name="idfb" required="">
                    </div>
                    <div class="form-group">
                        <label for="password">Nhập mật khẩu:</label>
                            <input type="text" class="form-control" placeholder="Nhập mật khẩu..." value="<?php echo isset($_POST['password']) ? $_POST['password'] : ''; ?>" name="password">
                    </div>
                    <div class="form-group">
                        <label for="password2">Nhập lại mật khẩu:</label>
                            <input type="text" class="form-control" placeholder="Nhập lại mật khẩu..." name="password2">
                    </div>
                    <button name="submit" class="btn btn-purple waves-effect waves-light">Đăng ký tài khoản</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
    if (isset($_POST['submit'])){
        $username = htmlspecialchars(addslashes($_POST['username']));
        $password = htmlspecialchars(addslashes($_POST['password']));
        $password2 = htmlspecialchars(addslashes($_POST['password2']));
        $email = $_POST['email'];
        $sdt = $_POST['sdt'];
        $idfb = $_POST['idfb'];
        $code = randma(20);
        $today = date('Y-m-d');
        
		$check_email = mysqli_query($conn, "SELECT COUNT(*) FROM member WHERE email='$email'");
		$getcheck_email = mysqli_fetch_assoc($check_email);
        $checkemail = $getcheck_email['COUNT(*)'];
        
		$check_sdt = mysqli_query($conn, "SELECT COUNT(*) FROM member WHERE sdt='$sdt'");
		$getcheck_sdt = mysqli_fetch_assoc($check_sdt);
        $checksdt = $getcheck_sdt['COUNT(*)'];
        
		$check_idfb = mysqli_query($conn, "SELECT COUNT(*) FROM member WHERE idfb='$idfb'");
		$getcheckidfb = mysqli_fetch_assoc($check_idfb);
        $checkidfb = $getcheckidfb['COUNT(*)'];
        
        $check = mysqli_query($conn, "SELECT COUNT(*) FROM member WHERE username='$username'");
        $getcheck = mysqli_fetch_assoc($check);
        $res = $getcheck['COUNT(*)'];
        
        if(!$username || !$password || !$password2){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Vui lòng điền tên đăng nhập.',type: 'error',});</script>";
        }else if(!$password){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Vui lòng điền mật khẩu.',type: 'error',});</script>";
        }else if(!$password2){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Vui lòng điền nhập lại mật khẩu.',type: 'error',});</script>";
        }else if($response.success == false){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Hệ thống phát hiện có hành động spam.',type: 'error',});</script>";
        }else if(strlen($username) > 20 || strlen($username) < 5){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Tên đăng nhập phải lớn hơn 5 kí tự và nhỏ hơn 20 kí tự.',type: 'error',});</script>";
        }else if($res > 0){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Tên đăng nhập đã tồn tại.',type: 'error',});</script>";
        }else if($checkemail > 0){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Email $email đã tồn tại trên hệ thống.',type: 'error',});</script>";
        }else if($checksdt > 0){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Sđt $sdt đã tồn tại trên hệ thống.',type: 'error',});</script>";
        }else if($checkidfb > 0){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'UID $idfb đã tồn tại trên hệ thống.',type: 'error',});</script>";
        }else if($password != $password2){
            echo "<script>swal({html: true,title: 'Lỗi',text: 'Nhập lại mật khẩu không chính xác.',type: 'error',});</script>";
        }else{
            $sql = "INSERT INTO member(username, password, level, bill, macode, status, email, sdt, idfb, ip, diachi) VALUES ('$username', '$password', '0', '0', '$code', '0', '$email', '$sdt', '$idfb', '$remoteip', 'VietNam')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>swal({html: true,title: 'Thành công',text: 'Đăng ký thành công.',type: 'success',});</script>";
            }
        }
    }
    function randma($length) {
        $characters = '01233849573465723';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
?>