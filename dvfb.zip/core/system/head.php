<?php
include "config.php";
include "functions.php";
if (!isset($_SESSION['id_ctv'])) {
    echo "<script>window.location='Login.php';</script>";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Nơi cài auto thả tim, bình luận, like tương tác.">
        <meta name="author" content="0858 743 369">
        <link rel="shortcut icon" href="<?=$setting['logo'];?>">
        <!-- Base Css Files -->
        <link href="<?=$domain;?>/css/bootstrap.min.css" rel="stylesheet" />
        <link href="<?=$domain;?>/assets/sweet-alert/sweet-alert.min.css" rel="stylesheet">
        <!-- Font Icons -->
        <link href="<?=$domain;?>/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
        <link href="<?=$domain;?>/assets/ionicon/css/ionicons.min.css" rel="stylesheet" />
        <link href="<?=$domain;?>/css/material-design-iconic-font.min.css" rel="stylesheet">
        <!-- animate css -->
        <link href="<?=$domain;?>/css/animate.css" rel="stylesheet" />
        <!-- Waves-effect -->
        <link href="<?=$domain;?>/css/waves-effect.css" rel="stylesheet">
        <link href="<?=$domain;?>/css/helper.css" rel="stylesheet" type="text/css" />
        <link href="<?=$domain;?>/css/style.css" rel="stylesheet" type="text/css" />
        <!-- Custom Files -->
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <script src="<?=$domain;?>/js/jquery.min.js"></script>
        <script src="<?=$domain;?>/js/modernizr.min.js"></script>
        <script src="<?=$domain;?>/js/jickme.js"></script>
        <script src="<?=$domain;?>/assets/sweet-alert/sweet-alert.min.js"></script>
        <script src="<?=$domain;?>/assets/sweet-alert/sweet-alert.init.js"></script>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({
                  google_ad_client: "ca-pub-9484633495941539",
                  enable_page_level_ads: true
             });
        </script>
    </head>
    <body class="fixed-left">
        <div id="wrapper">
            <div class="topbar">
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="/" class="logo"> KQ </a>
                    </div>
                </div>
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="fa fa-bars"></i>
                                </button>
                            </div>
                            <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown">
                                    <button class="btn btn-danger navbar-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Cài đặt <span class="caret"></span></span></button>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?=$domain;?>/index.php?action=thong-tin"><i class="fa fa-play faa-horizontal animated"></i> Cập nhật thông tin</a></li>
										<?php
										if($idctv == $idvip){?>
										<li><a href="<?=$domain;?>/index.php?action=daily"><i class="fa fa-play faa-horizontal animated"></i> Quản lý đại lý</a></li>	
										<?php }
										?>
                                        <li><a href="<?=$domain;?>/index.php?action=thoat"><i class="fa fa-play faa-horizontal animated"></i> Đăng xuất</a></li>
                                    </ul>
                                </li>
                            </ul>
							<ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown">
								<?php
								if($uname == $accoutadmin){
									$getls = mysqli_query($conn,"SELECT COUNT(*) FROM lichsuxoavip");
									$getls1 = mysqli_query($conn,"SELECT COUNT(*) FROM history");
								}else{
								$getls = mysqli_query($conn,"SELECT COUNT(*) FROM lichsuxoavip WHERE id_ctv=$idctv");
								$getls1 = mysqli_query($conn,"SELECT COUNT(*) FROM history WHERE id_ctv=$idctv");
								}
								$ls = mysqli_fetch_assoc($getls)['COUNT(*)'];
								$ls1 = mysqli_fetch_assoc($getls1)['COUNT(*)'];
								$tong = $ls + $ls1;
								?>
									<button class="btn btn-block navbar-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Lịch sử hệ thống (<?php echo $tong; ?>)<span class="caret"></span></button> 
									<ul class="dropdown-menu">
										<li><a href="<?=$domain;?>/index.php?action=xoa-vip"><i class="fa fa-play faa-horizontal animated"></i> Lịch sử đã xoá (<?php echo $ls; ?>)</a></li>
										<li><a href="<?=$domain;?>/index.php?action=lich-su"><i class="fa fa-play faa-horizontal animated"></i> Lịch sử giao dịch (<?php echo $ls1; ?>)</a></li>
                                    </ul>
                                </li>
                            </ul>
							<ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown">
								<?php
								$getma = mysqli_query($conn,"SELECT COUNT(*) FROM giftcode WHERE type=0");
								$ma = mysqli_fetch_assoc($getma)['COUNT(*)'];
								?>
									<button class="btn btn-warning navbar-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Mã nhận thưởng (<?php echo $ma; ?>)<span class="caret"></span></button>
									<ul class="dropdown-menu">
										<li><a href="<?=$domain;?>/index.php?action=gift-code"><i class="fa fa-play faa-horizontal animated"></i> Lấy mã thưởng</a></li>
                                    </ul>
                                </li>
                            </ul>
							<ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown">
								<?php
										$getthe = mysqli_query($conn,"SELECT COUNT(*) FROM card WHERE type=0");
										$the = mysqli_fetch_assoc($getthe)['COUNT(*)'];
									?>
									<button class="btn btn-info navbar-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Nạp tiền & Giá dịch vụ <?php if($uname == $accoutadmin){ echo "($the)"; } ?><span class="caret"></span></button>
									<ul class="dropdown-menu">
                                        <li><a href="<?=$domain;?>/index.php?action=nap-the"><i class="fa fa-play faa-horizontal animated"></i> Nạp tiền vào tài khoản</a></li>
										<li><a href="<?=$domain;?>/index.php?action=chuyen-tien-le"><i class="fa fa-play faa-horizontal animated"></i> Chuyển tiền cho khách</a></li>
										<li><a href="<?=$domain;?>/index.php?action=chuyen-tien-dl"><i class="fa fa-play faa-horizontal animated"></i> Chuyển tiền cho đại lý</a></li>
										<li><a href="<?=$domain;?>/index.php?action=chuyen-tien"><i class="fa fa-play faa-horizontal animated"></i> Chuyển tiền cho cộng tác viên</a></li>
										<li><a href="<?=$domain;?>/index.php?action=bang-gia"><i class="fa fa-play faa-horizontal animated"></i> Bảng giá dịch vụ</a></li>
                                    </ul>
                                </li>
                            </ul>
							<ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown">
									<button class="btn btn-success navbar-btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false">+ THÊM GÓI VIP MỚI <span class="caret"></span></button>
									<ul class="dropdown-menu">
                                        <li><a href="<?=$domain;?>/index.php?action=vip-bot"><img src="/images/LOVE.gif" height="40" width="40"/> Thêm gói Vip BOT</a></li>
										<li><a href="<?=$domain;?>/index.php?action=vip-like"><img src="/images/like.gif" height="40" width="40"/> Thêm gói Vip LIKE</a></li>
                                    </ul>
                                </li>
                            </ul>
							<br>
                      <!--      <span style="color: white;">IP của bạn: <?=$remoteip?></span>-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                    <div class="user-details">
                        <div class="pull-left">
                            <img src="https://graph.facebook.com/<?=$idfb;?>/picture?width=48&height=48" alt="" class="thumb-fa img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="text-success"><?=$uname?> <i class="fa fa-check-circle" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Tài khoản đã xác minh."></i></span></a>
                            </div>
                            <p class="text-success m-0"><i class="fa fa-money" aria-hidden="true"></i> <?php echo number_format($bill).' Đ';?></p>
							<?php
							$get = "SELECT id_ctv, level FROM member WHERE id_ctv=$idctv";
							$result = mysqli_query($conn, $get);
							$x = mysqli_fetch_assoc($result);
							$level=$x['level'];
							$numid=$x['id_ctv'];
							if($level == 2){
								echo '<a class="btn btn-warning">Cộng Tác Viên</a>';
							}elseif($level == 3){
								echo '<a class="btn btn-info">Đại Lý - ID: '.$numid.'</a>';
							}elseif($level == 4){
								echo '<a class="btn btn-success">Tổng Đại Lý - ID: '.$numid.'</a>';
							}
							else{
								echo '<a class="btn btn-danger">(Thành Viên)</a>';
							}
							?>
                        </div>
                    </div>
                    <div id="sidebar-menu">
                        <ul>
						<?php
								if($uname == $accoutadmin){
									$getbot = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction");
									$getlike = mysqli_query($conn,"SELECT COUNT(*) FROM vip");
									$getrep = mysqli_query($conn,"SELECT COUNT(*) FROM autorep");
								}else if($idctv == $idvip){
								$getbot = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction WHERE boss=$idvip");
								$getlike = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE boss=$idvip");
								}
								else{
									$getbot = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction WHERE id_ctv=$idctv");
									$getlike = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE id_ctv=$idctv");
									$getrep = mysqli_query($conn,"SELECT COUNT(*) FROM autorep WHERE id_ctv=$idctv");
								}
									$bot = mysqli_fetch_assoc($getbot)['COUNT(*)'];
									$like = mysqli_fetch_assoc($getlike)['COUNT(*)'];
									$rep = mysqli_fetch_assoc($getrep)['COUNT(*)'];
						?>
                                    <li><a href="<?=$domain;?>/index.php?action=admin-bot" class="waves-effect"><img src="/images/LOVE.gif" height="40" width="40"/><span> Quản lý VipBot (<?php echo $bot; ?>) </span></a></li>
									<li><a href="<?=$domain;?>/index.php?action=admin-like" class="waves-effect"><img src="/images/like.gif" height="40" width="40"/><span> Quản lý VipLike (<?php echo $like; ?>) </span></a></li>
									<li><a href="http://tools.trieulikes.com" target="_blank" class="waves-effect"><i class="fa fa-cogs" aria-hidden="true"></i><span> Công Cụ Hỗ Trợ </span></a></li>
                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="fa fa-cogs" aria-hidden="true"></i><span>Tools hệ thống </span><span class="pull-right">+</span></a>
                                <ul class="list-unstyled">
                                    <li><a href="http://tools.trieulikes.com/index.php?do=token&act=checktoken" target="_blank" class="waves-effect"><i class="fa fa-exchange"></i><span> Kiểm tra token </span></a></li>
									<li><a href="http://tools.trieulikes.com/index.php?do=token&act=loctrung" target="_blank" class="waves-effect"><i class="fa fa-exchange"></i><span> Lọc trùng token </span></a></li>
									<li><a href="http://tools.trieulikes.com/index.php?do=token&act=loctext" target="_blank" class="waves-effect"><i class="fa fa-exchange"></i><span> Lọc token từ text </span></a></li>
									<li><a href="<?=$domain;?>/index.php?action=loc-ban"><i class="fa fa-exchange"></i> Lọc bạn bè</a></li>
									<li><a href="<?=$domain;?>/index.php?action=khien-token"><i class="fa fa-exchange"></i> Bật khiên avatar </a></li>
									<li><a href="<?=$domain;?>/index.php?action=token-cookies" class="waves-effect"><i class="fa fa-exchange"></i><span> Token sang cooikes </span></a></li>
                                </ul>
                            </li>
                        <?php if($uname == $accoutadmin){ echo '
                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="fa fa-cogs" aria-hidden="true"></i><span> Panel Admin </span><span class="pull-right">+</span></a>
                                <ul class="list-unstyled">
									<li><a href="'.$domain.'/index.php?action=user"> Danh sách thành viên</a></li>
                                    <li><a href="'.$domain.'/index.php?action=gift-code-admin"> Thêm mã gift code</a></li>
                                    <li><a href="'.$domain.'/index.php?action=add-token"> Thêm Token </a></li>
                                    <li><a href="'.$domain.'/index.php?action=die-token"> Xoá Token </a></li>
									<li><a href="'.$domain.'/index.php?action=get-token"> Xuất Token Bot </a></li>
									<li><a href="'.$domain.'/index.php?action=get-token2"> Xuất TokenLike1 </a></li>
									<li><a href="'.$domain.'/index.php?action=get-token3"> Xuất TokenLike2 </a></li>
									<li><a href="'.$domain.'/index.php?action=get-token4"> Xuất TokenLike3 </a></li>
									<li><a href="'.$domain.'/index.php?action=list-reaction"> Thêm Gói VIPBOT </a></li>
									<li><a href="'.$domain.'/index.php?action=list-like"> Thêm Gói VIPLIKE </a></li>
									<li><a href="'.$domain.'/index.php?action=list-cmt"> Thêm Gói VIPREP </a></li>
									<li><a href="'.$domain.'/index.php?action=buzzlike"> Buzz like</a></li>
									<li><a href="'.$domain.'/index.php?action=buzzsub"> Buzz sub</a></li>
									<li><a href="'.$domain.'/index.php?action=choc"> Chọc bạn bè </a></li>
									<li><a href="'.$domain.'/index.php?action=setting"> Cấu hình hệ thống </a></li>
                                    
                                </ul>
                            </li>'; } ?>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="content-page">
                <div class="content">
                    <div class="container">
