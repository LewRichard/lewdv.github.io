<?php
// Cấu hình Database 
    $conn = mysqli_connect('localhost','tenmysqlhosting','matkhaudatabase','matkhaumysqlhosting') or die('<center><h1>Đang nâng cấp server, quay lại sau...</h1></center>');
    mysqli_set_charset($conn, "utf8");//tên da
// Phần này không cần sửa gì hết tự kích hoạt domain cho bạn.
    $domain = $_SERVER['HTTP_HOST'];
    if (!empty($_SERVER['HTTPS'])) {
        $domain = 'https://' . $domain;
    } else {
        $domain = 'http://' . $domain;
    }
// Từ đây trở xuống edit hết
// Tên tài khoản admin
    $accoutadmin="admin";
// Name url fb của admin
    $nameurlfb="4";
// ID fb admin
    $uidadmin="4";
// Tên của admin
    $nameadmin="0858 743 369";
// Cấu hình captcha google, lên google search recaptcha google, xong thay 2 mã bên dưới là okay
 //   $secret="6Leeaw0aAAAAAC89Pl9qp5Iue8rYoXmYaZoNv5Bh";
 //   $sitekey="6Leeaw0aAAAAAF6drpGRG8tdLSvAFM4HLjUM0hPh";

?>
