<?php $titles='BUZZ COMMENT';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
                <strong>HỆ THỐNG CHỈ ĐỊNH 1 COMMENT = <?=$setting['ratecmt'];?>Đ</strong>
<?php
if (isset($_POST['submit'])) {
    $id_post = intval($_POST['id_post']);
    $max_cmt = intval($_POST['max_cmt']);
    $noi_dung = $_POST['noi_dung'];
    $price = $setting['ratecmt'] * $max_cmt;
    $checkid = mysqli_query($conn, "SELECT COUNT(id_post) FROM buzz_cmt WHERE id_post='$id_post'");
    $check = mysqli_fetch_assoc($checkid);
    $loi = array();
    if ($n['status'] < 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Tài khoản của bạn chưa kích hoạt.',type: 'error',});</script>";
    }else if (!$id_post) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'UID không đúng định dạng.',type: 'error',});</script>";
    }else if (!$max_cmt) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng nhập giới hạn cmt cần mua.',type: 'error',});</script>";
    }else if (!$noi_dung) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng điền nội dung.',type: 'error',});</script>";
    }else if ($check['COUNT(id_post)'] == 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: '<strong>$id_post</strong> đã tồn tại trên hệ thống.',type: 'error',});</script>";
    }else if ($max_cmt < 50) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mua tối thiểu <strong>50 cmt</strong>.',type: 'error',});</script>";
    }else if ($bill - $price < 0) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'error',});</script>";
    }else{
        mysqli_query($conn, "INSERT INTO buzz_cmt(id_post, max_cmt, cmtd, noi_dung,id_ctv) VALUES('$id_post', '$max_cmt', '0', '$noi_dung', '$idctv')");
        mysqli_query($conn, "UPDATE member SET bill = bill - $price WHERE id_ctv=$idctv");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thành công.',type: 'success',});</script>";
    }
}
?>
                <div class="form-group">
                    <label for="id_post">Post ID:</label>
                        <input type="text" class="form-control" value="<?php echo isset($_POST['id_post']) ? $_POST['id_post'] : ''; ?>" id="id_post" name="id_post" placeholder="Id bài viết cần tăng comment." required>
                </div>
                <div class="form-group">
                    <label for="max_cmt">Số cmt cần mua:</label>
                    <input name="max_cmt" class="form-control" placeholder="Nhập số cmt cần mua" type="number" value="<?php echo isset($_POST['max_cmt']) ? $_POST['max_cmt'] : ''; ?>" max="10000"/>
                </div>
                <div class="form-group">
                    <label for="noi_dung">Nội Dung</label>
                    <textarea class="form-control" rows="5" name="noi_dung" id="noi_dung" placeholder="Có thể thêm nhiều nội dung comment khác nhau, mỗi comment trên một dòng. Hệ thống sẽ lấy ngẫu nhiên các nội dung comment" onchange="update()" required><?php echo isset($_POST['noi_dung']) ? $_POST['noi_dung'] : ''; ?></textarea>
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success waves-effect waves-light">XÁC NHẬN</button>
        </div>
            </form>
    </div>
</div>

<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-body">
            <div class="table-responsive">
                <table id="example1" class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>UID</th>
                            <th>Comment cần tăng</th>
                            <th>Comment đã hoàn thành</th>
                            <th>Trạng thái</th>
                            <th>Công cụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        if($uname != $accoutadmin){
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_cmt WHERE id_ctv = $idctv");
                        }else{
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_cmt");
                        }
                        while ($x = mysqli_fetch_assoc($get_buzz)) {
                            // cột trạng thái
                            $tt = "<font color=green>Đang chạy</font>";
                            if($x['cmtd'] >= $x['max_cmt']){
                                $tt = "<font color=red>Đã hoàn thành</font>";
                            }
                            
                            // cột công cụ
                            $ii = $i + 1;
                            ?>
                            <tr>
                                <td><?=$ii;?></td>
                                <td><a href="//fb.com/<?=$x['id_post'];?>" target="_blank"><?=$x['id_post'];?></a></td>
                                <td><?= $x['max_cmt'];?> cmt</td>
                                <td><?=$x['cmtd'];?> cmt</td>
                                <td><?= $tt;?></td>
                                <td style="text-align:center"><a onclick="xoa(<?= $x['id'];?>)" class="btn btn-danger" href="javascript:void(0)">Xóa</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    function xoa(id) {
        if (confirm('Bạn có chắc xóa id này?') == true) {
            window.location = '<?=$domain;?>/index.php?action=buzz-cmt&id=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $get = "SELECT * FROM buzz_cmt WHERE id = $id";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $id_post = $check['id_post'];
    $end = $check['end'];
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>window.location='/index.php?action=trang-loi';</script>";
        }else{
            $sql = "DELETE FROM buzz_cmt WHERE id = $id";
            if (mysqli_query($conn, $sql)) {
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";      
                if(mysqli_query($conn, $up)){
                    echo "<script>window.location='/index.php?action=buzz-cmt';</script>";
                }
            }
        }
    }else if($uname != $accoutadmin){
        $sql = "DELETE FROM buzz_cmt WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
            if(mysqli_query($conn, $up)){
                echo "<script>window.location='/index.php?action=buzz-cmt';</script>";
            }
        }
    }else{
        $del = mysqli_query($conn, "DELETE FROM buzz_cmt WHERE id = $id");
        if($del){
            echo "<script>window.location='/index.php?action=buzz-cmt';</script>";
        }
    }
}
?>