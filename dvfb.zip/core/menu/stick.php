<div class="panel-group">
  <div class="panel panel-info">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse1"><font color="green"><img src="/assets/images/hot.gif"/> NHẤN VÀO ĐÂY ĐỂ XEM ID NHÃN DÁN</font></a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse">
        <img src="https://www.facebook.com/stickers/asset/?sticker_id=344394649290083" width="50" height="50">
		<b id="copy">344394649290083|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=344394765956738" width="70" height="70">
		<b id="copy1">344394765956738|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy1')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=344395512623330" width="70" height="70">
		<b id="copy2">344395512623330|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy2')">Copy</span><br>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=344396095956605" width="50" height="50">
		<b id="copy3">44396095956605|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy3')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=345440432518838" width="70" height="70">
		<b id="copy4">345440432518838|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy4')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=344394505956764" width="70" height="70">
		<b id="copy5">344394505956764|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy5')">Copy</span><br>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1598323170480504" width="50" height="50">
		<b id="copy6">1598323170480504|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy6')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1598323397147148" width="70" height="70">
		<b id="copy7">1598323397147148|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy7')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1598323843813770" width="70" height="70">
		<b id="copy8">1598323843813770|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy8')">Copy</span><br>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=488524224594356" width="50" height="50">
		<b id="copy9">488524224594356|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy9')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=488524341261011" width="70" height="70">
		<b id="copy10">488524341261011|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy10')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=488524014594377" width="70" height="70">
		<b id="copy11">488524014594377|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy11')">Copy</span><br>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1211883345577222" width="50" height="50">
		<b id="copy12">1211883345577222|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy12')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1193280720770818" width="70" height="70">
		<b id="copy13">1193280720770818|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy13')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1193279524104271" width="70" height="70">
		<b id="copy14">1193279524104271|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy14')">Copy</span><br>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=499671060115397" width="50" height="50">
		<b id="copy15">499671060115397|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy15')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=499671100115393" width="70" height="70">
		<b id="copy16">499671100115393|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy16')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=499671016782068" width="70" height="70">
		<b id="copy17">499671016782068|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy17')">Copy</span><br>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1151376801549337" width="50" height="50">
		<b id="copy18">1151376801549337|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy18')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1151368254883525" width="70" height="70">
		<b id="copy19">1151368254883525|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy19')">Copy</span>
		<img src="https://www.facebook.com/stickers/asset/?sticker_id=1181334531886897" width="70" height="70">
		<b id="copy20">1181334531886897|</b> <span style="color: black; background-color: Silver" onclick="copyToClipboard('#copy20')">Copy</span>
    </div>
  </div>
</div>
<script type="text/javascript">
function copyToClipboard(element) {
var $temp = $("<input>");
$("body").append($temp);
$temp.val($(element).html()).select();
document.execCommand("copy");
document.execCommand("copy1");
document.execCommand("copy2");
document.execCommand("copy3");
document.execCommand("copy4");
document.execCommand("copy5");
document.execCommand("copy6");
document.execCommand("copy7");
document.execCommand("copy8");
document.execCommand("copy9");
document.execCommand("copy10");
document.execCommand("copy11");
document.execCommand("copy12");
document.execCommand("copy13");
document.execCommand("copy14");
document.execCommand("copy15");
document.execCommand("copy16");
document.execCommand("copy17");
document.execCommand("copy18");
document.execCommand("copy19");
document.execCommand("copy20");
document.execCommand("copy21");
$temp.remove();
}
</script>