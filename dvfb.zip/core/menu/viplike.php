<?php 
if ($uname != $accoutadmin) {
	echo "<script>alert('Chức năng đang cập nhật... Vui lòng quay lại sau!'); window.location='/';</script>";
        }
if(isset($_GET['update'])) {
    $id = $_GET['update'];
    $get = "SELECT * FROM vip WHERE user_id=$id";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    $uid = $x['user_id'];
	$name = $x['name'];
	$max = $x['max_like'];
	$likes =$x['likes'];
	$start = date('d/m/Y', $x['start']);
	$ghi_chu = $x['ghi_chu'];
    $type = explode("\n", $x['type']);
	$sv = $x['server'];
    if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: /index.php?action=trang-loi');
        }
    }
?>
<?php $titles='CHỈNH SỬA - '.$id.'';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
    <?php
    if (isset($_POST['submit'])) {
        $list_type = $_POST['type'];
        $type = implode("\n", $list_type);
        $hoten = $_POST['hoten'];
        $likes = $_POST['likes'];
        $max_like = $_POST['max_like'];
        $user_id = $_POST['user_id'];
		$server = $_POST['server'];
        if($uname != $accoutadmin){
            $sql = "UPDATE vip SET likes='$likes' type='$type' WHERE user_id='$user_id'";
        }else{
            $sql = "UPDATE vip SET user_id = '$user_id', name='$hoten', likes='$likes', max_like='$max_like', type='$type', server='$server' WHERE user_id='$user_id'";
        }
        if($likes > $max_like){
		        		echo "<div class=panel-footer><h4><font color=red>* Thông báo:<br>- Vui lòng chọn tốc độ nhỏ hơn $max .</font></h4></div>";
		}
		else if(empty($hoten)){
		        		echo "<div class=panel-footer><h4><font color=red>* Thông báo:<br>- Vui lòng nhập họ tên.</font></h4></div>";
		}
		else if(empty($type)){
		        		echo "<div class=panel-footer><h4><font color=red>* Thông báo:<br>- Vui lòng chọn ít nhất 1 cảm xúc.</font></h4></div>";
		}
		else if(empty($server)){
		        		echo "<div class=panel-footer><h4><font color=red>* Thông báo:<br>- Vui lòng chọn SERVER.</font></h4></div>";
		}
		else if($likes < 17){
		        		echo "<div class=panel-footer><h4><font color=red>* Thông báo:<br>- Tốc độ like không hợp lệ.</font></h4></div>";
		}
		else if (mysqli_query($conn, $sql)) {
		        echo "<script>swal({html: true,title: 'Thành công',text: 'Cập nhật Viplike thành công.',type: 'success',});</script>";
    }
    }
    ?>
	<div class="panel-footer">
	Thông tin hiện tại:<br>
	<?php
	echo "<h4>- Khách hàng: <font color=green>$name</font><br>- Gói like: $max<br>- Tốc độ: $likes<br>- Server: $sv</h4>";
	?>
	</div>
	            <?php if($uname == $accoutadmin){ ?>
				<div class="form-group">
                        <label>* CHỌN SERVER</label><br>
                        <input type="radio" value="1" name="server" /> <a class="btn btn-success"> 1</a>
						<input type="radio" value="2" name="server" /> <a class="btn btn-info"> 2</a>
						<input type="radio" value="3" name="server" /> <a class="btn btn-warning"> 3</a>
						<input type="radio" value="4" name="server" /> <a class="btn btn-danger"> 4</a>
						<input type="radio" value="5" name="server" /> <a class="btn btn-success"> 5</a>
						<input type="radio" value="6" name="server" /> <a class="btn btn-info"> 6</a>
						<input type="radio" value="7" name="server" /> <a class="btn btn-warning"> 7</a>
						<input type="radio" value="8" name="server" /> <a class="btn btn-danger"> 8</a>
						<input type="radio" value="9" name="server" /> <a class="btn btn-success"> 9</a>
                    </div>
                <div class="form-group">
                    <label for="user_id">Mã id</label>
                    <input type="number" class="form-control" name="user_id" id="user_id" value="<?=$x['user_id'];?>" onchange="send()" onkeyup="send()">
                    <input type="number" class="form-control" value="<?=$x['user_id'];?>" disabled>
                </div>
                <div class="form-group">
                    <label for="hoten">Họ tên</label>
                    <input type="text" class="form-control" maxlength="50" value="<?=$x['name'];?>" id="hoten" name="hoten" placeholder="Họ và tên">
                </div>
                <div class="form-group">
                    <label for="goi">Gói like</label>
                    <select id="goi" name="max_like" class="form-control">
                    <?php
                    $ds = "SELECT name_likes, max, price FROM package WHERE type='LIKE' ORDER BY price ASC";
                    $ds_x = mysqli_query($conn, $ds);
                    while ($ok = mysqli_fetch_assoc($ds_x)) {
                        $check = '';
                        if($x['max_like'] == $ok['name_likes']) $check = 'selected';
                            echo "<option value='" . $ok['max'] . "' $check>{$ok['name_likes']}</option>";
                        }
                    ?>
                    </select>
                </div>
            <?php } ?>
				<div class="form-group">
                    <label for="likes">Tốc độ</label>
					<select id="likes" name="likes" class="form-control">
                <!--    <input type="text" class="form-control" maxlength="50" id="likes" name="likes" value="<?=$_POST['likes'];?>" placeholder="25" required onchange="update()">-->
						<option value="25">25 like/lần</option>
						<option value="35">35 like/lần</option>
						<option value="52">50 like/lần</option>
						<option value="78">75 like/lần</option>
					</select>
                </div>
                <div class="form-group">
                    <label for="type">Cảm xúc</label>
                    <div class="container">
                        <div class="row">
                            <input type="checkbox" name="type[]" value="LIKE" id="LIKE" class="flat-red" <?= in_array('LIKE',$type) ? 'checked' : ''; ?>>
                            <label style="padding-right: 10px" for="LIKE">
                                <img src="<?$domain;?>/core/menu/icon/like.png" style="width:24px" data-toggle="tooltip" title="Thích"/>
                            </label>
                            <input type="checkbox" name="type[]" value="LOVE" id="LOVE" class="flat-red" <?= in_array('LOVE',$type) ? 'checked' : ''; ?>>
                            <label style="padding-right: 10px" for="LOVE">
                                <img src="<?$domain;?>/core/menu/icon/love.png" style="width:24px" data-toggle="tooltip" title="Yêu Thích" />
                            </label>
                        </div>
                    </div>
                </div>
				<div class="form-group">
                        <label>Ghi chú</label>
                        <textarea class="form-control" rows="1" name="ghi_chu" id="ghi_chu" placeholder="Ghi chú gì đó..." disabled><?php echo "$ghi_chu - Đăng ký ngày: $start"; ?></textarea>
                    </div>
					
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success">Cập nhật</button>
            <a class="btn btn-primary waves-effect waves-light" href="<?=$domain;?>/index.php?action=vip-like">Quay lại</a>
        </div>
            </form>
        </div>
    </div>
</div>
<?php }// gia hạn thời gian
else if(isset($_GET['giahan'])) {
	$id = $_GET['giahan'];
    $get = "SELECT * FROM vip WHERE user_id=$id";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
	$name = $x['name'];
	$end = $x['end'];
	$han = $x['han'];
	$goi = $x['max_like'];
	if ($goi == '50'){
		$g = '50000';
	}else if($goi == '75'){
		$g = '75000';
	}else if($goi == '100'){
		$g = '100000';
	}else{
		$g = '150000';
	}
	if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: index.php');
        }
    }
	// xử lý gia hạn
	$getmem = "SELECT level FROM member WHERE id_ctv = $idctv";
    $res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
	if (isset($_POST['submit'])) {
		$themhan = $_POST['han'];
		$ketqua = $han + $themhan;
		$themend = $end + $themhan * 30 * 86400 - 28800;
		if($level == 2){
			$price = $themhan * $g * 0.4;// chiết khấu 60% cho cộng tác viên
		}else if($level == 3){
			$price = $themhan * $g * 0.35;// chiết khấu 65% cho đại lý
		}else if($level == 4){
			$price = $themhan * $g * 0.3;// chiết khấu 70% cho tổng đại lý
		}else{
			$price = $themhan * $g;// không chiết khấu cho thành viên
		}
		$sql = "UPDATE vip SET han='$ketqua',end='$themend' WHERE user_id='$id'";
		if($themhan <= 0 || $themhan > 12){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- Số tháng không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h3></div>";
		}
		else if(mysqli_query($conn, $sql)){
                $minus = "UPDATE member SET bill = bill - $price WHERE id_ctv = $idctv";
                if (mysqli_query($conn, $minus)) {
                    $content = "Gia Hạn Vip Like";
                    $tien_sau = $bill - $price;
                    $time = time();
					if ($bill < $price) {
						echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
					}else{
							if($uname != $accoutadmin){
								$his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', 9)";
							}
					}
					if (mysqli_query($conn, $his)) {
                        echo "<div class=panel-footer><h3>* Thông báo: <br>- Gia hạn <font color=green>$themhan tháng</font> thành công cho<font color=green> $name</font>.<br>- Bạn bị trừ <font color=green>".number_format($price)." đồng.</font></h3></div>";
                    }
                }
        }
	}
?>
<?php $titles='GIA HẠN - '.$id.'';?>
	<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
        <form method="post">
		<div class="form-group">
                            <label>Thời hạn</label>
                                <select id="han" name="han" class="form-control">
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) {
                                        echo "<option value='$i'>$i Tháng</option>";
                                    }
                                    ?>
                                </select>
        </div>
		<div class="panel-footer">
			<button name="submit" class="btn btn-success">Gia hạn</button>
            <a class="btn btn-primary waves-effect waves-light" href="<?=$domain;?>/index.php?action=admin-bot">Quay lại</a>
		</div>
		
</form>
</div>
</div>
</div>
<?php }else{ ?>
<?php $titles='THÊM KHÁCH HÀNG';?>
    <div class="col-md-8">
        <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
            <div class="panel-heading">
                <h3 class="panel-title"><?=$titles;?></h3>
            </div>
            <div class="panel-body">
			<form method="post">
<?php
	$vi = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=1");
	$vip = mysqli_fetch_assoc($vi)['COUNT(*)'];
	
	$vi2 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=2");
	$vip2 = mysqli_fetch_assoc($vi2)['COUNT(*)'];
	
	$vi3 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=3");
	$vip3 = mysqli_fetch_assoc($vi3)['COUNT(*)'];
	
	$vi4 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=4");
	$vip4 = mysqli_fetch_assoc($vi4)['COUNT(*)'];
	
	$vi5 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=5");
	$vip5 = mysqli_fetch_assoc($vi5)['COUNT(*)'];
	
	$vi6 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=6");
	$vip6 = mysqli_fetch_assoc($vi6)['COUNT(*)'];
	
	$vi7 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=7");
	$vip7 = mysqli_fetch_assoc($vi7)['COUNT(*)'];
	
	$vi8 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=8");
	$vip8 = mysqli_fetch_assoc($vi8)['COUNT(*)'];
	
	$vi9 = mysqli_query($conn,"SELECT COUNT(*) FROM vip WHERE server=9");
	$vip9 = mysqli_fetch_assoc($vi9)['COUNT(*)'];
	
	$getmem = "SELECT level FROM member WHERE id_ctv = $idctv";
    $res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
	$get_pack = mysqli_query($conn, "SELECT COUNT(*), MIN(price) FROM package WHERE type='LIKE'");
    $package = mysqli_fetch_assoc($get_pack);
	if(isset($_POST['submit'])){
    $uid = $_POST['user_id'];
	$hoten = $_POST['hoten'];
    $get = "SELECT COUNT(user_id) FROM vip WHERE user_id = $uid";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    $type = 'LIKE';
    $han = $_POST['han'];
    $likes = $_POST['likes'];
    $goi = $_POST['goi'];
	$ghi_chu = $_POST['ghi_chu'];
    $start = time();
	$server = $_POST['server'];
    $end = $start + $han * 30 * 86400 - 28800;
	if($level == 2){
			$price = $han * $goi * 0.4;// chiết khấu 60% cho cộng tác viên
		}else if($level == 3){
			$price = $han * $goi * 0.35;// chiết khấu 65% cho đại lý
		}
		else if($level == 4){
			$price = $han * $goi * 0.3;// chiết khấu 70% cho đại lý
		}else{
			$price = $han * $goi;// không chiết khấu cho thành viên
		}
    $get_max = "SELECT name_likes, max FROM package WHERE type='LIKE' AND price='$goi'";
    $r_max = mysqli_query($conn, $get_max);
    $max_like = mysqli_fetch_assoc($r_max)['max'];
    if ($n['status'] < 1) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Tài khoản của bạn chưa kích hoạt.<br>- Vui lòng liên hệ Admin.</font></h4></div>';
    }else if($han <= 0 || $han > 12){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- Số tháng không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h3></div>";
	}else if(empty($uid) || empty($likes) || empty($hoten)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng điền đầy đủ thông tin.</font></h4></div>';
    }else if ($bill < $price) {
				echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'success',});</script>";
				echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
    }else if ($server < 0){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Server không tồn tại.</font></h4></div>';
    }
	else if (empty($server)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa chọn server.</font></h4></div>';
    }else if ($uname != $accoutadmin){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Chức năng đang cập nhật, vui lòng thử lại sau.</font></h4></div>';
    }
	else if(($vip >= 10) && ($server == 1)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 1 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}
	else if(($vip2 >= 10) && ($server == 2)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 2 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}else if(($vip3 >= 10) && ($server == 3)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 3 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}else if (($vip4 >= 10) && ($server ==4)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 4 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}else if (($vip5 >= 10) && ($server ==5)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 5 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}else if ($x['COUNT(user_id)'] > 0) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- UID đã tồn tại trong hệ thống.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if ($likes < 17) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Tốc độ like không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if ($likes > $max_like) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Tốc độ like không được lớn hơn gói like.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if ($_POST['goi'] < $package['MIN(price)']) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Gói like không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else{
        $content = "Mua Vip Like";
        $tien_sau = $bill - $price;
        $time = time();
        mysqli_query($conn, "INSERT INTO vip(user_id, name, start, end, han, ghi_chu, likes, max_like, id_ctv, type, server) VALUES ('$uid','$hoten','$start','$end','$han','$ghi_chu','$likes','$max_like','$idctv','$type','$server')");
        mysqli_query($conn, "UPDATE member SET num_id = num_id + 1 WHERE id_ctv=$idctv");
        mysqli_query($conn, "UPDATE member SET bill = bill - $price WHERE id_ctv = $idctv");
		if($uname != $accoutadmin){
        mysqli_query($conn, "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', '2')");
		}
		echo "<div class=panel-footer><h3>* Thông báo: <br>- Bạn vừa mua<font color=green> $han tháng</font> Viplike thành công cho <font color=green> $hoten</font>.<br>- Bạn bị trừ <font color=green>".number_format($price)." đồng.</font></h3></div>";
    }
}?>
<?php
	if($vip < 10){
		$tt = '<font color=green><b>ON</b></font>';
	}else{
		$tt = '<font color=red><b>FULL</b></font>';
	}
	if($vip2 < 10){
		$tt2 = '<font color=green><b>ON</b></font>';
	}else{
		$tt2 = '<font color=red><b>FULL</b></font>';
	}
	if($vip3 < 10){
		$tt3 = '<font color=green><b>ON</b></font>';
	}else{
		$tt3 = '<font color=red><b>FULL</b></font>';
	}
	if($vip4 < 10){
		$tt4 = '<font color=green><b>ON</b></font>';
	}else{
		$tt4 = '<font color=red><b>FULL</b></font>';
	}
	if($vip5 < 10){
		$tt5 = '<font color=green><b>ON</b></font>';
	}else{
		$tt5 = '<font color=red><b>FULL</b></font>';
	}
	if($vip6 < 10){
		$tt6 = '<font color=green><b>ON</b></font>';
	}else{
		$tt6 = '<font color=red><b>FULL</b></font>';
	}
	if($vip7 < 10){
		$tt7 = '<font color=green><b>ON</b></font>';
	}else{
		$tt7 = '<font color=red><b>FULL</b></font>';
	}
	if($vip8 < 10){
		$tt8 = '<font color=green><b>ON</b></font>';
	}else{
		$tt8 = '<font color=red><b>FULL</b></font>';
	}
	if($vip9 < 10){
		$tt9 = '<font color=green><b>ON</b></font>';
	}else{
		$tt9 = '<font color=red><b>FULL</b></font>';
	}
?>
				<div class="form-group">
                        <label>* CHỌN SERVER</label><br>
                        <input type="radio" value="1" name="server" /> <a class="btn btn-success"> 1<?php if($uname == $accoutadmin){ echo "<sup>$vip</sup>"; }?></a><font color="green"> (<?php echo $tt; ?>)</font>
						<input type="radio" value="2" name="server" /> <a class="btn btn-info"> 2<?php if($uname == $accoutadmin){ echo "<sup>$vip2</sup>"; }?></a><font color="green"> (<?php echo $tt2; ?>)</font>
						<input type="radio" value="3" name="server" /> <a class="btn btn-warning"> 3<?php if($uname == $accoutadmin){ echo "<sup>$vip3</sup>"; }?></a><font color="green"> (<?php echo $tt3; ?>)</font>
						<input type="radio" value="4" name="server" /> <a class="btn btn-danger"> 4<?php if($uname == $accoutadmin){ echo "<sup>$vip4</sup>"; }?></a><font color="green"> (<?php echo $tt4; ?>)</font>
						<input type="radio" value="5" name="server" /> <a class="btn btn-warning"> 5<?php if($uname == $accoutadmin){ echo "<sup>$vip5</sup>"; }?></a><font color="green"> (<?php echo $tt5; ?>)</font>
						</div>
                <div class="form-group">
                    <label>Mã UID*(Không được nhập sai)</label>
                    <input type="number" class="form-control" name="user_id" value="<?=$_POST['user_id'];?>" id="user_id" placeholder="Ví dụ: 100004165959685" required onchange="update()">
                </div>
				<div class="form-group">
                    <label for="hoten">Họ tên*</label>
                    <input type="text" class="form-control" maxlength="50" value="<?=$_POST['hoten'];?>" id="hoten" name="hoten" placeholder="Họ và tên" required onchange="update()">
                </div>
                <div class="form-group">
                    <label for="likes">Tốc độ</label>
					<select id="likes" name="likes" class="form-control" required onchange="update()">
						<option value="25">25 like/lần</option>
						<option value="35">35 like/lần</option>
						<option value="52">50 like/lần</option>
						<option value="78">75 like/lần</option>
					</select>
                </div>
                <div class="form-group">
                    <label for="goi">Gói like</label>
                    <select id="goi" name="goi" class="form-control" required onchange="update()">
                    <?php
                    $ds = "SELECT * FROM package WHERE type='LIKE' ORDER BY price ASC";
                    $ds_x = mysqli_query($conn, $ds);
                    while ($ok = mysqli_fetch_assoc($ds_x)) {
                        echo "<option value='".$ok['price']."'>{$ok['name_likes']}</option>";
                    }
                    ?>
                    </select>
                </div>
				<div class="form-group">
                            <label>Thời hạn</label>
                                <select id="han" name="han" class="form-control" required onchange="update()">
									<?php
                                    for ($i = 1; $i <= 12; $i++) {
                                        echo "<option value='$i'>$i Tháng</option>";
                                    }
                                    ?>
                                </select>
                        </div>
						<div class="form-group">
                        <label>Ghi chú</label>
                        <textarea class="form-control" rows="1" name="ghi_chu" id="ghi_chu" placeholder="Ghi chú gì đó..."></textarea>
                    </div>
				<div class="panel-footer">
				<button type="submit" name="submit" class="btn btn-success"> Xác nhận </button>
				<button type="reset" class="btn btn-danger"> Xoá làm lại </button>
            </div>
            </div>
        </div>
    </div></form>
	<script type="text/javascript">
function update(){
        var id = $("#user_id").val();
		var hotens = $("#hoten").val();
        var tocdo = $("#likes").val();
		var packages = $("#goi").val();
		var thoigian = $("#han").val();
		var tinhtien = packages * thoigian;
        $("#id-user").text(id);
		$("#ten").text(hotens);
        $("#tocdo").text(tocdo+' likes/lần');
		$("#solike").text(packages+' đồng');
		$("#sothang").text(thoigian+' tháng');
		$("#tien").text(tinhtien+' đồng');
		
    }
	</script>
    <div class="col-md-4">
        <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
            <div class="panel-heading">
                <h3 class="panel-title">KIỂM TRA THÔNG TIN</h3>
            </div>
            <div class="panel-body">
                <div class="panel panel-default">
                    <li class="list-group-item">Mã id <span class="badge pull-right bg-red" id="id-user">Chưa xác định</span></li>
                    <li class="list-group-item">Họ tên <span class="badge pull-right bg-red" id="ten">Chưa xác định</span></li>
                    <li class="list-group-item">Tốc độ <span class="badge pull-right bg-red" id="tocdo">Chưa xác định</span></li>
					<li class="list-group-item">Gói like<span class="badge pull-right bg-red" id="solike">Chưa xác định</span></li>
					<li class="list-group-item">Thời hạn <span class="badge pull-right bg-red" id="sothang">Chưa xác định</span></li>
					<li class="list-group-item">Tiền thanh toán <span class="badge pull-right bg-red" id="tien">Chưa xác định</span></li>
                </div>
            </div>
        </div>
    </div>
<?php
} ?>
<!-- hết form -->
