<?php
if (isset($_GET['update'])) {
    $id_react = $_GET['update'];
    $get = "SELECT * FROM vipreaction WHERE user_id=$id_react";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
	$cmt1 = $x['cmmment'];
	$cmt2 = $x['cmmments'];
	$cmt3 = $x['cmmmentc'];
	$cmt4 = $x['cmmmentt'];
	$start = date('d/m/Y', $x['start']);
	$ghi_chu = $x['ghi_chu'];
    $type = explode("\n", $x['type']);
    $laydl = "SELECT * FROM package WHERE max = ".$x['limit_react']." AND type='REACTION'";
    $resultt = mysqli_query($conn, $laydl);
    $xx = mysqli_fetch_assoc($resultt);
    if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: index.php');
        }
    }
?>
<?php $titles='CHỈNH SỬA - '.$id_react.'';?>
<?php if($accoutadmin == $uname) { ?>
<script>
    function send(){
        $(function () {
            $('#user_id').val('Đang kiểm tra....');
            $.post('<?=$domain;?>/core/menu/check-id.php', {token: $('#token').val()}, function (r) {
                $('#user_id').val(r);
            });
        });
        $(function () {
            $('#name').val('Đang kiểm tra....');
            $.post('<?=$domain;?>/core/menu/check-name.php', {token: $('#token').val()}, function (r) {
                $('#name').val(r);
            });
        });
    }
</script>
<?php } ?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
        <form method="post">
<?php
if (isset($_POST['submit'])) {
    $access_token = $_POST['token'];
    $name = $_POST['name'];
	$user_id = $_POST['user_id'];
	$batcx = $_POST['batcx'];
	$list_type = $_POST['type'];
    $type = implode("\n", $list_type);
	$giochay = $_POST['giochay'];
	$giodung = $_POST['giodung'];
    $limit = $_POST['limit_react'];
    $cmt = $_POST['cmt'];
	$cmtngay = $_POST['cmtngay'];
	$comment = $_POST['comment'];
	$comments = $_POST['comments'];
	$commentc = $_POST['commentc'];
	$commentt = $_POST['commentt'];
	$stick = $_POST['stick'];
	$nhandan = $_POST['nhandan'];
	$batcx = $_POST['batcx'];
	$idchan = $_POST['idchan'];
	$status = $_POST['status'];
	if($uname != $accoutadmin){
        $sql = "UPDATE vipreaction SET access_token='$access_token', idchan='$idchan', type='$type', batcx='$batcx', limit_react = '$limit', giochay='$giochay', giodung='$giodung', comment='$comment', cmtngay='$cmtngay', comments='$comments', commentc='$commentc', commentt='$commentt', nhandan='$nhandan', stick='$stick', cmt='$cmt', status='0' WHERE user_id='$id_react'";
    }else{
        $sql = "UPDATE vipreaction SET access_token='$access_token', user_id='$user_id', name='$name', idchan='$idchan', type='$type', batcx='$batcx', limit_react = '$limit', giochay='$giochay', giodung='$giodung', access_token='$access_token', comment='$comment', cmtngay='$cmtngay', comments='$comments', commentc='$commentc', commentt='$commentt', nhandan='$nhandan', stick='$stick', cmt='$cmt', status='$status' WHERE user_id='$id_react'";
    }
	if (empty($access_token)){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chưa nhập mã token.',type: 'error',});</script>";
    }
    else if(($batcx == 1) && !isset($_POST['type'])){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng chọn ít nhất 1 loại cảm xúc.',type: 'error',});</script>";
    }
	else if (($_POST['cmt'] == '1') && empty($comment)){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chưa nhập nội dung mặc định.',type: 'error',});</script>";
    }
	else if (($_POST['cmtngay'] == '1') && empty($comments)){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chưa nhập nội dung buổi sáng.',type: 'error',});</script>";
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentc)){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chưa nhập nội dung buổi chiều.',type: 'error',});</script>";
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentt)){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chưa nhập nội dung buổi tối.',type: 'error',});</script>";
    }
	else if (($_POST['stick'] == '1') && empty($nhandan)){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Bạn chưa nhập id nhãn dán.',type: 'error',});</script>";
    }
	else if (mysqli_query($conn, $sql)) {
		        echo "<script>swal({html: true,title: 'Thành công',text: 'Cập nhật thành công.',type: 'success',});</script>";
				echo '<meta http-equiv=refresh content="1; URL=/index.php?action=admin-bot">';
    }
}
?>
            <div class="form-group">
                <label for="access_token">Mã token</label>
                <input type="text" class="form-control" name="token" id="token" value="<?=$x['access_token'];?>" placeholder="Nhập mã token..." onchange="send()" onkeyup="send()" required>
            </div>
			<div class="form-group">
			<label>Nhập uid không muốn tương tác(1 uid được tách bởi dấu: | ) tối đa 3 người.</label>
				<input class="form-control" id="idchan" name="idchan" value="<?=$x['idchan'];?>" placeholder="Nhập uid của người muốn chặn tương tác. Ví dụ: 100003345550654|100003438883978|10000394649290083|">
            </div>
			<?php if($accoutadmin == $uname) { ?>
            <div class="form-group">
                <label for="user_id">Mã id</label>
                <input type="text" class="form-control" value="<?=$x['user_id'];?>" placeholder="eg. <?=$x['user_id'];?>" id="user_id" name="user_id" required>
            </div>
            <div class="form-group">
                <label for="name">Họ tên</label>
                <input type="text" class="form-control" value="<?=$x['name'];?>" placeholder="eg. <?=$x['name'];?>" id="name" name="name">
            </div>
            <?php } ?>
            <div class="form-group">
                <label for="limit_react">Gói (Số bài 1 lần chạy)</label>
                <select id="limit_react" name="limit_react" class="form-control">
                <?php
                $ds = "SELECT * FROM package WHERE type='REACTION' ORDER BY price ASC";
                $ds_x = mysqli_query($conn, $ds);
                while ($ok = mysqli_fetch_assoc($ds_x)) {
                    $check  = '';
                    if($x['limit_react'] == $ok['max']){
                        $check = 'selected';
                    }
                    echo "<option value='" . $ok['max'] . "' $check>{$ok['name_likes']}</option>";
                }
                ?>
                </select>
            </div>
            <div class="form-group">
                <label for="type">Chọn cảm xúc</label>
				<select id="batcx" name="batcx" class="form-control">
							<option value="1">Có</option>
							<option value="0">Không</option>
                        </select>
                <div class="container">
                    <div class="row">
                        <input type="checkbox" name="type[]" value="LIKE" id="LIKE" class="flat-red" <?= in_array('LIKE',$type) ? 'checked' : ''; ?>>
                        <label style="padding-right: 10px" for="LIKE">LIKE
                         <!--   <img src="<?$domain;?>/core/menu/icon/like.png" style="width:24px" data-toggle="tooltip" title="Thích"/> -->
                        </label>
                        <input type="checkbox" name="type[]" value="LOVE" id="LOVE" class="flat-red" <?= in_array('LOVE',$type) ? 'checked' : ''; ?>>
                        <label style="padding-right: 10px" for="LOVE">LOVE
                         <!--   <img src="<?$domain;?>/core/menu/icon/love.png" style="width:24px" data-toggle="tooltip" title="Yêu Thích" />-->
                        </label>
                        <br/>
                    </div>
                </div>
            </div>
			<div class="form-group">
                        <label>Giờ hoạt động</label>
                        <select id="giochay" name="giochay" class="form-control">
							<option value="8">8 giờ sáng</option>
                        </select> ĐẾN
						<select id="giodung" name="giodung" class="form-control">
                            <option value="21">21 giờ</option>
						</select>
                    </div>
            <div class="form-group">
                <label>Bật chạy comment</label>
                <select id="cmt" name="cmt" class="form-control">
					<option value="1">Có</option><
					<option value="0">Không</option>
                </select>
            </div>
            <div class="form-group">
                <label for="comment">Nhập nội dung bình luận mặc định</label>
                <textarea class="form-control" rows="5" name="comment" id="comment" placeholder="Mỗi dòng 1 comment, hệ thống sẽ chạy ngẫu nhiên, Enter để xuống dòng..."><?php echo isset($x['comment']) ? $x['comment'] : ''; ?></textarea>
            </div>
<!-- comment theo buổi -->
<div class="panel-group">
  <div class="panel panel-info">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse2"><font color="green"><img src="/assets/images/new.gif" width="60" height="30"/> CHỌN CÀI ĐẶT COMMENT NÂNG CAO</font></a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
					<div class="form-group">
                        <label>Bật chạy comment NÂNG CAO</label>
                        <select name="cmtngay" class="form-control">
							<option value="0">Không</option>
                            <option value="1">Có</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nhập nội dung buổi sáng( từ 9 - 10 giờ)</label>
                        <textarea class="form-control" rows="5" name="comments" id="comments" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."><?php echo isset($x['comments']) ? $x['comments'] : ''; ?></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung buổi chiều( từ 1 - 4 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentc" id="commentc" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."><?php echo isset($x['commentc']) ? $x['commentc'] : ''; ?></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung buổi tối( từ 7 - 10 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentt" id="commentt" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."><?php echo isset($x['commentt']) ? $x['commentt'] : ''; ?></textarea>
                    </div>
</div>
</div>
</div>
<!-- end nâng cao -->
			<div class="form-group">
               <label>Bật chạy nhãn dán</label>
				<select id="stick" name="stick" class="form-control">
							<option value="0">Không</option>
                            <option value="1">Có</option>
                        </select>
				</div>
				<div class="form-group">
			<label>Nhập id nhãn dán(1 id được tách bởi dấu: | )</label>
				<input class="form-control" id="nhandan" name="nhandan" value="<?=$x['nhandan'];?>" placeholder="Nhập id nhãn dán vào...Ví dụ: 184003345550654|184003438883978|344394649290083|">
            </div>
			<!-- list nhãn dán -->
			<?php include 'stick.php'; ?>
			<div class="form-group">
                <label>Trang thái</label>
                <select id="status" name="status" class="form-control">
					<option value="0">Tiếp tục chạy</option>
					<option value="1">Tạm dừng lại</option>
                </select>
				</div>
				<div class="form-group">
                        <label>Ghi chú</label>
                        <textarea class="form-control" rows="1" name="ghi_chu" id="ghi_chu" placeholder="Ghi chú gì đó..."><?php echo "$ghi_chu - Đăng ký ngày: $start;" ?></textarea>
                    </div>
			<div class="panel-footer">
			<button name="submit" class="btn btn-success">Cập nhật</button>
            <a class="btn btn-primary waves-effect waves-light" href="<?=$domain;?>/index.php?action=admin-bot">Quay lại</a>
    </div>
</form>
<!-- hết form -->
</div>
</div>
</div>
<?php }
else if(isset($_GET['giahan'])) {
	$id_bot = $_GET['giahan'];
    $get = "SELECT * FROM vipreaction WHERE user_id=$id_bot";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
	$name = $x['name'];
	$end = $x['end'];
	$han = $x['han'];
	$goi = $x['limit_react'];
	if(($goi == '1') || ($goi == '2') || ($goi == '3') || ($goi == '4') || ($goi == '5')){
		$g = '100000';
	}
	if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: index.php');
        }
    }
	// xử lý gia hạn
	$getmem = "SELECT level, boss FROM member WHERE id_ctv = $idctv";
    $res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
	$boss = $x['boss'];
	if (isset($_POST['submit'])) {
		$themhan = $_POST['han'];
		$ketqua = $han + $themhan;
		$themend = $end + $themhan * 30 * 86400 - 28800;
		if($level == 2){
			$price = $themhan * $g * 0.4;// // giảm 50% cho cộng tác viên
			$bos = $price * 0.5;// cộng tiền cho cấp trên khi chiết khấu cho cộng tác viên
		}else if($level == 3){
			$price = $themhan * $g * 0.3;// giảm 60% cho đại lý 1
			$bos = $price * 0.5;//cộng tiền cho cấp trên khi chiết khấu cho đại lý
		}else if($level == 4){
			$price = $themhan * $g * 0.25;// giảm 75% cho tổng đại lý
		}
		else{
			$price = $themhan * $g;// không chiết khấu cho thành viên
		}
		if($themhan <= 0 || $themhan > 12){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- Số tháng không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h3></div>";
		}
		else{
			mysqli_query($conn, "UPDATE member SET bill = bill + $bos WHERE id_ctv = $boss");
			$sql = "UPDATE vipreaction SET han='$ketqua', end='$themend' WHERE user_id='$id_bot'";
			if (mysqli_query($conn, $sql)) {
                $minus = "UPDATE member SET bill = bill - $price WHERE id_ctv = $idctv";
                if (mysqli_query($conn, $minus)) {
                    $content = "Gia Hạn Vip Bot";
                    $tien_sau = $bill - $price;
                    $time = time();
					if ($bill < $price) {
						echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
					}else{
                    $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, level, vip) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', '$level', 8)";
                    }
                    if (mysqli_query($conn, $his)) {
						echo "<div class=panel-footer><h3>* Thông báo: <br>- Bạn vừa gia hạn<font color=green> $themhan tháng</font> Vipbot thành công cho <font color=green> $name</font>.<br>- Bạn bị trừ <font color=green>".number_format($price)." đồng.</font></h3></div>";
                    }
                }
			}
        }
	}
?>
<?php $titles='BẠN ĐANG GIA HẠN CHO - '.$id_bot.'';?>
	<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
        <form method="post">
		<div class="form-group">
                            <label>Thời hạn</label>
                                <select id="han" name="han" class="form-control">
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) {
                                        echo "<option value='$i'>$i Tháng</option>";
                                    }
                                    ?>
                                </select>
        </div>
		<div class="panel-footer">
			<button name="submit" class="btn btn-success">Gia hạn</button>
            <a class="btn btn-primary waves-effect waves-light" href="<?=$domain;?>/index.php?action=admin-bot">Quay lại</a>
		</div>
		
</form>
</div>
</div>
</div>
<?php }else{ ?>
<?php $titles='THÊM KHÁCH HÀNG';?>
<div class="col-md-8">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
<?php
	$vi = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction WHERE server=1");
	$vip = mysqli_fetch_assoc($vi)['COUNT(*)'];
	$vi2 = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction WHERE server=2");
	$vip2 = mysqli_fetch_assoc($vi2)['COUNT(*)'];
	$vi3 = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction WHERE server=3");
	$vip3 = mysqli_fetch_assoc($vi3)['COUNT(*)'];
	$vi4 = mysqli_query($conn,"SELECT COUNT(*) FROM vipreaction WHERE server=4");
	$vip4 = mysqli_fetch_assoc($vi4)['COUNT(*)'];
	
	$getmem = "SELECT level, boss FROM member WHERE id_ctv = $idctv";
	$res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
	$boss = $x['boss'];
	$get_pack = mysqli_query($conn, "SELECT COUNT(*), MIN(price) FROM package WHERE type='REACTION'");
	$package = mysqli_fetch_assoc($get_pack);
if (isset($_POST['submit'])) {
    $token = $_POST['token'];
    $me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$token),true);
    $uid = $me['id'];
    $name = $me['name'];
    $get = "SELECT COUNT(user_id) FROM vipreaction WHERE user_id = $uid";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    $goi = $_POST['goi'];
	$han = $_POST['han'];
    $start = time();
    $end = $start + $han * 30 * 86400 - 28800;
    if($level == 2){
			$price = $han * $goi * 0.4;// giảm 60% cho cộng tác viên
			$bos = $price * 0.5;
		}else if($level == 3){
			$price = $han * $goi * 0.3;// giảm 70% cho đại lý cấp 1
			$bos = $price * 0.5;
		}else if($level == 4){
			$price = $han * $goi * 0.25;// giảm 75% cho tổng đại lý
		}
		else{
			$price = $han * $goi;
		}
	$idchan = $_POST['idchan'];
	$server = $_POST['server'];
	$giochay = $_POST['giochay'];
	$giodung = $_POST['giodung'];
    $comment = $_POST['comment'];
	$ghi_chu = $_POST['ghi_chu'];
	$comments = $_POST['comments'];
	$commentc = $_POST['commentc'];
	$commentt = $_POST['commentt'];
	$nhandan = $_POST['nhandan'];
	$stick = $_POST['stick'];
    $cmt = $_POST['cmt'];
	$cmtngay = $_POST['cmtngay'];
	$batcx = $_POST['batcx'];
	$list_type = $_POST['type'];
    $type = implode("\n", $list_type);
    $get_max = "SELECT max FROM package WHERE type='REACTION' AND price='$goi'";
    $r_max = mysqli_query($conn, $get_max);
    $max_reactions = mysqli_fetch_assoc($r_max)['max'];
    if ($n['status'] < 1) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Tài khoản của bạn chưa kích hoạt.<br.- Vui lòng liên hệ Admin.</font</h4>></div>';
    }else if(!$token || !$goi){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng điền đầy đủ thông tin.</font></h4></div>';
    }else if(($batcx == 1) && !isset($_POST['type'])){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng chọn ít nhất 1 cảm xúc.</font></h4></div>';
    }
	else if (($_POST['cmt'] == '1') && empty($comment)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung bình luận mặc định.</font></h4></div>';
    }
	else if (($_POST['cmt'] == '0') && !empty($comment)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật chạy bình luận mặc định.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($comments)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi sáng.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentc)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi chiều.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentt)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi tối.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '0') && !empty($comments)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật cài đặt nâng cao.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '0') && !empty($commentc)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật cài đặt nâng cao.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '0') && !empty($commentt)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật cài đặt nâng cao.</font></h4></div>';
    }
	else if (($cmt == '0') && ($cmtngay == '1')){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật chạy bình luận nâng cao.</font></h4></div>';
    }
	else if (($_POST['stick'] == '0') && !empty($nhandan)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật chạy nhãn dán.</font></h4></div>';
    }
	else if ($server < 0){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Server không tồn tại.</font></h4></div>';
    }
	else if(($vip >= 10) && ($server == 1)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 1 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}
	else if(($vip2 >= 10) && ($server == 2)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 2 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}else if(($vip3 >= 10) && ($server == 3)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 3 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}else if (($vip4 >= 10) && ($server ==4)){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- SERVER 4 đã quá tải.<br>- Vui lòng chọn SERVER khác.</font></h3></div>";
	}
	else if (($_POST['stick'] == '1') && empty($nhandan)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập id nhãn dán.</font></h4></div>';
    }
	else if ($bill < $price) {
			echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'success',});</script>";
			echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
    }else if(!$me['id']){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Người dùng không hoạt động<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if ($x['COUNT(user_id)'] > 0) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- UID đã tồn tại trong hệ thống.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if(($_POST['goi'] < $package['MIN(price)'])){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Gói Vipbot không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else{
		mysqli_query($conn, "UPDATE member SET bill = bill + $bos WHERE id_ctv = $boss");
        $sql = "INSERT INTO vipreaction(user_id, name, idchan, start, end, han, limit_react, id_ctv, useradd, type, batcx, giochay, giodung, access_token, comment, ghi_chu, cmtngay, comments, commentc, commentt, stick, nhandan, cmt, server, boss, status) VALUES('$uid','$name','$idchan','$start','$end','$han','$max_reactions','$idctv','$uname','$type','$batcx','$giochay','$giodung','$token','$comment','$ghi_chu','$cmtngay','$comments','$commentc','$commentt','$stick','$nhandan','$cmt','$server','$boss',0)";
        if (mysqli_query($conn, $sql)) {
            $up = "UPDATE member SET num_id = num_id + 1 WHERE id_ctv=$idctv";
            if(mysqli_query($conn, $up)){
                $minus = "UPDATE member SET bill = bill - $price WHERE id_ctv = $idctv";
                if (mysqli_query($conn, $minus)) {
                    $content = "Mua Vip Bot";
                    $tien_sau = $bill - $price;
                    $time = time();
                    $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, level, vip) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', '$level', 1)";
                    if (mysqli_query($conn, $his)) {
						echo "<div class=panel-footer><h3>* Thông báo: <br>- Bạn vừa mua<font color=green> $han tháng</font> Vipbot thành công cho <font color=green> $name</font>.<br>- Bạn bị trừ <font color=green>".number_format($price)." đồng.</font></h3></div>";
                    }
                }
            }
        }
    }
}
?>				<?php
	if($vip <= 10){
		$tt = '<font color=green>HOẠT ĐỘNG</font>';
	}else{
		$tt = '<font color=red>QUÁ TẢI</font>';
	}
	if($vip2 <= 10){
		$tt2 = '<font color=green>HOẠT ĐỘNG</font>';
	}else{
		$tt2 = '<font color=red>QUÁ TẢI</font>';
	}
	if($vip3 <= 10){
		$tt3 = '<font color=green>HOẠT ĐỘNG</font>';
	}else{
		$tt3 = '<font color=red>QUÁ TẢI</font>';
	}
	if($vip4 <= 10){
		$tt4 = '<font color=green>HOẠT ĐỘNG</font>';
	}else{
		$tt4 = '<font color=red>QUÁ TẢI</font>';
	}
?>
				<div class="form-group">
                        <label>* CHỌN SERVER</label><br>
                        <input type="radio" value="1" name="server" /> <a class="btn btn-success"> 1</a><font color="green"> (<?php echo $tt; ?>)</font>
						<input type="radio" value="2" name="server" checked="checked" /> <a class="btn btn-info"> 2</a><font color="green"> (<?php echo $tt2; ?>)</font>
						<input type="radio" value="3" name="server" /> <a class="btn btn-warning"> 3</a><font color="green"> (Đang chờ...)</font>
                    </div>
                <div class="form-group">
                    <label>Mã token( Nhớ cập nhật khi không hoạt động)</label>
                    <input class="form-control" name="token" id="token" value="<?=$_POST['token'];?>" placeholder="Nhập mã token..." required onchange="update()">
                </div>
				<div class="form-group">
			<label>Nhập uid không muốn tương tác(1 uid được tách bởi dấu: | ) tối đa 3 người</label>
				<input class="form-control" id="idchan" name="idchan" value="<?=$x['idchan'];?>" placeholder="Nhập uid của người muốn chặn tương tác. Ví dụ: 100003345550654|100003438883978|10000394649290083|">
            </div>
                <div class="form-group">
                    <label>Gói (Số bài 1 lần chạy)</label>
                    <select id="goi" name="goi" class="form-control" required onchange="updates()">
                        <?php
                        $ds = "SELECT * FROM package WHERE type='REACTION' ORDER BY price ASC";
                        $ds_x = mysqli_query($conn, $ds);
                        while ($ok = mysqli_fetch_assoc($ds_x)) {
                            echo "<option value='" . $ok['price'] . "'>{$ok['name_likes']}</option>";
                        }
                        ?>
                    </select>
                </div>
				<div class="form-group">
                            <label>Thời hạn</label>
                                <select id="han" name="han" class="form-control" required onchange="updates()">
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) {
                                        echo "<option value='$i'>$i Tháng</option>";
                                    }
                                    ?>
                                </select>
                        </div>
                <div class="form-group">
                    <label for="type">Chọn cảm xúc( Chọn KHÔNG nếu đang bị chặn tính năng)</label>
					<select id="batcx" name="batcx" class="form-control">
							<option value="1">Có</option>
							<option value="0">Không</option>
                        </select>
                    <div class="container">
                        <div class="row">
                            <input type="checkbox" name="type[]" value="LIKE" id="LIKE" class="flat-red" checked="checked">
                            <label style="padding-right: 10px" for="LIKE">LIKE
                            <!--    <img src="<?$domain;?>/core/menu/icon/like.png" style="width:24px" data-toggle="tooltip" title="Thích"/> -->
                            </label>
                            <input type="checkbox" name="type[]" value="LOVE" id="LOVE" class="flat-red">
                            <label style="padding-right: 10px" for="LOVE">LOVE
                             <!--   <img src="<?$domain;?>/core/menu/icon/love.png" style="width:24px" data-toggle="tooltip" title="Yêu Thích" /> -->
                            </label>
                            <br />
                        </div>
                    </div>
					</div>
					<div class="form-group">
                        <label>Giờ hoạt động( thời gian cho bot nghỉ là 3 tiếng 1 ngày)</label>
                        <select id="giochay" name="giochay" class="form-control">
							<option value="8">8 giờ sáng</option>
                        </select> ĐẾN
						<select id="giodung" name="giodung" class="form-control">
                            <option value="21">21 giờ</option>
						</select>
                    </div>
	<!-- cmt mặc định -->
                    <div class="form-group">
                        <label>Bật chạy comment( Không block tính năng)</label>
                        <select name="cmt" class="form-control">
							<option value="1">Có</option>
							<option value="0">Không</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nhập nội dung bình luận mặc định</label>
                        <textarea class="form-control" rows="5" name="comment" id="comment" placeholder="Mỗi dòng 1 comment, hệ thống sẽ chạy ngẫu nhiên, Enter để xuống dòng..."></textarea>
                    </div>
					<div class="form-group">
                        <label>Ghi chú</label>
                        <textarea class="form-control" rows="1" name="ghi_chu" id="ghi_chu" placeholder="Ghi chú gì đó..."></textarea>
                    </div>
<!-- comment theo buổi -->
<div class="panel-group">
  <div class="panel panel-info">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse2"><font color="green"><img src="/assets/images/new.gif" width="60" height="30"/> CHỌN CÀI ĐẶT COMMENT NÂNG CAO</font></a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
					<div class="form-group">
                        <label>Bật chạy comment NÂNG CAO</label>
                        <select name="cmtngay" class="form-control">
							<option value="0">Không</option>
                            <option value="1">Có</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nhập nội dung buổi sáng( từ 9 - 10 giờ)</label>
                        <textarea class="form-control" rows="5" name="comments" id="comments" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung buổi chiều( từ 1 - 4 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentc" id="commentc" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung buổi tối( từ 7 - 10 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentt" id="commentt" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."></textarea>
                    </div>
</div>
  </div>
</div>
<!-- end coment theo buổi -->			
			<div class="form-group">
                <label>Bật chạy nhãn dán</label>
				<select id="stick" name="stick" class="form-control">
							<option value="0">Không</option>
                            <option value="1">Có</option>
                        </select>
				
				</div>
			<div class="form-group">
			<label>Nhập id nhãn dán(1 id được tách bởi dấu: | )</label>
				<input class="form-control" id="nhandan" name="nhandan" placeholder="Nhập id nhãn dán vào...Ví dụ: 184003345550654|184003438883978|344394649290083|">
            </div>
			<!-- list nhãn dán -->
			<?php include 'stick.php'; ?>
<!-- end xổ comment -->
		<div class="panel-footer">
			<button type="submit" name="submit" class="btn btn-success"> Xác nhận </button>
            <button type="reset" class="btn btn-danger"> Xoá làm lại </button>
        </div>
  </div>
</div>
</div></form>
<script type="text/javascript">
	function update(){
        $(function () {
            $.post('<?=$domain;?>/core/menu/check-id.php', {token: $('#token').val()}, function (r) {
                $("#id-user").text(r);
            });
            $.post('<?=$domain;?>/core/menu/check-name.php', {token: $('#token').val()}, function (r) {
                $("#name-user").text(r);
            });
			$.post('<?=$domain;?>/core/menu/check-gender.php', {token: $('#token').val()}, function (r) {
                $("#gender-user").text(r);
            });
			$.post('<?=$domain;?>/core/menu/check-birthday.php', {token: $('#token').val()}, function (r) {
                $("#birthday-user").text(r);
            });
        });
		
    }
</script>
<div class="col-md-4">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">KIỂM TRA THÔNG TIN</h3>
        </div>
        <div class="panel-body">
            <div class="panel panel-default">
                <li class="list-group-item">Mã id <span class="badge pull-right bg-red" id="id-user">Chưa xác định</span></li>
                <li class="list-group-item">Họ tên <span class="badge pull-right bg-red" id="name-user">Chưa xác định</span></li>
				<li class="list-group-item">Giới tính <span class="badge pull-right bg-red" id="gender-user">Chưa xác định</span></li>
				<li class="list-group-item">Sinh nhật <span class="badge pull-right bg-red" id="birthday-user">Chưa xác định</span></li>
            </div>
			<a href="/laytoken" target="_blank"><button class="btn btn-info"> Lấy mã token </button></a>
        </div>
    </div>
</div>
<?php
}
 ?>