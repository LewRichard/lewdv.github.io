<?php $titles='BUZZ SUB';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
                <strong>HỆ THỐNG CHỈ ĐỊNH 1 SUB = <?=$setting['ratesub'];?>Đ</strong>
<?php
if (isset($_POST['submit'])) {
    $user_id = intval($_POST['user_id']);
    $max_sub = intval($_POST['max_sub']);
    $price = $setting['ratesub'] * $max_sub;
    $me = json_decode(file_get_contents('https://graph.fb.me/'.$user_id.'?access_token='.$tokenx),true);
    $checkid = mysqli_query($conn, "SELECT COUNT(user_id) FROM buzz_sub WHERE user_id='$user_id'");
    $check = mysqli_fetch_assoc($checkid);
    $loi = array();
    if ($n['status'] < 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Tài khoản của bạn chưa kích hoạt.',type: 'error',});</script>";
    }else if (!$user_id) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'UID không đúng định dạng.',type: 'error',});</script>";
    }else if (!$max_sub) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng nhập giới hạn sub cần mua.',type: 'error',});</script>";
    }else if(!$me['name']){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'UID không hợp lệ hoặc không tồn tại.',type: 'error',});</script>";
    }else if ($check['COUNT(user_id)'] == 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: '<strong>$user_id</strong> đã tồn tại trên hệ thống.',type: 'error',});</script>";
    }else if ($max_sub < 1000) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mua tối thiểu <strong>1.000 sub</strong>.',type: 'error',});</script>";
    }else if ($bill - $price < 0) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'error',});</script>";
    }else{
        mysqli_query($conn, "INSERT INTO buzz_sub(user_id, max_sub, subd, id_ctv) VALUES('$user_id', '$max_sub', '0', '$idctv')");
        mysqli_query($conn, "UPDATE member SET bill = bill - $price WHERE id_ctv=$idctv");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thành công.',type: 'success',});</script>";
    }
}
?>
                <div class="form-group">
                    <label for="user_id">UID:</label>
                        <input type="text" class="form-control" value="<?php echo isset($_POST['user_id']) ? $_POST['user_id'] : ''; ?>" id="user_id" name="user_id" placeholder="UID facebook cần tăng." required>
                </div>
                <div class="form-group">
                    <label for="max_sub">Số sub cần mua:</label>
                    <input name="max_sub" class="form-control" placeholder="Nhập số sub cần mua" type="number" value="<?php echo isset($_POST['max_sub']) ? $_POST['max_sub'] : ''; ?>" max="10000"/>
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success waves-effect waves-light">XÁC NHẬN</button>
        </div>
            </form>
    </div>
</div>

<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-body">
            <div class="table-responsive">
                <table id="example1" class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>UID</th>
                            <th>Sub cần tăng</th>
                            <th>Sub đã hoàn thành</th>
                            <th>Trạng thái</th>
                            <th>Công cụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        if($uname != $accoutadmin){
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_sub WHERE id_ctv = $idctv");
                        }else{
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_sub");
                        }
                        while ($x = mysqli_fetch_assoc($get_buzz)) {
                            // cột trạng thái
                            $tt = "<font color=green>Đang chạy</font>";
                            if($x['subd'] >= $x['max_sub']){
                                $tt = "<font color=red>Đã hoàn thành</font>";
                            }
                            
                            // cột công cụ
                            $ii = $i + 1;
                            ?>
                            <tr>
                                <td><?=$ii;?></td>
                                <td><a href="//fb.com/<?=$x['user_id'];?>" target="_blank"><?=$x['user_id'];?></a></td>
                                <td><?= $x['max_sub'];?> sub</td>
                                <td><?=$x['subd'];?> sub</td>
                                <td><?= $tt;?></td>
                                <td style="text-align:center"><a onclick="xoa(<?= $x['id'];?>)" class="btn btn-danger" href="javascript:void(0)">Xóa</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    function xoa(id) {
        if (confirm('Bạn có chắc xóa id này?') == true) {
            window.location = '<?=$domain;?>/index.php?action=buzz-sub&id=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $get = "SELECT * FROM buzz_sub WHERE id = $id";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $user_id = $check['user_id'];
    $end = $check['end'];
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>window.location='/index.php?action=trang-loi';</script>";
        }else{
            $sql = "DELETE FROM buzz_sub WHERE id = $id";
            if (mysqli_query($conn, $sql)) {
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";      
                if(mysqli_query($conn, $up)){
                    echo "<script>window.location='/index.php?action=buzz-sub';</script>";
                }
            }
        }
    }else if($uname != $accoutadmin){
        $sql = "DELETE FROM buzz_sub WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
            if(mysqli_query($conn, $up)){
                echo "<script>window.location='/index.php?action=buzz-sub';</script>";
            }
        }
    }else{
        $del = mysqli_query($conn, "DELETE FROM buzz_sub WHERE id = $id");
        if($del){
            echo "<script>window.location='/index.php?action=buzz-sub';</script>";
        }
    }
}
?>