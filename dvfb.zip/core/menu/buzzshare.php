<?php $titles='BUZZ SHARE';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
                <strong>HỆ THỐNG CHỈ ĐỊNH 1 SHARE = <?=$setting['rateshare'];?>Đ</strong>
<?php
if (isset($_POST['submit'])) {
    $post_id = intval($_POST['post_id']);
    $max_share = intval($_POST['max_share']);
    $price = $setting['rateshare'] * $max_share;
    $me = json_decode(file_get_contents('https://graph.fb.me/'.$post_id.'?access_token='.$tokenx),true);
    $checkid = mysqli_query($conn, "SELECT COUNT(post_id) FROM buzz_share WHERE post_id='$post_id'");
    $check = mysqli_fetch_assoc($checkid);
    $loi = array();
    if ($n['status'] < 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Tài khoản của bạn chưa kích hoạt.',type: 'error',});</script>";
    }else if (!$post_id) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'UID không đúng định dạng.',type: 'error',});</script>";
    }else if (!$max_share) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng nhập giới hạn share cần mua.',type: 'error',});</script>";
    }else if(!$me['name']){
        echo "<script>swal({html: true,title: 'Thất bại',text: 'UID không hợp lệ hoặc không tồn tại.',type: 'error',});</script>";
    }else if ($check['COUNT(post_id)'] == 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: '<strong>$post_id</strong> đã tồn tại trên hệ thống.',type: 'error',});</script>";
    }else if ($max_share < 1000) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mua tối thiểu <strong>1.000 share</strong>.',type: 'error',});</script>";
    }else if ($bill - $price < 0) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'error',});</script>";
    }else{
        mysqli_query($conn, "INSERT INTO buzz_share(post_id, max_share, shared, id_ctv) VALUES('$post_id', '$max_share', '0', '$idctv')");
        mysqli_query($conn, "UPDATE member SET bill = bill - $price WHERE id_ctv=$idctv");
        echo "<script>swal({html: true,title: 'Thành công',text: 'Thành công.',type: 'success',});</script>";
    }
}
?>
                <div class="form-group">
                    <label for="post_id">Post ID:</label>
                        <input type="text" class="form-control" value="<?php echo isset($_POST['post_id']) ? $_POST['post_id'] : ''; ?>" id="post_id" name="post_id" placeholder="Id bài viết cần tăng share." required>
                </div>
                <div class="form-group">
                    <label for="max_share">Số share cần mua:</label>
                    <input name="max_share" class="form-control" placeholder="Nhập số share cần mua" type="number" value="<?php echo isset($_POST['max_share']) ? $_POST['max_share'] : ''; ?>" max="10000"/>
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success waves-effect waves-light">XÁC NHẬN</button>
        </div>
            </form>
    </div>
</div>

<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-body">
            <div class="table-responsive">
                <table id="example1" class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>UID</th>
                            <th>Share cần tăng</th>
                            <th>Share đã hoàn thành</th>
                            <th>Trạng thái</th>
                            <th>Công cụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        if($uname != $accoutadmin){
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_share WHERE id_ctv = $idctv");
                        }else{
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_share");
                        }
                        while ($x = mysqli_fetch_assoc($get_buzz)) {
                            // cột trạng thái
                            $tt = "<font color=green>Đang chạy</font>";
                            if($x['shared'] >= $x['max_share']){
                                $tt = "<font color=red>Đã hoàn thành</font>";
                            }
                            
                            // cột công cụ
                            $ii = $i + 1;
                            ?>
                            <tr>
                                <td><?=$ii;?></td>
                                <td><a href="//fb.com/<?=$x['post_id'];?>" target="_blank"><?=$x['post_id'];?></a></td>
                                <td><?= $x['max_share'];?> share</td>
                                <td><?=$x['shared'];?> share</td>
                                <td><?= $tt;?></td>
                                <td style="text-align:center"><a onclick="xoa(<?= $x['id'];?>)" class="btn btn-danger" href="javascript:void(0)">Xóa</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    function xoa(id) {
        if (confirm('Bạn có chắc xóa id này?') == true) {
            window.location = '<?=$domain;?>/index.php?action=buzz-share&id=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $get = "SELECT * FROM buzz_share WHERE id = $id";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $post_id = $check['post_id'];
    $end = $check['end'];
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>window.location='/index.php?action=trang-loi';</script>";
        }else{
            $sql = "DELETE FROM buzz_share WHERE id = $id";
            if (mysqli_query($conn, $sql)) {
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";      
                if(mysqli_query($conn, $up)){
                    echo "<script>window.location='/index.php?action=buzz-share';</script>";
                }
            }
        }
    }else if($uname != $accoutadmin){
        $sql = "DELETE FROM buzz_share WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
            if(mysqli_query($conn, $up)){
                echo "<script>window.location='/index.php?action=buzz-share';</script>";
            }
        }
    }else{
        $del = mysqli_query($conn, "DELETE FROM buzz_share WHERE id = $id");
        if($del){
            echo "<script>window.location='/index.php?action=buzz-share';</script>";
        }
    }
}
?>