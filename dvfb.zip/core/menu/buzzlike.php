<?php $titles='BUZZ LIKE';?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
                <strong>HỆ THỐNG CHỈ ĐỊNH 1 LIKE = <?=$setting['ratelike'];?>Đ</strong>
<?php
if (isset($_POST['submit'])) {
    $post_id = htmlspecialchars(addslashes($_POST['post_id']));
    $list_type = $_POST['type'];
    $type = implode("\n", $list_type);
    $checkne = json_decode(file_get_contents('https://graph.fb.me/'.$post_id.'?access_token='.$tokenx), true);
    $count_react = json_decode(file_get_contents('https://graph.fb.me/'.$post_id.'/reactions?access_token='.$tokenx.'&fields=id&method=get&summary=total_count'),true);
    $likestt = $count_react['summary']['total_count'];
    $max_like = intval($_POST['max_like']);
    $likehoanthanh = $likestt + $max_like;
    $price = $setting['ratelike'] * $max_like;
    $checkid = mysqli_query($conn, "SELECT COUNT(post_id) FROM buzz_like WHERE post_id='$post_id'");
    $check = mysqli_fetch_assoc($checkid);
    $loi = array();
    if ($n['status'] < 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Tài khoản của bạn chưa kích hoạt.',type: 'error',});</script>";
    }else if ($checkne['category']) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Không thể sử dụng ID Page.',type: 'error',});</script>";
    }else if (!isset($_POST['type'])) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Vui lòng chọn ít nhất 1 loại cảm xúc.',type: 'error',});</script>";
    }else if ($check['COUNT(post_id)'] == 1) {
        echo "<script>swal({html: true,title: 'Thất bại',text: '<strong>$post_id</strong> đã tồn tại trên hệ thống.',type: 'error',});</script>";
    }else if ($max_like < 500) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Mua tối thiểu <strong>500 like</strong>.',type: 'error',});</script>";
    }else if ($bill - $price < 0) {
        echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'error',});</script>";
    }else{
        $ins = mysqli_query($conn, "INSERT INTO buzz_like(post_id, max_like, type, id_ctv, liked, likehoanthanh) VALUES('$post_id','$max_like','$type','$idctv', '$likestt', '$likehoanthanh')");
        if (mysqli_query($conn, $ins)) {
            $up = mysqli_query($conn, "UPDATE member SET bill = bill - $price WHERE id_ctv=$idctv");
            if (mysqli_query($conn, $up)) {
                $content = "Mua Vip Buzz";
                $tien_sau = $bill - $price;
                $time = time();
                $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, type) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', 2)";
                if (mysqli_query($conn, $his)) {
                    echo "<script>swal({html: true,title: 'Thành công',text: 'Thêm <strong>$post_id</strong> vào hệ thống thành công.',type: 'success',});</script>";
                }
            }
        }
    }
}
?>
                <div class="form-group">
                    <label for="post_id">Post ID:</label>
                        <input type="text" class="form-control" value="<?php echo isset($_POST['post_id']) ? $_POST['post_id'] : ''; ?>" id="post_id" name="post_id" placeholder="Status định dạng id sau Idfb_Idpost | Ảnh đinh dạng id sau Idpost" required>
                </div>
                <div class="form-group">
                    <label for="max_like">Số like cần mua:</label>
                    <input name="max_like" class="form-control" placeholder="Nhập số like cần mua" type="number" value="<?php echo isset($_POST['max_like']) ? $_POST['max_like'] : ''; ?>"  min="10" max="1000"/>
                </div>
                <div class="form-group">
                    <label for="type">Cảm xúc:</label>
                    <select id="goi" name="max_like" class="form-control">
                        <option value="LIKE">Thích</option>
                        <option value="LOVE">Yêu Thích</option>
                        <option value="HAHA">Cười lớn</option>
                        <option value="WOW">Ngạc nhiên</option>
                        <option value="SAD">Buồn</option>
                        <option value="ANGRY">Phẫn nộ</option>
                    </select>
                </div>
        </div>
        <div class="panel-footer">
            <button name="submit" class="btn btn-success waves-effect waves-light">XÁC NHẬN</button>
        </div>
            </form>
    </div>
</div>

<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-body">
            <div class="table-responsive">
                <table id="example1" class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Post ID</th>
                            <th>Cảm xúc</th>
                            <th>Like cần tăng</th>
                            <th>Like hiện tại STT</th>
                            <th>Like dự kiến</th>
                            <th>Trạng thái</th>
                            <th>Công cụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        if($uname != $accoutadmin){
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_like WHERE id_ctv = $idctv");
                        }else{
                            $get_buzz = mysqli_query($conn, "SELECT * FROM buzz_like");
                        }
                        while ($x = mysqli_fetch_assoc($get_buzz)) {
                            // cột loại CX
                            $type = $x['type'];
                            if(strpos($type, "\n", 0)){
                                $type = str_replace("\n", " ", $x['type']);
                                $type = str_replace(array('LIKE', 'HAHA', 'LOVE', 'WOW', 'SAD', 'ANGRY'), array(
                                    '<img src="/core/menu/icon/like.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Thích">', 
                                    '<img src="/core/menu/icon/haha.svg" style="width:24px" data-toggle="tooltip" title="" data-original-title="Cười lớn">', 
                                    '<img src="/core/menu/icon/love.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Yêu thích">', 
                                    '<img src="/core/menu/icon/wow.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Ngạc nhiên">', 
                                    '<img src="/core/menu/icon/sad.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Buồn">', 
                                    '<img src="/core/menu/icon/angry.png" style="width:24px" data-toggle="tooltip" title="" data-original-title="Phẩn nộ">'), $type);
                            }
                            
                            // cột trạng thái
                            $tt = "<font color=green>Đang chạy</font>";
                            if($x['liked'] >= $x['likehoanthanh']){
                                $tt = "<font color=red>Đã hoàn thành</font>";
                            }
                            
                            // cột công cụ
                            $ii = $i + 1;
                            ?>
                            <tr>
                                <td><?=$ii;?></td>
                                <td><a href="//fb.com/<?=$x['post_id'];?>" target="_blank"><?=$x['post_id'];?></a></td>
                                <td><?= $type;?></td>
                                <td><?= $x['max_like'];?> Like</td>
                                <td><?=$x['liked'];?> Like</td>
                                <td><?=$x['likehoanthanh'];?></td>
                                <td><?= $tt;?></td>
                                <td style="text-align:center"><a onclick="xoa(<?= $x['id'];?>)" class="btn btn-danger" href="javascript:void(0)">Xóa</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    function xoa(id) {
        if (confirm('Bạn có chắc xóa id này?') == true) {
            window.location = '<?=$domain;?>/index.php?action=buzz-like&id=' + id;
        } else {
            return false;
        }
    }
</script>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $get = "SELECT * FROM buzz_like WHERE id = $id";
    $result = mysqli_query($conn, $get);
    $check = mysqli_fetch_assoc($result);
    $ctv = $check['id_ctv'];
    $post_id = $check['post_id'];
    $end = $check['end'];
    if ($uname != $accoutadmin) {
        if ($check['id_ctv'] != $idctv) {
            echo "<script>window.location='/index.php?action=trang-loi';</script>";
        }else{
            $sql = "DELETE FROM buzz_like WHERE id = $id";
            if (mysqli_query($conn, $sql)) {
                    $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";      
                if(mysqli_query($conn, $up)){
                    echo "<script>window.location='/index.php?action=buzz-like';</script>";
                }
            }
        }
    }else if($uname != $accoutadmin){
        $sql = "DELETE FROM buzz_like WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $up = "UPDATE member SET num_id = num_id - 1 WHERE id_ctv=$ctv";
            if(mysqli_query($conn, $up)){
                echo "<script>window.location='/index.php?action=buzz-like';</script>";
            }
        }
    }else{
        $del = mysqli_query($conn, "DELETE FROM buzz_like WHERE id = $id");
        if($del){
            echo "<script>window.location='/index.php?action=buzz-like';</script>";
        }
    }
}
?>