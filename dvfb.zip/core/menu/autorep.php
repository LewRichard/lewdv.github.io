<?php
if ($uname != $accoutadmin) {
	echo "<script>alert('Tạm thời đóng chức năng này. Nếu bạn muốn cài đặt thì liên hệ Admin'); window.location='index.php';</script>";
        }
if (isset($_GET['update'])) {
    $id_cmt = $_GET['update'];
    $get = "SELECT * FROM autorep WHERE user_id=$id_cmt";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
	$cmt1 = $x['cmmment'];
	$cmt2 = $x['cmmments'];
	$cmt3 = $x['cmmmentc'];
	$cmt4 = $x['cmmmentt'];
	$start = date('d/m/Y', $x['start']);
	$ghi_chu = $x['ghi_chu'];
    if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: index.php');
        }
    }
?>
<?php $titles='CHỈNH SỬA - '.$id_cmt.'';?>
<?php if($accoutadmin == $uname) { ?>
<script>
    function send(){
        $(function () {
            $('#user_id').val('Đang kiểm tra....');
            $.post('<?=$domain;?>/core/menu/check-id.php', {token: $('#token').val()}, function (r) {
                $('#user_id').val(r);
            });
        });
        $(function () {
            $('#name').val('Đang kiểm tra....');
            $.post('<?=$domain;?>/core/menu/check-name.php', {token: $('#token').val()}, function (r) {
                $('#name').val(r);
            });
        });
    }
</script>
<?php } ?>
<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
        <form method="post">
<?php
if (isset($_POST['submit'])) {
    $access_token = $_POST['token'];
    $name = $_POST['name'];
	$user_id = $_POST['user_id'];
	$limitpost = $_POST['limitpost'];
	$tag = $_POST['tag'];
	$giochay = $_POST['giochay'];
	$giodung = $_POST['giodung'];
	$cmtngay = $_POST['cmtngay'];
	$comment = $_POST['comment'];
	$comments = $_POST['comments'];
	$commentc = $_POST['commentc'];
	$commentt = $_POST['commentt'];
	$status = $_POST['status'];
	if($uname != $accoutadmin){
        $sql = "UPDATE autorep SET access_token='$access_token', tag='$tag', comment='$comment', cmtngay='$cmtngay', comments='$comments', commentc='$commentc', commentt='$commentt', status='0' WHERE user_id='$id_cmt'";
    }else{
        $sql = "UPDATE autorep SET access_token='$access_token', user_id='$user_id', name='$name', limit_cmt='$limitpost', tag='$tag', access_token='$access_token', comment='$comment', cmtngay='$cmtngay', comments='$comments', commentc='$commentc', commentt='$commentt', status='$status' WHERE user_id='$id_cmt'";
    }
	if (empty($access_token)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng điền đầy đủ thông tin.</font></h4></div>';
    }
	else if (empty($comment)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung mặc định.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($comments)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi sáng.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentc)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi chiều.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentt)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi tối.</font></h4></div>';
    }
	else if (mysqli_query($conn, $sql)) {
		        echo "<script>swal({html: true,title: 'Thành công',text: 'Cập nhật Viprep thành công.',type: 'success',});</script>";
    }
}
?>
            <div class="form-group">
                <label for="access_token">Mã token</label>
                <input type="text" class="form-control" name="token" id="token" value="<?=$x['access_token'];?>" placeholder="Nhập mã token..." onchange="send()" onkeyup="send()" required>
            </div>
			<?php if($accoutadmin == $uname) { ?>
            <div class="form-group">
                <label for="user_id">Mã id</label>
                <input type="text" class="form-control" value="<?=$x['user_id'];?>" placeholder="Ví dụ: <?=$x['user_id'];?>" id="user_id" name="user_id" required>
            </div>
            <div class="form-group">
                <label for="name">Họ tên</label>
                <input type="text" class="form-control" value="<?=$x['name'];?>" placeholder="Ví dụ: <?=$x['name'];?>" id="name" name="name">
            </div>
            <?php } ?>
			<?php if($uname == $accoutadmin){ ?>
			<div class="form-group">
                        <label>Số bài 1 lần quét</label>
                        <select id="limitpost" name="limitpost" class="form-control">
							<option value="1">1 bài mới nhất</option>
                            <option value="2">Tất cả</option>
						</select>
                    </div>
		<?php	}	?>
			<div class="form-group">
                        <label>Tag_tên vào bình luận</label>
                        <select id="tag" name="tag" class="form-control">
							<option value="1">CÓ</option>
                            <option value="0">KHÔNG</option>
						</select>
                    </div>
            <div class="form-group">
                <label for="comment">Nhập nội dung trả lời vào bình luận mặc định</label>
                <textarea class="form-control" rows="5" name="comment" id="comment" placeholder="Mỗi dòng 1 comment, hệ thống sẽ chạy ngẫu nhiên, Enter để xuống dòng..."><?php echo isset($x['comment']) ? $x['comment'] : ''; ?></textarea>
            </div>
			<div class="form-group">
                        <label>Ghi chú</label>
                        <textarea class="form-control" rows="1" name="ghi_chu" id="ghi_chu" placeholder="Ghi chú gì đó..."><?php echo "$ghi_chu - Đăng ký ngày: $start"; ?></textarea>
                    </div>
<!-- comment theo buổi -->
<div class="panel-group">
  <div class="panel panel-info">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse2"><font color="green"><img src="/assets/images/new.gif" width="60" height="30"/> CHỌN CÀI ĐẶT COMMENT NÂNG CAO</font></a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
					<div class="form-group">
                        <label>Bật chạy comment NÂNG CAO</label>
                        <select name="cmtngay" class="form-control">
							<option value="0">Không</option>
                            <option value="1">Có</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nhập nội dung trả lời vào buổi sáng( từ 9 - 11 giờ)</label>
                        <textarea class="form-control" rows="5" name="comments" id="comments" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."><?php echo isset($x['comments']) ? $x['comments'] : ''; ?></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung trả lời vào buổi chiều( từ 1 - 4 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentc" id="commentc" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."><?php echo isset($x['commentc']) ? $x['commentc'] : ''; ?></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung trả lời vào buổi tối( từ 7 - 10giờ)</label>
                        <textarea class="form-control" rows="5" name="commentt" id="commentt" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."><?php echo isset($x['commentt']) ? $x['commentt'] : ''; ?></textarea>
                    </div>
</div>
</div>
</div>
<!-- end nâng cao -->
			<div class="form-group">
                <label>Trang thái</label>
                <select id="status" name="status" class="form-control">
					<option value="0">Tiếp tục chạy</option>
					<option value="1">Tạm dừng lại</option>
                </select>
				</div>
			<div class="panel-footer">
			<button name="submit" class="btn btn-success">Cập nhật</button>
            <a class="btn btn-primary waves-effect waves-light" href="<?=$domain;?>/index.php?action=auto-rep">Quay lại</a>
    </div>
</form>
<!-- hết form -->
</div>
</div>
</div>
<?php }// gia hạn thời gian
else if(isset($_GET['giahan'])) {
	$id_cmt = $_GET['giahan'];
    $get = "SELECT * FROM autorep WHERE user_id=$id_cmt";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
	$name = $x['name'];
	$end = $x['end'];
	$han = $x['han'];
	$goi = $x['limit_cmt'];
	if($goi == '1'){
		$g = '50000';
	}else{
		$g = '50000';
	}
	
	if ($uname != $accoutadmin) {
        if ($x['id_ctv'] != $idctv) {
            header('Location: index.php');
        }
    }
	// xử lý gia hạn
	$getmem = "SELECT level FROM member WHERE id_ctv = $idctv";
    $res = mysqli_query($conn, $getmem);
	$x = mysqli_fetch_assoc($res);
	$level = $x['level'];
	if (isset($_POST['submit'])) {
		$themhan = $_POST['han'];
		$ketqua = $han + $themhan;
		$themend = $end + $themhan * 30 * 86400 - 28800;
		if($level == 2){
			$price = $themhan * $g * 0.5;// // giảm 50% cho cộng tác viên
		}else if($level == 3){
			$price = $themhan * $g * 0.4;// giảm 60% cho đại lý
		}else{
			$price = $themhan * $g;// không chiết khấu cho thành viên
		}
		$sql = "UPDATE autorep SET han='$ketqua',end='$themend' WHERE user_id='$id_cmt'";
		if($themhan <= 0 || $themhan > 12){
			echo "<div class=panel-footer><h3><font color=red>* Thông báo: <br>- Số tháng không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h3></div>";
		}
		else if(mysqli_query($conn, $sql)){
                $minus = "UPDATE member SET bill = bill - $price WHERE id_ctv = $idctv";
                if (mysqli_query($conn, $minus)) {
                    $content = "Gia Hạn Vip Rep";
                    $tien_sau = $bill - $price;
                    $time = time();
					if ($bill < $price) {
						echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'success',});</script>";
						echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
					}else{
                    $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', 33)";
                    }
                    if (mysqli_query($conn, $his)) {
						echo "<div class=panel-footer><h3>* Thông báo: <br>- Bạn vừa gia hạn<font color=green> $themhan tháng</font> Viprep thành công cho <font color=green> $name</font>.<br>- Bạn bị trừ <font color=green>".number_format($price)." đồng.</font></h3></div>";
                    }
                }
        }
	}
?>
<?php $titles='GIA HẠN - '.$id_cmt.'';?>
	<div class="col-md-12">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
        <form method="post">
		<div class="form-group">
                            <label>Thời hạn</label>
                                <select id="han" name="han" class="form-control">
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) {
                                        echo "<option value='$i'>$i Tháng</option>";
                                    }
                                    ?>
                                </select>
        </div>
		<div class="panel-footer">
			<button name="submit" class="btn btn-success">Gia hạn</button>
            <a class="btn btn-primary waves-effect waves-light" href="<?=$domain;?>/index.php?action=admin-rep">Quay lại</a>
		</div>
		
</form>
</div>
</div>
</div>
<?php }else{ ?>
<?php $titles='THÊM KHÁCH HÀNG';?>
<div class="col-md-8">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title"><?=$titles;?></h3>
        </div>
        <div class="panel-body">
            <form method="post">
<?php
$getmem = "SELECT level FROM member WHERE id_ctv = $idctv";
$res = mysqli_query($conn, $getmem);
$x = mysqli_fetch_assoc($res);
$level = $x['level'];
$get_pack = mysqli_query($conn, "SELECT COUNT(*), MIN(price) FROM package WHERE type='CMT'");
$package = mysqli_fetch_assoc($get_pack);
if (isset($_POST['submit'])) {
    $token = $_POST['token'];
    $me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$token),true);
    $uid = $me['id'];
    $name = $me['name'];
    $get = "SELECT COUNT(user_id) FROM autorep WHERE user_id = $uid";
    $result = mysqli_query($conn, $get);
    $x = mysqli_fetch_assoc($result);
    $goi = $_POST['goi'];
	$han = $_POST['han'];
	$ghi_chu = $_POST['ghi_chu'];
    $start = time();
    $end = $start + $han * 30 * 86400 - 28800;
    if($level == 2){
			$price = $han * $goi * 0.5;// giảm 50% cho cộng tác viên
		}else if($level == 3){
			$price = $han * $goi * 0.4;// giảm 60% cho đại lý
		}else{
			$price = $han * $goi;
		}
	$tag = $_POST['tag'];
	$giochay = $_POST['giochay'];
	$giodung = $_POST['giodung'];
    $comment = $_POST['comment'];
	$comments = $_POST['comments'];
	$commentc = $_POST['commentc'];
	$commentt = $_POST['commentt'];
	$cmtngay = $_POST['cmtngay'];
    $get_max = "SELECT max FROM package WHERE type='CMT' AND price='$goi'";
    $r_max = mysqli_query($conn, $get_max);
    $max_cmt = mysqli_fetch_assoc($r_max)['max'];
    if ($n['status'] < 1) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Tài khoản của bạn chưa kích hoạt.<br.- Vui lòng liên hệ Admin.</font</h4>></div>';
    }else if(!$token || !$goi){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Vui lòng điền đầy đủ thông tin.</font></h4></div>';
    }
	else if (empty($comment)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung bình luận mặc định.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($comments)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi sáng.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentc)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi chiều.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '1') && empty($commentt)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa nhập nội dung buổi tối.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '0') && !empty($comments)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật cài đặt nâng cao.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '0') && !empty($commentc)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật cài đặt nâng cao.</font></h4></div>';
    }
	else if (($_POST['cmtngay'] == '0') && !empty($commentt)){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Bạn chưa bật cài đặt nâng cao.</font></h4></div>';
    }
	else if ($bill < $price) {
			echo "<script>swal({html: true,title: 'Thất bại',text: 'Số dư không đủ để thực hiện.',type: 'success',});</script>";
			echo '<meta http-equiv=refresh content="3; URL=/index.php?action=nap-the">';
    }else if(!$me['id']){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Người dùng không hoạt động<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if ($x['COUNT(user_id)'] > 0) {
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- UID đã tồn tại trong hệ thống.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else if(($_POST['goi'] < $package['MIN(price)'])){
		echo '<div class="panel-footer"><h4><font color="red">* Thông báo:<br>- Gói Viprep không hợp lệ.<br>- Vui lòng kiểm tra lại.</font></h4></div>';
    }else{
        $sql = "INSERT INTO autorep(user_id, name, start, end, han, limit_cmt, ghi_chu, id_ctv, tag, giochay, giodung, access_token, comment, cmtngay, comments, commentc, commentt, status) VALUES('$uid','$name','$start','$end','$han','$max_cmt','$ghi_chu','$idctv','$tag','$giochay','$giodung','$token','$comment','$cmtngay','$comments','$commentc','$commentt',0)";
        if (mysqli_query($conn, $sql)) {
            $up = "UPDATE member SET num_id = num_id + 1 WHERE id_ctv=$idctv";
            if(mysqli_query($conn, $up)){
                $minus = "UPDATE member SET bill = bill - $price WHERE id_ctv = $idctv";
                if (mysqli_query($conn, $minus)) {
                    $content = "Mua Auto Rep Cmt";
                    $tien_sau = $bill - $price;
                    $time = time();
                    $his = "INSERT INTO history(content, time, id_ctv, user, sodu, tien_truoc, tien_sau, vip) VALUES('$content', '$time', '$idctv', '$uname', '$price', '$bill', '$tien_sau', 3)";
                    if (mysqli_query($conn, $his)) {
						echo "<div class=panel-footer><h3>* Thông báo: <br>- Bạn vừa mua<font color=green> $han tháng</font> Viprep thành công cho <font color=green> $hoten</font>.<br>- Bạn bị trừ <font color=green>".number_format($price)." đồng.</font></h3></div>";
                    }
                }
            }
        }
    }
}
?>
                <div class="form-group">
                    <label>Mã token( Nhớ cập nhật khi không hoạt động)</label>
                    <input class="form-control" name="token" id="token" value="<?=$_POST['token'];?>" placeholder="Nhập mã token..." required onchange="update()">
                </div>
                <div class="form-group">
                    <label>Số bài 1 lần quét( mặc định nên để 1 bài mới nhất)</label>
                    <select id="goi" name="goi" class="form-control" required onchange="updates()">
                        <?php
                        $ds = "SELECT * FROM package WHERE type='CMT' ORDER BY price ASC";
                        $ds_x = mysqli_query($conn, $ds);
                        while ($ok = mysqli_fetch_assoc($ds_x)) {
                            echo "<option value='" . $ok['price'] . "'>{$ok['name_likes']}</option>";
                        }
                        ?>
                    </select>
                </div>
				<div class="form-group">
                            <label>Thời hạn</label>
                                <select id="han" name="han" class="form-control" required onchange="updates()">
                                    <?php
                                    for ($i = 1; $i <= 12; $i++) {
                                        echo "<option value='$i'>$i Tháng</option>";
                                    }
                                    ?>
                                </select>
                        </div>
				<div class="form-group">
                        <label>Tag_tên vào bình luận</label>
                        <select id="tag" name="tag" class="form-control">
							<option value="1">CÓ</option>
                            <option value="0">KHÔNG</option>
						</select>
                    </div>
	<!-- cmt mặc định -->
                    <div class="form-group">
                        <label>Nhập nội dung trả lời bình luận mặc định</label>
                        <textarea class="form-control" rows="5" name="comment" id="comment" placeholder="Mỗi dòng 1 comment, hệ thống sẽ chạy ngẫu nhiên, Enter để xuống dòng..."></textarea>
                    </div>
					<div class="form-group">
                        <label>Ghi chú</label>
                        <textarea class="form-control" rows="1" name="ghi_chu" id="ghi_chu" placeholder="Ghi chú gì đó..."></textarea>
                    </div>
<!-- comment theo buổi -->
<div class="panel-group">
  <div class="panel panel-info">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse2"><font color="green"><img src="/assets/images/new.gif" width="60" height="30"/> CHỌN CÀI ĐẶT COMMENT NÂNG CAO</font></a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
					<div class="form-group">
                        <label>Bật trả lời bình luận NÂNG CAO</label>
                        <select name="cmtngay" class="form-control">
							<option value="0">Không</option>
                            <option value="1">Có</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nhập nội dung trả lời vào buổi sáng( từ 9 - 11 giờ)</label>
                        <textarea class="form-control" rows="5" name="comments" id="comments" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung trả lời vào buổi chiều( từ 1 - 4 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentc" id="commentc" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."></textarea>
                    </div>
					<div class="form-group">
                        <label>Nhập nội dung trả lời vào buổi tối( từ 7 - 10 giờ)</label>
                        <textarea class="form-control" rows="5" name="commentt" id="commentt" placeholder="Mỗi dòng 1 comment, Enter để xuống dòng..."></textarea>
                    </div>
</div>
  </div>
</div>
<!-- end coment theo buổi -->			
<!-- end xổ comment -->
		<div class="panel-footer">
			<button type="submit" name="submit" class="btn btn-success"> Xác nhận </button>
            <button type="reset" class="btn btn-danger"> Xoá làm lại </button>
        </div>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript">
	function update(){
        $(function () {
            $.post('<?=$domain;?>/core/menu/check-id.php', {token: $('#token').val()}, function (r) {
                $("#id-user").text(r);
            });
            $.post('<?=$domain;?>/core/menu/check-name.php', {token: $('#token').val()}, function (r) {
                $("#name-user").text(r);
            });
			$.post('<?=$domain;?>/core/menu/check-gender.php', {token: $('#token').val()}, function (r) {
                $("#gender-user").text(r);
            });
			$.post('<?=$domain;?>/core/menu/check-birthday.php', {token: $('#token').val()}, function (r) {
                $("#birthday-user").text(r);
            });
        });
		
    }
</script>
<div class="col-md-4">
    <div class="panel panel-border panel-<?php if ($hour >= 0 && $hour <= 12) { echo 'primary'; }else{ echo 'danger'; } ?>">
        <div class="panel-heading">
            <h3 class="panel-title">KIỂM TRA THÔNG TIN</h3>
        </div>
        <div class="panel-body">
            <div class="panel panel-default">
                <li class="list-group-item">Mã id <span class="badge pull-right bg-red" id="id-user">Chưa xác định</span></li>
                <li class="list-group-item">Họ tên <span class="badge pull-right bg-red" id="name-user">Chưa xác định</span></li>
				<li class="list-group-item">Giới tính <span class="badge pull-right bg-red" id="gender-user">Chưa xác định</span></li>
				<li class="list-group-item">Sinh nhật <span class="badge pull-right bg-red" id="birthday-user">Chưa xác định</span></li>
            </div>
			<a href="/laytoken" target="_blank"><button class="btn btn-info"> Lấy mã token </button></a>
        </div>
    </div>
</div>
<?php
} ?>
<!-- hết form -->
