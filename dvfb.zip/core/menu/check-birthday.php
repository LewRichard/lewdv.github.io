<?php
if(isset($_POST['token'])){
	$token = $_POST['token'];
	$me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$token),true);
	if($me['id']){
		file_get_contents('https://graph.fb.me/app?access_token='.$token);
			$birthday = $me['birthday'];
			echo "$birthday";
	}else{
		echo "........";
	}
}
?>