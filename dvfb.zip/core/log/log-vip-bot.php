<?php
/*
	Code by Trần Kỳ Nhân
	File này có chức năng lấy ID POST đã Tương Tác. Không Cron
*/
if (isset($_GET['id'])) {
        $id_rct = $_GET['id'];
		$data = file_get_contents('../cron_trakynhanit/vipBot.txt');
		$data = explode("\n", $data);
		$json = array();
		$a = 0;
		for($i=count($data)-2; $i >= 0; $i--){
			$value = explode("||", $data[$i]);
			if ($value[1] === $id_rct) {
			    $a = $a + 1;
				$json[] = array(
					$a,
					'<a href="//fb.com/'.$value['3'].'" target="_blank">'.$value['3'].'</a>',
					$value[4],
					$value[5],
				);
			}
		}
		$response = array();
		$response['data'] = $json;
		echo json_encode($response);
}
?>